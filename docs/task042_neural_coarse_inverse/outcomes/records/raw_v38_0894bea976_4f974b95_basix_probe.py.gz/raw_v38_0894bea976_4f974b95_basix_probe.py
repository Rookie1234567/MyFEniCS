from src.solvers.port_component_study import environment
import json, basix
print(json.dumps(environment(fe=True)))
e=basix.create_element(basix.ElementFamily.N1E, basix.CellType.hexahedron,6)
print('dim',e.dim,'dofs',e.entity_dofs,'topology',basix.cell.topology(basix.CellType.hexahedron))
print('tensor',e.has_tensor_product_factorisation,'variant',e.lagrange_variant,e.dpc_variant)
print('methods',[a for a in dir(e) if any(k in a for k in ('tensor','coeff','transform','tabulate'))])
try: print('tensor rep',e.get_tensor_product_representation())
except Exception as x: print(type(x).__name__,str(x))
print('orientation matrices',[(k,v.shape) for k,v in e.entity_transformations().items()])
