"""Author V37 documentation from measured compact evidence; no FE imports."""
import json
import subprocess
from pathlib import Path

ROOT=Path('/home/fenics/Projects/NN-Lab')
TASK=ROOT/'docs/task042_neural_coarse_inverse'
OUT=TASK/'outcomes'
R=OUT/'records'
def load(n):return json.loads((R/n).read_text())
def write(p,text):p.write_text(text,encoding='utf-8')
def prepend(p,text):
    marker='<!-- V37-LATEST-END -->'
    old=p.read_text()
    if marker in old:old=old.split(marker,1)[1].lstrip('\n')
    write(p,text+'\n'+marker+'\n\n'+old)

m=load('boundary_metrics_v37.json')
c=load('resource_costs_v37.json')
f=load('final_state_v37.json') if (R/'final_state_v37.json').exists() else None
charged=c.get('charged_final',c['charged_before_pack'])
wall=c.get('supervised_wall_seconds_final',c['supervised_wall_seconds_before_pack'])
probes=c.get('probe_seconds_final',c['probes'])
peak=c['sampled_tree_peak_bytes']
storage=c.get('storage_final',c['storage'])
closed='closed，全部自有actor清除' if f else '数值队列已结束；closed／清场以 final_state_v37.json 为准'
cost=f'{charged:.9f}'

summary=f'''# V37统一结果：普通p6面片分块接口通过，q15不合格，全量边界未获资格

端口把边界场分解为不同衍射方向。新接口将单个方向的边界数据继续拆成面片：第一遍累加一个复振幅，第二遍重放面片并累加牵引。这样不必常驻整张单方向系数表，代价是两次遍历与生成；它不改变三维体积方程，也不是神经收益。

| 对象／数据身份 | measured、derived或not_run结果 | 门限／边界及证据 |
|---|---|---|
| 原50×25nm周期、z=−10..130nm、.7nm、p6容量情景 | 32060 ordered端口；530856 cells／345771066 storage，均复用V36 | 未建目标体积mesh／完整编号或解PDE |
| p6真实普通面片，4hex、882局部basis、12预登记mode、MPI1 | q15→q30最大相对差 {m['q15_q30_max']:.12g} | 高于1e-10，q15未获此见证资格 |
| 未裁剪native q30 vs Basix q60 | 最大相对差 {m['q30_native_q60_Basix_max']:.12g} | 低于1e-10；原生q60、max普通／周期缝／角点未完成，不授全量边界资格 |
| q30分块正向／伴随／复振幅 | {m['action_checks']['forward']['relative']:.12g}／{m['action_checks']['adjoint']['relative']:.12g}／{m['action_checks']['port']['relative']:.12g} | H独立重算差0；单位功率绝对差7.1054e-15；仅P6_TILE_INTERFACE_QUALIFIED_ON_PARTIAL_WITNESS |
| 数值tile／creator工作区 | 42336B／q30上界22127616B、q60上界81821376B | 缓存与生成临时对象分开；真实全量support／周期扩张上界unknown |
| shared-workstation费用／峰 | 计费 {cost}s；同时树采样峰 {peak}B；own swap0 | 0.5s采样，非连续cgroup硬峰；实现／元数据读写未单独监督部分unknown |
| 新存储停止及最终库存 | 原JIT C/o/so重叠曾越512MiB；无损归档后 {storage['new_bytes']}B | 保留越界事实，不改成全程合规；原生q60与扩大面片停止 |
| 原方程、total/scattered E/H、curl、40或32060通道物理解、R/T/A/A_volume及能量 | 本轮全部NOT_RUN | 仅任意边界向量与单位通道泛函，没有新合格场 |
| dot语义消费／原尺寸2TB、48h／NN20% | SOLVER_PACKAGE_NOT_QUALIFIED／NOT_QUALIFIED／NOT_DEMONSTRATED | 不忽略材料差2.9917e-8，不以小面片或缓存节省推断生产能力 |

[response](../response_v37.md)／[完整结果](target_p6_boundary_tiles_v37.md)／[独立checker](records/component_checker_v37.json)／[全部费用](records/resource_costs_v37.json)／[run与source](records/run_index_v37.json)。本批{closed}，V24–V36永久closed，旧资格及负结果保持。唯一下一建议：取得一次可预估JIT峰存储的未裁剪原生q60周期缝／角点边界见证，补齐精度与MPC覆盖；不自动运行、不升级到体积求解或NN训练。
'''
prepend(OUT/'summary.md',summary)
for name,title in [('docs/development_progress.md','Task042 V37进展'),('docs/development_model_registry.md','Task042 V37模型总账')]:
    body=summary.replace('# V37统一结果',f'# {title}',1)
    body=body.replace('(../response_v37.md)','(task042_neural_coarse_inverse/response_v37.md)').replace('(target_p6_boundary_tiles_v37.md)','(task042_neural_coarse_inverse/outcomes/target_p6_boundary_tiles_v37.md)').replace('(records/','(task042_neural_coarse_inverse/outcomes/records/')
    prepend(ROOT/name,body)

write(TASK/'response_v37.md',f'''# Response V37：完成目标边界的有限真实见证与分块接口，保留q15及存储负结果

本轮在原三维目标尺寸的普通外表面上核查高阶有限元边界积分，并把单方向系数改为分面片生成。12个预登记通道的未裁剪分块作用通过；q15精度不合格。原生q60 JIT越过新存储门后停止自身负载，留下q15／q30原生数组，再独立完成Basix q30／q60、分块、checker及容量／消费分析。**没有取得TARGET_P6_BOUNDARY_WITNESS_QUALIFIED、完整有限元解、原尺寸2TB／48h或NN20%资格。**

| 身份 | 本轮实际值 |
|---|---|
| worktree／branch／upstream | `/home/fenics/Projects/NN-Lab`／`task42_neural_coarse_inverse`／`origin/task42_neural_coarse_inverse` |
| common Git／origin | `/home/fenics/Projects/Maxwell3D-Lab/task-repository.git`／`git@github-myfenics:Rookie1234567/MyFEniCS.git` |
| 冻结base／任务初始锚点 | `ccd357885f7f9be84efe3be07868cc94f13d93fc`／`f8c51c8e614edc806cf72120ac2cfd14ae8b62f7`，均为本分支祖先 |
| 取得的Review V34 | `02fe5f860562f6a7ef689f9d53b061cfaf30a43b`，同分支安全fetch，无回退／其他worktree操作 |
| 原生保存q15／q30实际source | `ce18a6056731780d1feb4f47c96dfcc4f52aa6d1` |
| CAPACITY／独立数组CHECK实际source | `bd7d7e2bc8167973ee1156deb0e8a23607a37db6` |
| 最终实现／DEPLOY实际source | `d7ec9180af1b45f55bd37b49a6f0ac450920589e`；最后文档HEAD另在推送回执及会话报告，不冒充数值source |
| 固定时钟／边界 | 2026-10-04T03:17:22.040407958Z，monotonic1008836.90，boot fd8f4b00-1e17-46af-a6fa-da3a32dbeba3；24h总窗口，末1h交付；总有载3600s／组件2400s |
| 交付状态 | {closed}；推送后精确HEAD／clean／upstream0/0另核验，旧账本未重开 |

材料仍为canonical用户表，source波长0.699999988、nominal0.7，n=0.999885140474+4.32477054e-6i，epsilon=n²。目标周期50／25nm、外表面130／−10nm，实体x=16.5..33.5、y=0..25、z=0..120；本轮未偷换为微型模型或把面片宽度当周期。V36的32060完整ordered库存按hash复用，元数据预选12mode／4类面片共20hex；实际只完成一类4hex。各次失败重建合计16个native hex，未超过32；没有构造530856cell目标mesh或完整FE编号。

| 分别验收的问题 | 实测／停止项 | 结论 |
|---|---|---|
| q15积分是否足够 | q15／q30最大相对差 {m['q15_q30_max']:.12g} > 1e-10 | 不足；不靠裁剪小系数制造一致 |
| q30更高阶对照 | 未裁剪native q30／Basix q60差 {m['q30_native_q60_Basix_max']:.12g} | 普通面片支持q30；缺原生q60及周期情形，不能扩大结论 |
| 同q分块泛函 | 最大差 {m['q30_same_max']:.12g}；forward {m['action_checks']['forward']['relative']:.12g}，adjoint {m['action_checks']['adjoint']['relative']:.12g} | 有限普通面片接口通过；完整高阶边／面矩、方向／Piola保留，C/D独立 |
| 端口振幅／H／单位功率 | {m['action_checks']['port']['relative']:.12g}／0／7.105427357601002e-15 | 仅局部边界见证，非物理解功率 |
| 旧两道裁剪 | q30删14928及112个分量；最大C/D差1.9269e-13，未删空本组选中通道 | 此有限组未超门；V36增加LEGACY_CLIPPED_SURFACE_EQUIVALENCE限定，不能证明全部目标通道裁剪安全 |
| 软件及隔离 | 最终31个定点测试、MPI2／4小fixture、真实编译／ABI通过 | MPI1真实FE；MPI2／4含空owner与共享rows，不称真实目标MPI资格 |
| 原native／Schur残差、E/H/curl、R00_s/p/total、R/T/A、A_volume、逐通道能量 | NOT_RUN | 本轮边界组件没有体积求解；无official结果 |

失败均保留。普通面片原MPC入口不适用于没有全局周期实体的截取片，最小修复为空的原全局约束限制；周期缝／角点仍走全局50／25nm周期映射。随后修复native双复分量T_apply需要平坦缓冲区的接线。q60生成的C/o/so造成新存储越512MiB：当时只有阶段边界存储检查，这是监督接线缺口；核实自身argv／PGID和临时JIT cwd后只SIGTERM自身组，未动邻任务。保存的失败raw分类仍WORKER_FAILED，资源原因另列；未称全程存储合规。修复0.5s新存储guard，经纯回归后只做已保存前缀的独立容量接口分析，没有重新启动该q60扩大步骤。34份JIT文件先无损压缩并解压核对hash／长度后回收原副本，原始科学数组和历史结果未删。证据打包CPU字段接线错误同轮修复，失败3.280613258s仍计费。

dot只读发布SHA为077ec9c8386c976da232093779279fb9d1a93033。逐字段验收区分相同入射／lambda／p6、真实几何与材料差、mode／Floquet／canonical行／恢复证据缺失；不是拿不同schema的hash直接判不同物理。其n差2.991716531811656e-8没有被默许成同一算子，source恢复未授其runtime／科学raw资格。没有执行dot solver、factor或修改其ref／工作树。

费用均标shared-workstation：监督wall {wall:.9f}s＋探针 {probes:.9f}s＋bootstrap保守收费3s＝{cost}s，含失败、JIT、归档、测试及checker；其中PATCH＋CAPACITY累计269.670777797s。分块作用集合wall1.810418537s包含creator1.628519290s与hash0.041459786s，不能再次相加。全批同时树采样峰{peak}B（约{peak/2**30:.3f}GiB），own swap0、GPU不用；独立cgroup没有权限部署，记录为0.5s整树采样与停机保护，不伪称内核连续硬峰。数学／BLAS getter1、真实MPI1，自有锁／缓存／低优先级；每次准入重选核，实际CPU见原准入表。邻Task042extra持续运行未干预；没有足够可比阶段数据排除干扰，性能影响INCONCLUSIVE。

最终新库存{storage['new_bytes']}B、Task042 artifact {storage['task_artifact_bytes']}B，自由磁盘{storage['free_bytes']}B。端口tile实测42336B，保守全mode支撑111259016B原门会拒绝；9.08MB只是条件理想支撑。完整FE输入＋输出至少11.0647GB载荷，条件GMRES256向量组434.673GB，体积solver／因子／内部恢复／MPIIO共存峰unknown，未拼成伪峰。完整N=1历史仍有unknown；既有77349.71922726494s下界保留，不把边界费用当整个求解成本或NN摊销收益。

[完整结果与停止分析](outcomes/target_p6_boundary_tiles_v37.md)／[run与父hash](outcomes/records/run_index_v37.json)／[独立checker](outcomes/records/component_checker_v37.json)／[费用](outcomes/records/resource_costs_v37.json)／[原raw及大数组索引](outcomes/records/raw_evidence_index_v37.json)／[消费缺口](outcomes/records/consumer_v37.json)／[依赖分组](outcomes/records/selective_merge_manifest_v37.json)。GitHub精确Review V34页未取到视觉渲染，NOT_VERIFIED；本地结构检查单列，不称CI通过。

唯一下一建议：取得一次可预估JIT峰存储的未裁剪原生q60周期缝／角点边界见证，补齐精度与MPC覆盖；本轮不自动继续、不以NN补积分误差、不merge。推送、closed和清场后用原会话队列交回审阅窗口。
''')

write(OUT/'target_p6_boundary_tiles_v37.md',f'''# V37：未裁剪目标p6边界见证、单mode分面片接口及容量停止

## 目的和改变

边界积分把连续电磁场与每个有限元基函数配对，得到端口耦合系数。旧路径先删掉幅度很小的条目，再比较新旧输出；这种比较只能证明两个裁剪实现一致。V37新增未裁剪native小面片对照：基函数是p6 Nédélec的882个向量基，完整保留方向变换、Piola（把参考单元向量正确映射到真实单元）及周期主从相位。q是求积规则的多项式精确度，不是点数，Fourier指数积分仍须比较不同q。

新TiledPortAction在一个mode内部逐面片处理：先算完整投影的一个复标量，再将同样面片重放，向共享master行相加牵引；伴随对独立C/D取正确共轭。主实现不创建完整目标FE向量再切片。小native向量只作为独立oracle；完整目标行reader／周期分布尚未资格化。O(Nport)元数据与完整输入输出、O(tile)缓存分开，不能仅报tile载荷冒充总内存。

## 实际覆盖和结果

| 内容／身份 | 实际值 | 解释 |
|---|---|---|
| 固定完整模式／材料 | 32060（16030每侧），canonical n=0.999885140474+4.32477054e-6i | V36 metadata只读复用，未删通道 |
| 元数据预选mode | top index0/1/6018/6019/16028/16029；bottom16030/16031/22048/22049/32058/32059 | 含s/p、零级、横向极值、最小非零传播纵向波数；tie-break原index最小，不按结果挑选 |
| min普通面片 | bottom [24,20,0]／[25,20,0]，top同x/y、zindex201；四hex | x=16.5..17.86、y=13.8889..14.5833nm；外表面−10／130nm |
| max普通／x周期缝／xy角点 | 共另16个预登记hex，NOT_RUN_STORAGE_GATE | 计划四类20hex；实际失败重建累计16hex，独立唯一4hex；没有目标mesh |
| q15与q30 | 完整C/D泛函最大相对差 {m['q15_q30_max']:.12g} | 阈值1e-10 FAIL，不能因同q映射正确称q15精确 |
| 同q30 Basix／native | 最大相对差 {m['q30_same_max']:.12g} | 相同完整局部basis及坐标下PASS |
| q30 native与q60 Basix | 最大相对差 {m['q30_native_q60_Basix_max']:.12g} | PASS；原生q60未完成，保留独立对照边界 |
| forward／adjoint／amplitudes／modal RHS | 2.79308e-13／2.61646e-13／1.59542e-13／3.26371e-13 | 以未裁剪native重算，分子分母及全部mode保存在独立checker |
| 复线性／dual／H／单位功率 | 4.58310e-16／2.45695e-18／0／7.10543e-15 | 前两者operation差，H独立由k/E/面积／参考面算；单位功率绝对门1e-10 |
| 完整物理解／original A或SH／LU／QR／训练 | NOT_RUN／0／0／0／0 | 不把边界作用称体积传播；没有新R/T/A |

[预登记库存／坐标](records/witness_inventory_v37.json)、[原分子／分母／clipping](records/boundary_metrics_v37.json)、[保存数组独立检查](records/component_checker_v37.json)。near-zero和全零按原规则分别记录，未用operand范数覆盖完整非零泛函FAIL。

旧两道阈值仍为max(1e-30,1e-13×global_max)，按独立原native数据重算。q30第一道／第二道分别删除14928／112个分量，最大C/D相对差1.9269e-13，12mode未删空。原q15／q30每mode删除数量、最大幅度、范数、row与是否删空在raw sidecar及其hash索引；本组没有发现超门裁剪，不能证明所有32060mode／周期情形安全。V36旧资格明确LEGACY_CLIPPED_SURFACE_EQUIVALENCE，历史classification不改。

## 生命周期、资源与容量停止

| 对象／过程 | measured或derived容量／费用 | 未证明的内容 |
|---|---|---|
| tile cache／上限 | 42336B实测；独立128KiB门；mode cache门64MiB/max64 | 完整target support、periodic map扩张仍unknown，分配前门不能代替全量证明 |
| q30／q60 creatorworkspace | 上界22127616／81821376B；persistent geometry/map81024B | 算术数组载荷上界，非实测RSS；tabulation等嵌套时钟分别记录 |
| 完整分块作用集合 | 1.810418537s inclusive，192tile loads，96passes，5visits | creator1.628519290s、hash0.041459786s已包含；无匹配独立旧/新总成本速度比 |
| JIT停止 | 原始C/o/so总1559383311B，无损archive254668906B；单q60 form三件359797483B | 旧仅阶段边界guard导致越512MiB；明确软件监督缺口，未伪称门内停止 |
| 同时树采样峰／swap | {peak}B／0 | 0.5s launcher＋全部后代采样，非连续cgroup峰；FE warn6/hard8GiB，aux2GiB |
| 所有监督、probe、bootstrap | {wall:.9f}＋{probes:.9f}＋3＝{cost}s | 包含失败／重放／JIT／测试／归档／checker，非完整N=1；未监督实现和元数据时间unknown |
| 保存新数据／Task042总artifact | {storage['new_bytes']}／{storage['task_artifact_bytes']}B | 最终门内不能抹掉历史新存储越界；科学数组及旧raw只读保留 |

当q60编译中生成的多个C/o/so副本超过存储门，先核实只属本任务的worker和临时JIT cwd，再SIGTERM完整自有组，watchdog确认后代清除。未暂停或终止邻Task042extra；native q60、max普通和periodic扩大不再启动。只对完成q15／q30数组，独立重新计算手工q30／q60及分块接口；容量分析不是冒称failed PATCH恢复或完整native q60成功。新live新存储guard已接线，专门负例测试通过。归档每个文件先解压核对原hash／长度，再回收相同原生成副本。失败分类和全部费用仍在ledger与raw。

数学线程／实际BLAS1，MPI1真实FE；MPI2／4为小合成共享rows、空owner与全体拒绝fixture。activation／复杂ABI及真实命令见run index，Torch/GPU未加载，缓存全部在NN-Lab。每次CPU门实际重新核查物理核和SMT，不依赖固定CPU编号。shared-workstation的性能影响缺可比阶段证据，INCONCLUSIVE；无绝对零干扰或无争用加速声明。

## 目标级排除式与消费包

理想单mode成对支撑9082376B有支撑假设；当前旧creator安全声明111259016B会越64MiB而拒绝。分面片改变了这个单对象门，但真实全量support、target canonical面片reader及periodic展开仍需证据。目标单complex128向量5532337056B；输入输出至少11064674112B载荷；条件GMRES256向量组434673050112B。端口元数据、内部恢复、全局solver／因子、MPI／IO的同时峰unknown，不把不同阶段及共享数组相加成伪峰。

假定每face一个tile，一个完整端口作用的双遍历面片访问量为2×32060×2628=168507360。实测普通tile生成单价约0.00848s只是本次调用集合均值；冷JIT、重复几何复用、所有mode分布、通信与迭代次数unknown，不线性外推48h承诺。最能决定后续可行性的校准是完整同尺寸端口面片creator的原生高q存储峰、周期覆盖及可复用几何成本，尚未运行。

只读contract/provider/验收模块分别为solver_consumer_contract、TiledPortAction和check_boundary_witness；精确source／hash和依赖在[部署包](records/deployment_package_v37.json)。完整32060metadata有序sourcehash继续沿用。consumer逐字段区分几何、材料、lambda、入射、背景、mode、参考面、复Floquet、p、canonical rows及内部恢复。dot只读SHA077ec9c...的恢复source没有合格runtime/scientific raw；几何尺寸／缺口、材料差2.9917165e-8及缺失的全量mode／row／恢复不能静默匹配。默认TARGET_SOLVE_NOT_AUTHORIZED_OR_NOT_QUALIFIED；没有启动其volume solver或消费factor。

## 交付边界与下一步

本轮是普通面片有限组件正结果＋q15和JIT存储负结果；非完整目标边界资格、micro PDE pass或神经增量。完整原尺寸原方程、E/H/curl、功率、生产h/p/q、外部截断、2TB/48h均未资格化。历史已记77349.71922726494s下界及unknown保留，V24–V36closed，没有新的teacher/dataset/model训练。本轮没有可比完整正确N=1非神经基线，所以NN20% NOT_DEMONSTRATED。

唯一下一建议：取得一次可预估JIT峰存储的未裁剪原生q60周期缝／角点边界见证，补齐精度与MPC覆盖。不自动实施，也不继续FFT／低秩／NN替代扫描。本轮{closed}，精确最终Git HEAD在推送回执；不merge。GitHub视觉NOT_VERIFIED，本地结构检查与raw hash核验分别记录。
''')

prepend(TASK/'README.md','''# 最新交付导航：V37 / Review V34 已连续收口

已完成普通p6真实4hex／12mode未裁剪积分、单mode面片分块及独立保存数组检查。q15不合格；原生q60 JIT超过新存储门，周期缝／角点未完成，故仅P6_TILE_INTERFACE_QUALIFIED_ON_PARTIAL_WITNESS，无目标全量边界／完整求解／NN20%资格。

[合同](review_report_v34.md) · [response](response_v37.md) · [完整结果](outcomes/target_p6_boundary_tiles_v37.md) · [run/source](outcomes/records/run_index_v37.json) · [checker](outcomes/records/component_checker_v37.json) · [费用](outcomes/records/resource_costs_v37.json) · [原始证据](outcomes/records/raw_evidence_index_v37.json) · [部署与缺口](outcomes/records/deployment_package_v37.json)。失败保留；正式入口仅列复现身份，closed后不得重开运行。以下完整历史正文保留，“当前”只指当时状态。
''')
prepend(OUT/'test_summary.md','''# V37测试：真实编译、31个定点与MPI2／4小fixture通过

复用最终aux_pre_06的逐文件hash和真实ABI记录；新增独立C/D、共享rows、H/source不变性、tile容量分配前拒绝、错误相位／转置／共轭、重复／丢face、坏hash及整树超时清场测试。31pass（pytest7.36s），MPI2／4完整向量和空owner／全体拒绝通过；真实FE仅MPI1。未重复旧campaign或全仓昂贵测试，无CI声明。

首次27pass/1fail、两次PATCH接线失败、q60存储停止及打包字段失败均保留，针对性修复同轮计费。[最终测试身份](records/tests_v37.json) · [原始日志](records/raw_evidence_index_v37.json) · [独立数组审核](records/component_checker_v37.json)。Ruff／文档本地检查结果单列，GitHub视觉NOT_VERIFIED；不以小fixture授目标资格。旧后缀逐字保留。
''')
prepend(OUT/'changed_files.md','''# V37变更：通用分面片端口作用与独立原数组审核

数值核心在src/solvers，按mode内双遍历生成／散射未裁剪面片，原oracle／体积solver默认不变；provider补H/source身份绑定。复用既有runner、窗、watchdog、事务writer，并加本批新存储live门与无损JIT归档。checker只重算保存数组，不搭建FE或solve。

五个one-run dat对应IDENTITY／PATCH／CAPACITY／CHECK／DEPLOY，PAT​CH失败没有被伪造为完成；大数组、JIT、timeline保持ignored。compact证据、README／总账只增加V37内容，原task／review／response／raw不改。[实际清单](records/changed_files_v37.json) · [依赖分组与资格](records/selective_merge_manifest_v37.json)。无merge approval，不把research-only组件升为production default。
'''.replace('PAT​CH','PATCH'))
print('V37 documentation authored; numeric identity unchanged',flush=True)
