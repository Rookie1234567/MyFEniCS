"""V38 raw metadata packaging only; no numerical arrays decompressed."""
import gzip
import hashlib
import json
import subprocess
import time
from pathlib import Path

from src.runners.task042_shared import write_json
from src.runners.port_preparation import storage
from src.solvers.boundary_structure_scope import ARTIFACT, ROOT, read_stage, window

OUT = ROOT / 'docs/task042_neural_coarse_inverse/outcomes/records'
OUT.mkdir(parents=True, exist_ok=True)
REVIEW = 'cf0896e57f9f16970e5af6b55ad14920ab4c7815'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def dump(name, value):
    write_json(OUT / name, value)

def ref(path):
    return {'path': str(path), 'sha256': sha(path), 'bytes': Path(path).stat().st_size}

def pack():
    began = time.monotonic()
    stages = {role: read_stage(role) for role in ('BRIDGE','LAYOUT','COMPONENT','ORACLE','CHECK','DEPLOY')}
    bridge, layout, component, oracle, checked, deployed = [stages[k][0] for k in stages]
    book = window.ledger()
    rows, raw = [], []
    directories = []
    for r in book['runs']:
        d = Path(r['folder']); directories.append(d)
        rows.append({**{k:r[k] for k in ('role','source_sha','elapsed_seconds','classification','exit_code','peak_bytes','swap_bytes','descendants_cleared')},
                     'directory':str(d),'cpu':json.loads((d/'resource_baseline.json').read_text())['cpu'],
                     'summary':ref(d/('summary.json' if d.name.startswith('aux_') else 'run_summary.json'))})
    selected = set()
    for d in directories:
        selected.update(p for p in d.rglob('*') if p.is_file() and p.suffix in ('.json','.jsonl','.log','.stdout','.stderr','.xml','.dat','.txt'))
    selected.update(p for p in window.TMP.iterdir() if p.is_file() and p.suffix in ('.json','.jsonl','.txt','.py'))
    selected.update(p for p in ARTIFACT.rglob('*') if p.is_file() and p.suffix == '.json')
    manifests = list(window.TMP.glob('jit_archive_*/manifest.json')) + list(window.TMP.glob('fixture_archives/manifest.json'))
    selected.update(manifests)
    for p in sorted(selected):
        data = p.read_bytes(); h = hashlib.sha256(data).hexdigest()
        out = OUT/('raw_v38_'+hashlib.sha256(str(p).encode()).hexdigest()[:10]+'_'+h[:8]+'_'+p.name+'.gz')
        encoded = gzip.compress(data, compresslevel=1, mtime=0); out.write_bytes(encoded)
        if gzip.decompress(encoded) != data: raise ValueError('raw lossless readback')
        raw.append({'original_path':str(p),'gzip':str(out.relative_to(ROOT)),'bytes':len(data),'sha256':h,'gzip_sha256':sha(out)})
    parents = {k:ref(p) for k,(_,p) in stages.items()}
    dump('run_index_v38.json', {'schema':'task042.v38.run-index.v1','base':'ccd357885f7f9be84efe3be07868cc94f13d93fc','review':REVIEW,
        'source_before_documentation':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'runs':rows,'parents':parents,
        'physical_sha256':component['physical_contract_sha256'],'material':layout['physical_parent']['materials'],
        'mode_inventory_parent':ref(ROOT/'benchmarks/artifacts/task042/v37/IDENTITY.json'),'current_pack_pending_settlement':book['active']})
    dump('component_checker_v38.json',checked)
    dump('boundary_metrics_v38.json',{'bridge':[{ 'name':p['description']['name'],'checks':p['checks'],'cost':p['cost'],'native':p['native'],'literal':p['literal'],'directional':p['directional'],'independent':p['independent'],'actions':p['component']['witness']} for p in bridge['patches']],
        'row_adapter':layout['native_patch_adapter'],'component_inputs':component['inputs'],'component_outputs':component['outputs'],
        'ladder':component['ladder'],'second_input_q30':component['second_input_q30'],'q60_first':component['q60_first'],'q60_second':component['q60_second'],
        'q30_q60':component['q30_q60'],'per_channel':component['per_channel_q30_q60'],'oracle':{'checks':oracle['checks'],'outputs':oracle['outputs'],'costs':oracle['costs'],'visits':oracle['explicit_face_visits'],'wall_seconds':oracle['wall_seconds']},
        'counter_snapshot_annotation':'Historical first-input stats share a mutable dictionary with second input: 10 project/10 scatter are cumulative for two inputs, never added twice. Per-action clocks are actual separate measurements. New code copies snapshots; no numerical replay.'})
    dump('gate_decisions_v38.json',{'native_bridge':bridge['status'],'boundary_layout':layout['status'],'full_boundary_action':checked['status'],'qualified_q':30,'real_MPI':1,
        'all_modes':32060,'all_rows':378432,'selected_explicit_modes':12,'native_unique_hex':20,'native_constructs':json.loads((window.TMP/'native_construct_count.json').read_text())['count'],
        'q15_historical':'FAIL 1.3259472061511423e-5 > 1e-10, not rerun','native_q60':'NOT_RUN_STORAGE_GATE_PRESERVED',
        'full_volume_adapter':'NOT_QUALIFIED_NOT_CONSTRUCTED','full_PDE':'NOT_RUN','official_RTA':'NOT_RUN','E_H_curl_Avolume':'NOT_RUN',
        'global_p4_factor':'ABSENT','global_volume_matrices':'ABSENT','training':'NOT_RUN','NN20':'NOT_DEMONSTRATED','target_2TB_48h':'NOT_QUALIFIED',
        'failures_preserved':[r for r in rows if r['classification']!='COMPLETED']})
    snapshot = storage(namespace='v38')
    dump('resource_costs_v38.json',{'runs':rows,'supervised_wall_seconds':sum(r['elapsed_seconds'] for r in rows),'probes_seconds':window.probe_wall(),'bootstrap_charge_seconds':window.bootstrap,
        'charged_seconds_before_pack_settlement':window.charged_wall(),'component_seconds':sum(r['elapsed_seconds'] for r in rows if r['role'] in ('BRIDGE','LAYOUT','COMPONENT','ORACLE')),
        'sampled_tree_peak_bytes':max(r['peak_bytes'] for r in rows),'own_swap_peak_bytes':max(r['swap_bytes'] for r in rows),
        'peak_scope':'simultaneous dedicated supervisor and all descendants, 0.5s samples; not continuous cgroup peak','cgroup_limit_created':False,
        'physical_solve':False,'GPU_used':False,'Torch_loaded':False,'MPI_real_FE':1,'synthetic_MPI':[2,4],'math_getter_threads':1,
        'storage':snapshot,'window':window.snapshot(),'shared_workstation':True,'performance_interference':'INCONCLUSIVE; no matching isolated stage data',
        'historical_known_lower_before_v38_seconds':77821.58134307021,'historical_complete_cost':'UNKNOWN, unmonitored implementation/metadata and upstream N=1 are unknown',
        'counter_annotation':'do not add nested project/scatter/setup/hash clocks to inclusive supervised wall; see boundary_metrics',
        'current_pack_pending_settlement':book['active']})
    dump('capacity_lifecycle_v38.json',{'layout_rows':378432,'per_side':189216,'faces_per_side':2628,'layout_bytes':layout['shared_layout_bytes'],
        'numeric_cache_bytes':component['cache_bytes'],'cache_cap_bytes':64*2**20,'mode_block':64,'single_boundary_vector_bytes':378432*16,
        'component_input_bytes':(2*378432+32060)*16,'full_volume_vector_bytes_historical_derived':5532337056,'volume_rows_not_constructed':True,
        'surface_polynomial_workspace_per_side_bytes':2628*49*2*16,'live_objects':'two input boundary vectors + alpha; one layout/kernel; at most both q frozen output dictionaries during comparison; direct q60 oracle retains two C/D vectors at a time; gzip temporary coexists with original until verified',
        'persistent_outputs_encoding':'complex128 lossless compressed NPZ; aliases only byte-identical dtype/shape/content, individually decoded member hashes',
        'allocation_preflight':'native q30 C/o/so reserved before JIT; completed binaries archived after actor exit; 144MiB full-output reservation refused once and later passed after releasing archived cache',
        'time_formula':'T_setup + K*T_boundary + T_volume/PC/recovery/IO; K and volume costs UNKNOWN',
        'setup_q30_full_seconds':component['ladder'][-1]['measurement']['setup_seconds'],'first_q30_per_action_seconds':component['ladder'][-1]['measurement']['per_action_seconds'],
        'fixed_cost_ladder':component['ladder'],'full_qualification':'boundary only, no h/p convergence, no N=1 complete solver time'})
    dump('deployment_package_v38.json',{'schema':'task042.boundary-consumer.v38.v1','status':checked['status'],'consumer':deployed['consumer'],
        'source_hashes':json.loads((window.TMP/'qualification.json').read_text())['implementation_hashes'],'physical_contract':layout['physical_parent'],
        'ordered_mode_ref':ref(ROOT/'benchmarks/artifacts/task042/v37/IDENTITY.json'),'boundary_layout':layout['layout'],'fragment_adapters':layout['native_patch_adapter']['arrays'],
        'dtype':'complex128','MPI_qualified':1,'ports':32060,'boundary_rows':378432,'degree':6,'quadrature':30,'reference_planes_nm':{'bottom':-10,'top':130},
        'unknowns':'canonical tangential complete edge/face moments of two periodic surfaces only; no volume canonical row IDs',
        'signs':{'C':'minus outward traction paired with conjugate test, primal-dual MPC pullback','D':'conjugate modal E paired with primal trace','H_augmented':'I for physical mode amplitude unknowns','projection_denominator':'positive integral of tangential modal E norm squared at its reference plane','recover':'alpha = D*t / projection_denominator','forward':'C*(D*t/projection_denominator)','adjoint':'D^H*(C^H*t/projection_denominator)','modal_rhs':'C*alpha; C/D independent, no F=C^H assumption'},
        'entrypoint':'src.solvers.directional_boundary.DirectionalBoundaryAction, constructed via qualified make_action; opt-in only',
        'cache_identity':'new instance per full source/basis/quadrature/exact axes/Floquet/mode identity; no cache reuse by rounded coordinates; all immutable numeric arrays readonly',
        'full_solver_required_gates':['same physical/material/mode/reference plane convention','native volume extract/scatter row adapter with primal/dual dot and MPC/slave qualification','same interior affine recovery and full residual auditor','complete E/H/curl/ports/power/energy and h/p/external truncation','full N=1 time and simultaneous peak; NN20 relative qualified non-neural baseline'],
        'dot_dependency':'prior SOLVER_PACKAGE_NOT_QUALIFIED remains; no new dot fetch, matrix/factor/source consumption or ref change','global_solver_run':False,
        'shared_geometry_metadata':'two side face/row maps stored once; exact shared tile plans; no mode-by-face materialized tuples',
        'new_dataset_or_model':'NONE; fixed arbitrary complex validation inputs are not training data'})
    dump('raw_evidence_index_v38.json',{'files':raw,'large_scientific_receipts':{'inputs':component['inputs'],'outputs':component['outputs'],'oracle':oracle['outputs'],'layout':layout['layout']},
        'bridge_arrays_index':'boundary_metrics_v38.json','ignored_lossless_generated_archives':[ref(p) for p in manifests],
        'pack_script_sha256':sha(__file__),'pack_metadata_seconds':time.monotonic()-began,'scientific_arrays_immutable':True})
    tests=json.loads((window.TMP/'aux_pre_12/tests.json').read_text())
    dump('tests_v38.json',{'final_focused':tests,'serial_passed':27,'serial_failed':0,'synthetic_MPI':[2,4],'real_FE_MPI':1,'CI':'NOT_CLAIMED',
        'old_tests_reused_without_full_campaign_replay':True,'failure_and_repairs':'all source/admission/stdout/stderr/run failures retained in raw index; final metadata tests pending'})
    changed=subprocess.check_output(['git','diff','--name-only',REVIEW,'HEAD'],text=True).splitlines()
    dump('changed_files_v38.json',{'implementation':changed,'old_authorities_modified':False,'ordinary_defaults':'UNCHANGED; explicit v38 section only','audit_oracle':'original native assembly/recover path remains independent'})
    groups=[
      {'group':'production numerical/core','files':['src/solvers/directional_boundary.py'],'behavior':'new opt-in boundary decoder/action only','dependencies':['Basix native element','explicit qualified volume adapter REQUIRED'],'fresh_PDE':'NOT_RUN','merge':'not approved; consumer Gate first'},
      {'group':'reusable runner/watchdog','files':['src/runners/port_preparation.py','src/solvers/boundary_structure_scope.py','src/solvers/tiled_port_action.py'],'behavior':'namespace budget/active reader and collective error/shared plan fixes','tests':'final focused/MPI2/4','merge':'selective after review'},
      {'group':'checker/benchmark','files':['benchmarks/check_boundary_witness.py','benchmarks/check_boundary_structure.py','benchmarks/archive_jit_cache.py','benchmarks/qualify_port_preparation.py'],'behavior':'strict complete inventory and raw independent recomputation; lossless own JIT cleanup','tests':'negative inventory/hash/counter/physics fixtures','merge':'selective after dependencies'},
      {'group':'compact evidence/docs','files':['docs/task042_neural_coarse_inverse/response_v38.md','docs/task042_neural_coarse_inverse/outcomes/directional_boundary_structure_v38.md','docs/task042_neural_coarse_inverse/outcomes/records/*v38*'],'behavior':'no numerical behavior','merge':'retain negative history'},
      {'group':'research-only','files':['src/solvers/boundary_structure_study.py','input/task042_neural_coarse_inverse/v38_*.dat'],'behavior':'one frozen campaign; closed entries not production','merge':'research branch'},
      {'group':'do-not-merge','files':['tmp/task042/v38','benchmarks/artifacts/task042/v38','results/task042/task042_v38_*'],'behavior':'large raw data/caches remain ignored','merge':'never tracked'}]
    dump('selective_merge_manifest_v38.json',{'approval':'NOT_APPROVED','dependency_groups':groups,'ordinary_solver_default_changed':False})
    print(json.dumps({'status':checked['status'],'charged_before_pack':window.charged_wall(),'peak':max(r['peak_bytes'] for r in rows),'raw_versions':len(raw),'storage_before_docs_bytes':snapshot['new_bytes']}),flush=True)

if __name__=='__main__':pack()
