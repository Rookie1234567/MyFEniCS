import ast,gzip,hashlib,json,math,struct,subprocess,time,zipfile,xml.etree.ElementTree as ET
from pathlib import Path
ROOT=Path.cwd();D=ROOT/'docs/task042_neural_coarse_inverse';R=D/'outcomes/records';O=ROOT/'tmp/task042/review_v36';HEAD='6166ad27e36c08408f81d4bba07d2f6b035e9f2b';BASE='cf0896e57f9f16970e5af6b55ad14920ab4c7815'
def git(*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a])
def sha(b):return hashlib.sha256(b).hexdigest()
def read(n):return json.loads((R/n).read_text())
assert git('rev-parse','HEAD').decode().strip()==HEAD
raw={};versions={};rawidx=read('raw_evidence_index_v38.json')
for x in rawidx['files']:
 b=(ROOT/x['gzip']).read_bytes();assert sha(b)==x['gzip_sha256'];v=gzip.decompress(b);assert sha(v)==x['sha256'] and len(v)==x['bytes'];raw[x['original_path']]=v;versions.setdefault(x['original_path'],[]).append(v)
originals=0;changed=[]
for p,vs in versions.items():
 if Path(p).exists():
  if Path(p).read_bytes() in vs:originals+=1
  else:changed.append(p)
protected=[];history=[];append={'README.md','outcomes/summary.md','outcomes/test_summary.md','outcomes/changed_files.md'}
for p in git('ls-tree','-r','--name-only',BASE,str(D.relative_to(ROOT))).decode().splitlines():
 old=git('show',BASE+':'+p);now=(ROOT/p).read_bytes();rel=str(Path(p).relative_to(D.relative_to(ROOT)))
 if rel in append:assert now.endswith(old),p
 else:assert now==old,p;protected.append(p)
 if Path(p).name.startswith(('review_report_v','response_v')):history.append(p)
compiled=[]
for p in git('diff','--name-only',BASE,HEAD).decode().splitlines():
 if p.endswith('.py'):compile((ROOT/p).read_text(),p,'exec');compiled.append(p)
deploy=read('deployment_package_v38.json');source=deploy['source_hashes'];source_checks={}
for p,h in source.items():
 assert sha(git('show','6e4693620dc87802b44361da64620bf5d622b271:'+p))==h,p
 source_checks[p]={'deployment_sha256':h,'final_sha256':sha((ROOT/p).read_bytes()),'final_differs':sha((ROOT/p).read_bytes())!=h}
stages={};stage_sources={}
for name,x in read('run_index_v38.json')['parents'].items():
 b=Path(x['path']).read_bytes();assert sha(b)==x['sha256'];stages[name]=json.loads(b);s=stages[name];stage_sources[name]=s['source_sha'];assert git('merge-base','--is-ancestor',s['source_sha'],HEAD)==b''
cost=read('resource_costs_v38.json');supervisions=[];formal_source_checks=[]
for row in cost['runs']:
 folder=Path(row['directory']);manifest=json.loads(raw[str(folder/'run_manifest.json')]);
 if manifest['stage'].removeprefix('V38-') in ('BRIDGE','LAYOUT','COMPONENT','ORACLE','CHECK','DEPLOY'):
  for fp,h in manifest['implementation_hashes'].items():assert sha(git('show',manifest['source_sha']+':'+fp))==h,(manifest['stage'],fp)
  formal_source_checks.append(dict(stage=manifest['stage'],source_sha=manifest['source_sha'],path=str(folder/'run_manifest.json'),hashes=len(manifest['implementation_hashes'])))
 p=folder/'supervision/summary.json';s=json.loads(raw[str(p)]);samples=[json.loads(b) for b in raw[str(folder/'supervision/resources.jsonl')].splitlines()]
 assert len(samples)==s['samples']
 for v in samples:
  assert v['rss_bytes']==sum(m['rss_bytes'] for m in v['members']);assert v['swap_bytes']==sum(m['swap_bytes'] for m in v['members'])
 assert max(v['rss_bytes'] for v in samples)==s['sampled_process_tree_rss_peak_bytes']==row['peak_bytes']
 assert max(v['swap_bytes'] for v in samples)==0 and s['descendants_cleared'];assert s['elapsed_seconds']==row['elapsed_seconds']
 supervisions.append(dict(role=row['role'],path=str(p),seconds=s['elapsed_seconds'],peak=s['sampled_process_tree_rss_peak_bytes'],samples=len(samples),status=s['classification']))
probes=[json.loads(p.read_text()) for p in (ROOT/'tmp/task042/v38').glob('probe_*.json')];sumruns=sum(s['seconds'] for s in supervisions);sumprobes=sum(p['elapsed_seconds'] for p in probes);total=sumruns+sumprobes+3
assert math.isclose(total,cost['charged_seconds'],rel_tol=1e-14)
book=json.loads((ROOT/'tmp/task042/v38/ledger.json').read_text());assert book['closed'] and book['active'] is None and len(book['runs'])==len(supervisions)
admissions=[]
for p in probes:
 d=json.loads(raw[p['receipt_path']]);fr={int(k):v for k,v in d['cpu_busy_fractions'].items()};reasons={}
 for key,b in d['cpu_ticks_before'].items():
  a=d['cpu_ticks_after'][key];assert abs(1-(a[3]-b[3]+a[4]-b[4])/max(sum(a)-sum(b),1)-fr[int(key)])<1e-15
 for tid,a in d['thread_ticks_after'].items():
  b=d['thread_ticks_before'].get(tid)
  if b and a[0]==b[0]:assert d['thread_delta_ticks'][tid]==a[1]-b[1]
 for cpu,v in fr.items():
  if v>.05:reasons.setdefault(cpu,[]).append('sample_busy_fraction_gt_0.05')
 for proc in d['neighbor_processes']:
  for t in proc['threads']:
   if len(t['affinity'])<=16:
    for cpu in t['affinity']:reasons.setdefault(cpu,[]).append('narrow_thread_affinity:'+str(t['tid']))
   elif d['thread_delta_ticks'].get(str(t['tid']),1)>0:reasons.setdefault(t['cpu'],[]).append('active_wide_thread:'+str(t['tid']))
 decisions=[dict(**t,eligible=not any(c in reasons for c in t['siblings']),excluded_siblings={str(c):reasons[c] for c in t['siblings'] if c in reasons}) for t in d['topology']]
 assert decisions==d['cpu_decisions'];assert [t['cpu'] for t in decisions if t['eligible']]==d['candidate_cpus'];assert d['selected_cpu'] in d['candidate_cpus'];admissions.append(dict(path=p['receipt_path'],cpu=d['selected_cpu']))
# Read stored array bytes; no FE, BLAS, NumPy, matrix action or solve imports.
receipts={}
def walk(v):
 if isinstance(v,dict):
  if all(k in v for k in ('path','sha256','members')) and str(v['path']).endswith('.npz'):receipts[v['path']]=v
  for w in v.values():walk(w)
 elif isinstance(v,list):
  for w in v:walk(w)
for v in [stages,read('boundary_metrics_v38.json'),rawidx,deploy]:walk(v)
def payload(receipt,name):
 aliases=receipt.get('aliases',{});seen=set()
 while name in aliases:
  assert name not in seen;seen.add(name);name=aliases[name]
 with zipfile.ZipFile(receipt['path']) as z:b=z.read(name+'.npy')
 assert b[:6]==b'\x93NUMPY';length=2 if b[6]==1 else 4;off=8+length;size=int.from_bytes(b[8:off],'little');meta=ast.literal_eval(b[off:off+size].decode().strip());return meta,b[off+size:]
array_checks=[]
for path,receipt in receipts.items():
 p=Path(path);assert sha(p.read_bytes())==receipt['sha256'];aliases=receipt.get('aliases',{})
 with zipfile.ZipFile(p) as z:assert set(z.namelist())=={k+'.npy' for k in receipt['members'] if k not in aliases}
 for name,m in receipt['members'].items():
  meta,b=payload(receipt,name);assert not meta['fortran_order'];assert list(meta['shape'])==m['shape'] and meta['descr']==m['dtype'];assert sha(b)==m['sha256'],(path,name)
 array_checks.append(dict(path=path,members=len(receipt['members']),stored_members=len(receipt['members'])-len(aliases),bytes=p.stat().st_size))
# Strengthen the independent oracle link: only compare 12 already-saved complex entries.
oracle=stages['ORACLE'];mode_indices=[m['original_index'] if isinstance(m,dict) else m for m in oracle['modes']]
def complex_values(r,n):
 m,b=payload(r,n);assert m['descr']=='<c16';return [complex(x,y) for x,y in struct.iter_unpack('<dd',b)]
links=[]
for label in ('a','b'):
 a=complex_values(stages['COMPONENT']['outputs'],'q30_'+label+'_amplitudes');b=complex_values(oracle['outputs'],label+'_amplitudes');c=complex_values(oracle['outputs'],'new_'+label+'_amplitudes');assert len(b)==len(c)==12
 for i,k in enumerate(mode_indices):
  den=abs(b[i]);num=abs(a[k]-b[i]);ratio=num/den if den else None
  assert num==0 if den==0 else ratio<=1e-10
  links.append(dict(input=label,original_index=k,numerator=num,denominator=den,relative=ratio,full_vs_selected_new_absolute=abs(a[k]-c[i])))
checks=read('component_checker_v38.json');scalars=[]
for section in ('checks','fullchecks'):
 for c in checks[section]:
  if 'numerator' not in c or 'denominator' not in c:continue
  num=c['numerator'];den=c['denominator'];passed=num==0 if den==0 else num/den<=1e-10
  assert c['passed']==passed
  if den and c.get('relative') is not None:assert math.isclose(c['relative'],num/den,rel_tol=1e-14)
  scalars.append(c)
xml=[]
for p,b in raw.items():
 if p.endswith('pytest.xml'):
  t=ET.fromstring(b);suite=list(t)[0] if t.tag=='testsuites' else t;xml.append(dict(path=p,tests=int(suite.get('tests')),failures=int(suite.get('failures')),errors=int(suite.get('errors'))))
archives={};start=time.monotonic()
for entry in rawidx['ignored_lossless_generated_archives']:
 p=Path(entry['path']);b=p.read_bytes();assert sha(b)==entry['sha256'];m=json.loads(b)
 for row in m['members']:
  if row['archive'] in archives:continue
  archive=Path(row['archive']);assert archive.stat().st_size==row['archive_bytes'];h=hashlib.sha256();size=0
  with gzip.open(archive,'rb') as f:
   while b:=f.read(2**20):h.update(b);size+=len(b)
  assert h.hexdigest()==row['sha256'] and size==row['bytes'];archives[row['archive']]=dict(raw_bytes=size,compressed_bytes=row['archive_bytes'],sha256=h.hexdigest())
x=dict(reviewed_head=HEAD,previous_review=BASE,scope='Read-only stdlib source/metadata/resource/hash audit; 24 stored complex amplitude scalar comparisons; no FE import, vector operator, factor, solve or new numerical experiment',raw_archives_verified=len(rawidx['files']),current_originals_matching_archived_version=originals,unmatched_current_originals=changed,protected_files=len(protected),history_files=history,compiled=compiled,source_hashes=source_checks,stage_sources=stage_sources,formal_source_checks=formal_source_checks,supervisions=supervisions,CPU_admissions=admissions,costs=dict(supervised=sumruns,probes=sumprobes,bootstrap=3,total=total),array_byte_verification=array_checks,scalar_ratio_checks=len(scalars),independent_oracle_to_full_output=links,pytest_snapshots=xml,generated_and_fixture_archives=dict(members=archives,total_raw_bytes=sum(v['raw_bytes'] for v in archives.values()),total_compressed_bytes=sum(v['compressed_bytes'] for v in archives.values()),verification_seconds=time.monotonic()-start),repository_index_sha256=sha((O/'repository_index.json').read_bytes()),dot_head='077ec9c8386c976da232093779279fb9d1a93033',source_changes=False,qualification=['NATIVE_P6_PERIODIC_PATCH_BRIDGE_QUALIFIED','TARGET_BOUNDARY_ACTION_QUALIFIED_AT_FROZEN_Q'],limitations=['not a whole-repository line-by-line semantic audit','MPI1 only for actual native FE','target volume adapter/recovery/native PDE/2TB48h/NN20% not qualified','audit human and ordinary IO cost not supervised'])
(O/'independent_checks.json').write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(raw=len(rawidx['files']),originals=originals,changed=changed,protected=len(protected),history=len(history),compiled=len(compiled),costs=x['costs'],arrays=len(array_checks),members=sum(v['members'] for v in array_checks),ratio_checks=len(scalars),oracle_link_max=max(v['relative'] for v in links),archives=len(archives),archive_raw=x['generated_and_fixture_archives']['total_raw_bytes'],xml=xml),indent=2))
