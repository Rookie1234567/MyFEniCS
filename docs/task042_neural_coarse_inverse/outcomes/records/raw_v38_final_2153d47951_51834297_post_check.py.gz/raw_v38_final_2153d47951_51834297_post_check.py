"""Final metadata/doc checks. No new FE numerical experiment."""
import gzip
import hashlib
import json
import re
import subprocess
import sys
import time
from pathlib import Path
from src.runners.task042_shared import write_json
from src.solvers.boundary_structure_scope import ROOT,window,implementation_hashes

R=ROOT/'docs/task042_neural_coarse_inverse/outcomes/records'; T=window.TMP
REVIEW='cf0896e57f9f16970e5af6b55ad14920ab4c7815'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(n,x):write_json(R/n,x)

def main():
    began=time.monotonic()
    tests=json.loads((T/'aux_pre_12/tests.json').read_text())
    if tests['implementation_hashes']!=implementation_hashes():raise ValueError('final tested source changed')
    for p in tests['compiled']:
        if p.endswith('.py'):compile((ROOT/p).read_bytes(),p,'exec')
    py=[p for p in implementation_hashes() if p.endswith('.py') and p!='scripts/run_case.py']
    ruff='/home/fenics/Projects/Metrology/.venv/bin/ruff'
    lint=subprocess.run([ruff,'check',*py],capture_output=True,text=True)
    (T/'final_ruff.stdout').write_text(lint.stdout);(T/'final_ruff.stderr').write_text(lint.stderr)
    if lint.returncode:raise ValueError('final Ruff failed')
    old=subprocess.check_output(['git','show',REVIEW+':scripts/run_case.py'],text=True)
    new=(ROOT/'scripts/run_case.py').read_text()
    def signatures(code):
        result=subprocess.run([ruff,'check','--output-format=json','--stdin-filename','scripts/run_case.py','-'],input=code,capture_output=True,text=True)
        lines=code.splitlines()
        return sorted([r['code'],r['message'],'\n'.join(lines[r['location']['row']-1:r['end_location']['row']])] for r in json.loads(result.stdout))
    oldsig,newsig=signatures(old),signatures(new)
    if oldsig!=newsig:raise ValueError('new dispatcher lint findings')
    dump('dispatcher_lint_v38.json',{'baseline':REVIEW,'exact_old_source_spans_unchanged':True,'old_count':len(oldsig),'new_count':len(newsig),'unrelated_cleanup':False})
    allow=['docs/task042_neural_coarse_inverse/README.md','docs/task042_neural_coarse_inverse/outcomes/summary.md','docs/task042_neural_coarse_inverse/outcomes/test_summary.md','docs/task042_neural_coarse_inverse/outcomes/changed_files.md','docs/development_progress.md','docs/development_model_registry.md']
    hist=[]
    for p in allow:
        original=subprocess.check_output(['git','show',REVIEW+':'+p])
        current=(ROOT/p).read_bytes()
        if not current.endswith(original):raise ValueError('historical suffix changed '+p)
        hist.append({'path':p,'original_sha256':hashlib.sha256(original).hexdigest(),'bytes':len(original),'suffix_exact':True})
    changed=subprocess.check_output(['git','diff','--name-only',REVIEW],text=True).splitlines()
    protected=[p for p in changed if '/review_report_' in p or '/response_' in p or p.endswith('task.md') or p.endswith('AGENTS.md')]
    if protected:raise ValueError('old authority changed '+str(protected))
    docs=[ROOT/'docs/task042_neural_coarse_inverse/response_v38.md',ROOT/'docs/task042_neural_coarse_inverse/outcomes/directional_boundary_structure_v38.md',ROOT/'docs/task042_neural_coarse_inverse/review_report_v35.md']+[ROOT/p for p in allow]
    checked=[]
    for p in docs:
        text=p.read_text().split('<!-- V38-LATEST-END -->',1)[0]
        fence=False;width=None;tables=0;links=0;math=0
        for line in text.splitlines():
            if line.startswith('```'):
                if line=='```math':math+=1
                fence=not fence;width=None;continue
            if fence:continue
            if '$$' in line or '\\[' in line:raise ValueError('unsupported new math '+str(p))
            if line.strip().startswith('|'):
                n=len(re.split(r'(?<!\\)\|',line))-2
                if width is not None and width!=n:raise ValueError('table columns '+str(p))
                if width is None:tables+=1
                width=n
            else:width=None
        if fence:raise ValueError('unclosed fence '+str(p))
        for target in re.findall(r'\]\(([^)]+)\)',text):
            if target.startswith(('http://','https://','#')):continue
            part=target.split('#')[0]
            if part and not (p.parent/part).exists():raise ValueError('missing link '+part)
            links+=1
        checked.append({'path':str(p.relative_to(ROOT)),'tables':tables,'math_blocks':math,'local_links':links,'passed':True})
    raw=json.loads((R/'raw_evidence_index_v38.json').read_text())
    for v in raw['files']:
        p=ROOT/v['gzip'];data=gzip.decompress(p.read_bytes())
        if sha(p)!=v['gzip_sha256'] or len(data)!=v['bytes'] or hashlib.sha256(data).hexdigest()!=v['sha256']:raise ValueError('raw gzip identity')
    commands=[]
    for modules in [('src.test.test_26_documentation_contract','src.test.test_24_repository_work_principles'),('src.test.test_183_development_model_registry_markdown',)]:
        command=[sys.executable,'-m','unittest','-q',*modules]
        r=subprocess.run(command,capture_output=True,text=True)
        i=len(commands);(T/f'docs_check{i}.stdout').write_text(r.stdout);(T/f'docs_check{i}.stderr').write_text(r.stderr)
        commands.append({'command':command,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
        if r.returncode:raise ValueError('documentation regression failure')
    subprocess.run(['git','diff','--check'],check=True)
    dump('documentation_checks_v38.json',{'github_visual':'NOT_VERIFIED','exact_review_url':'https://github.com/Rookie1234567/MyFEniCS/blob/'+REVIEW+'/docs/task042_neural_coarse_inverse/review_report_v35.md','web_attempt':'Cache miss on precise page; no visual evidence','local_markdown':checked,'historical_suffix':hist,'protected_paths_modified':protected,'commands':commands,'CI':'NOT_CLAIMED'})
    record=json.loads((R/'tests_v38.json').read_text());record.update(final_metadata_source_sha=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),documentation_commands=commands,Ruff_returncode=lint.returncode,dispatcher_baseline_findings_preserved=len(oldsig));dump('tests_v38.json',record)
    dump('evidence_checks_v38.json',{'source_sha':record['final_metadata_source_sha'],'raw_gzip_versions_checked':len(raw['files']),'tested_hashes_equal':True,'old_authorities_unchanged':True,'metadata_elapsed_seconds':time.monotonic()-began,'fresh_PDE':False})
    print(json.dumps({'archives':len(raw['files']),'documents':len(checked),'Ruff':'PASS','document_commands':len(commands),'history':'UNCHANGED'}),flush=True)

if __name__=='__main__':main()
