import ast,gzip,hashlib,json,math,struct,subprocess,zipfile
from pathlib import Path
ROOT=Path.cwd();D=ROOT/'docs/task042_neural_coarse_inverse';R=D/'outcomes/records'
HEAD='3259bf67fb622a9b43268602e07456685763e37d';BASE='93326fd0e4edc078c51da9af71bdc6f870e93c61'
def git(*args):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*args])
def sha(x):return hashlib.sha256(x).hexdigest()
def read(n):return json.loads((R/n).read_text())
def near(a,b):return math.isclose(a,b,rel_tol=2e-12,abs_tol=1e-10)
assert git('rev-parse','HEAD').decode().strip()==HEAD
raw_index=read('raw_evidence_index_v47.json');raw={};versions={}
for row in raw_index['files']:
 archive=(ROOT/row['archive_path']).read_bytes()
 assert sha(archive)==row['archive_sha256'] and len(archive)==row['archive_bytes'],row['archive_path']
 value=gzip.decompress(archive)
 assert sha(value)==row['sha256'] and len(value)==row['bytes'],row['path']
 path=str((ROOT/row['path']).resolve());raw[path]=value;versions.setdefault(path,[]).append(value)
matched=[];unmatched=[];missing=[]
for path,rows in versions.items():
 p=Path(path)
 if not p.exists():missing.append(path)
 elif p.read_bytes() in rows:matched.append(path)
 else:unmatched.append({'path':path,'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size})
delivery=read('delivery_index_v47.json');records=[]
for row in delivery['records']:
 value=Path(row['path']).read_bytes();assert sha(value)==row['sha256'] and len(value)==row['bytes'],row['path'];records.append(row['path'])
tests=read('tests_v47.json');compiled=[]
for path,h in tests['implementation_hashes'].items():
 value=(ROOT/path).read_bytes();assert sha(value)==h and sha(git('show',tests['source_sha']+':'+path))==h,path
 if path.endswith('.py'):compile(value,path,'exec');compiled.append(path)
protected=[];append={'README.md','outcomes/summary.md','outcomes/test_summary.md','outcomes/changed_files.md'}
for line in git('ls-tree','-r',BASE,str(D.relative_to(ROOT))).decode().splitlines():
 meta,path=line.split('\t');oid=meta.split()[2];value=(ROOT/path).read_bytes();rel=str(Path(path).relative_to(D.relative_to(ROOT)))
 if rel in append:assert value.endswith(git('show',BASE+':'+path)),path
 else:assert hashlib.sha1(b'blob '+str(len(value)).encode()+b'\0'+value).hexdigest()==oid,path;protected.append(path)
for path in ('docs/development_progress.md','docs/development_model_registry.md'):
 assert (ROOT/path).read_bytes().endswith(git('show',BASE+':'+path)),path
inventory=read('array_inventory_v47.json');members=0;payload=0;packages=[]
for packet in inventory['packages']:
 p=Path(packet['path']);digest=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(2**20),b''):digest.update(chunk)
 assert digest.hexdigest()==packet['sha256'],p
 aliases=packet.get('aliases',{});assert not aliases
 with zipfile.ZipFile(p) as z:
  assert {n.removesuffix('.npy') for n in z.namelist()}==set(packet['members']) and len(z.namelist())==len(packet['members'])
  for name,meta in packet['members'].items():
   with z.open(name+'.npy') as f:
    magic=f.read(8);assert magic[:6]==b'\x93NUMPY'
    length=struct.unpack('<H' if magic[6]==1 else '<I',f.read(2 if magic[6]==1 else 4))[0]
    header=ast.literal_eval(f.read(length).decode());assert not header['fortran_order'] and list(header['shape'])==meta['shape'] and header['descr']==meta['dtype'],name
    h=hashlib.sha256();size=0
    for chunk in iter(lambda:f.read(2**20),b''):h.update(chunk);size+=len(chunk)
    assert h.hexdigest()==meta['sha256'],name
    members+=1;payload+=size
 packages.append({'path':str(p.relative_to(ROOT)),'members':len(packet['members']),'sha256':packet['sha256']})
idx=read('run_index_v47.json');cost=read('resource_costs_v47.json');runs=[];probes=[];probe_by={};source_differences=[]
for p in (ROOT/'tmp/task042/v47').glob('probe_*.json'):
 value=p.read_bytes();assert value in versions[str(p.resolve())];v=json.loads(value);probes.append(v)
 folder=str(Path(v['receipt_path']).parent.resolve());probe_by[folder]=probe_by.get(folder,0)+v['elapsed_seconds']
 source=Path(v['receipt_path']).read_bytes();assert source in versions[str(Path(v['receipt_path']).resolve())]
 a=json.loads(source);assert a['selected_cpu'] in a['candidate_cpus']
 for name,before in a['cpu_ticks_before'].items():
  after=a['cpu_ticks_after'][name];fraction=1-(after[3]-before[3]+after[4]-before[4])/max(sum(after)-sum(before),1)
  assert near(fraction,a['cpu_busy_fractions'][name])
for row in idx['runs']:
 folder=Path(row['directory']);summ=Path(row['summary']['path']).read_bytes();manifest=Path(row['manifest']['path']).read_bytes()
 assert sha(summ)==row['summary']['sha256'] and sha(manifest)==row['manifest']['sha256']
 s=json.loads(summ);m=json.loads(manifest)
 samples=[json.loads(v) for v in raw[str(folder/'supervision/resources.jsonl')].splitlines()]
 for v in samples:
  assert v['rss_bytes']==sum(q['rss_bytes'] for q in v['members'])
  assert v['swap_bytes']==sum(q['swap_bytes'] for q in v['members'])==0
 assert len(samples)==s['samples'] and s['descendants_cleared'] and s['elapsed_seconds']==row['seconds']
 assert max(v['rss_bytes'] for v in samples)==row['peak_bytes']
 gaps=[b['elapsed_seconds']-a['elapsed_seconds'] for a,b in zip(samples,samples[1:])]
 extra=max(0,row['launch_wall_seconds']-row['seconds']-probe_by.get(str(folder),0))
 if row['role'] in ('DATA','ORACLE','CHECK','ANALYSIS') and s['leader_exit_code']==0:
  if row['formal_input'] is not None:assert row['source_sha']==idx['actual_scientific_sources'][row['role']]
  for path,h in m.get('implementation_hashes',{}).items():
   if sha(git('show',row['source_sha']+':'+path))!=h:
    final_matches=sha(git('show',idx['current_delivery_code']+':'+path))==h
    source_differences.append({'run':row['directory'],'launch_HEAD':row['source_sha'],'path':path,'recorded_sha256':h,'matches_final_code':final_matches,'final_code':idx['current_delivery_code']})
    assert row['formal_input'] is None and final_matches
 runs.append({'role':row['role'],'source_sha':row['source_sha'],'seconds':row['seconds'],'exit':s['leader_exit_code'],'peak':row['peak_bytes'],'samples':len(samples),'max_gap':max(gaps,default=0),'extra':extra,'actions':row['counts']['upper']['actions']})
supervision=math.fsum(x['seconds'] for x in runs);probe=math.fsum(x['elapsed_seconds'] for x in probes);launcher=math.fsum(x['extra'] for x in runs)
assert near(supervision,cost['supervised_seconds']) and near(probe,cost['probe_seconds']) and near(launcher,cost['nonnested_launcher_seconds'])
fee=cost['metadata_fee_final'];fee_current=Path(fee['receipt']['path']).read_bytes();assert sha(fee_current)==fee['receipt']['sha256']
setup_receipt=(ROOT/'tmp/task042/v47/metadata_setup_receipt.json').read_bytes();assert setup_receipt in versions[str(ROOT/'tmp/task042/v47/metadata_setup_receipt.json')];setup_seconds=json.loads(setup_receipt)['seconds'];lower=supervision+probe+launcher+setup_seconds+fee['measured_metadata_seconds'];upper=lower+fee['pre_actor_scope_error_charged_upper_seconds']+fee['final_metadata_write_reserved_upper_seconds']
print('FEE_AUDIT',supervision,probe,launcher,lower,upper,flush=True)
assert near(lower,cost['known_loaded_lower_seconds']) and near(upper,cost['known_loaded_seconds'])
assert sum(r['actions'] for r in runs)==cost['original_actions']['actions']==146
assert max(r['peak'] for r in runs)==cost['peak_bytes'] and near(max(r['max_gap'] for r in runs),cost['max_sampling_gap_seconds'])
book=json.loads((ROOT/'tmp/task042/v47/ledger.json').read_text());assert book['closed'] and book['active'] is None
def stage(name):
 p=json.loads((ROOT/'benchmarks/artifacts/task042/v47'/f'{name}.json').read_text());b=Path(p['path']).read_bytes();assert sha(b)==p['sha256'];return json.loads(b)
oracle=stage('ORACLE');checker=stage('CHECK');data=stage('DATA');rows=oracle['results']
assert len(rows)==len(checker['outcomes'])==40 and not oracle['training_admitted'] and not checker['training_admitted']
summary=[]
for fraction in (0.5,0.8):
 rr=[r for r in rows if r['fraction']==fraction];assert len(rr)==20
 counts={k:sum(r['metrics'][k]<=tol for r in rr) for k,tol in [('eta',1e-4),('trace_error',1e-4),('rho',1e-6)]}
 for r in rr:
  v=r['metrics'];assert near(v['eta']**2,v['omitted_energy']/v['coefficient_energy'])
  assert near(v['rho'],v['residual_numerator']/v['original_rhs_denominator'])
  c=next(c for c in checker['outcomes'] if (c['split'],c['sample'],c['fraction'])==(r['split'],r['sample'],fraction))
  assert all(c['identity_checks'].values()) and all(near(c[k],v[k]) for k in ('eta','trace_error','rho'))
 summary.append({'fraction':fraction,'counts':counts,'range':{k:[min(r['metrics'][k] for r in rr),max(r['metrics'][k] for r in rr)] for k in ('eta','trace_error','rho')},'omitted_energy_range':[min(r['metrics']['omitted_energy'] for r in rr),max(r['metrics']['omitted_energy'] for r in rr)]})
out={'reviewed_HEAD':HEAD,'prior_review_HEAD':BASE,'archive_count':len(raw_index['files']),'current_paths_matched':len(matched),'unmatched':unmatched,'missing':missing,'delivery_records':records,'compiled_python_files':compiled,'protected_old_files':len(protected),'array_packages':packages,'array_member_count':members,'array_raw_bytes_hashed':payload,'heldout_scope':'Stored bytes/header/hash only; no numeric decoding, training, selection or heldout scientific audit by reviewer','runs':runs,'source_differences':source_differences,'raw_scalar_recomputation':summary,'mapping_pairings':[{k:v for k,v in p.items() if k!='arrays'} for p in data['pairings']],'bridge_checks':data['bridge_checks'],'supervised':supervision,'probe':probe,'launcher':launcher,'lower':lower,'upper':upper,'history_lower_with_V47':cost['history_known_loaded_lower_seconds']+lower,'resource_peak':cost['peak_bytes'],'max_gap':max(r['max_gap'] for r in runs),'closed':True,'review_new_A_AH_FE_training_solves':0,'review_IO_cost':'unmeasured; no performance claim'}
Path('/tmp/task042_review45_audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k in ('archive_count','current_paths_matched','unmatched','missing','protected_old_files','array_member_count','array_raw_bytes_hashed','raw_scalar_recomputation','lower','upper','history_lower_with_V47','resource_peak','max_gap')},ensure_ascii=False,indent=2))
