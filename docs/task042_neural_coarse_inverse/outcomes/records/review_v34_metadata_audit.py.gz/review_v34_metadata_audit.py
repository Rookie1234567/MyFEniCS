import json,gzip,hashlib,subprocess,math,re
from pathlib import Path
ROOT=Path('/home/fenics/Projects/NN-Lab');D=ROOT/'docs/task042_neural_coarse_inverse';R=D/'outcomes/records';O=ROOT/'tmp/task042/review_v34';HEAD='bc2efb6e9013ceeb3e34d4c295a21db8b054c837';BASE='cc5d9823a66fb5090618705114093998a647e40c'
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT)
def sha(b):return hashlib.sha256(b).hexdigest()
def read(n):return json.loads((R/n).read_text())
assert git('rev-parse','HEAD').decode().strip()==HEAD
raw={};versions={}
for x in read('raw_evidence_index_v36.json')['files']:
 b=(ROOT/x['archive_path']).read_bytes();assert sha(b)==x['archive_sha256'];v=gzip.decompress(b);assert sha(v)==x['source_sha256'] and len(v)==x['source_bytes'];versions.setdefault(x['original_path'],[]).append(v);raw[x['original_path']]=v
 # An original may legitimately have several immutable archived snapshots.
 if Path(x['original_path']).exists() and Path(x['original_path']).read_bytes()==v:pass
final_original_checks=0
for p,vs in versions.items():
 if Path(p).exists():
  now=Path(p).read_bytes()
  if now in vs:final_original_checks+=1
  else:raise AssertionError(('unarchived final original',p))
idx=read('run_index_v36.json');verified={}
for p,h in idx['source_files'].items():assert sha((ROOT/p).read_bytes())==h;verified[p]=h
stages={}
for name,x in idx['published'].items():
 b=Path(x['path']).read_bytes();assert sha(b)==x['sha256'];stages[name]=json.loads(b)
protected=[];history=[]
append={'README.md','outcomes/summary.md','outcomes/test_summary.md','outcomes/changed_files.md'}
for p in git('ls-tree','-r','--name-only',BASE,str(D.relative_to(ROOT))).decode().splitlines():
 old=git('show',BASE+':'+p);now=(ROOT/p).read_bytes();rel=str(Path(p).relative_to(D.relative_to(ROOT)))
 if rel in append:assert now.endswith(old),p
 else:assert now==old,p;protected.append(p)
 if Path(p).name.startswith(('review_report_v','response_v')):history.append(p)
compiled=[]
for p in git('diff','--name-only',BASE,HEAD).decode().splitlines():
 if p.endswith('.py'):compile((ROOT/p).read_text(),p,'exec');compiled.append(p)
book=json.loads((ROOT/'tmp/task042/v36/ledger.json').read_text());assert book['closed'] and book['active'] is None and len(book['runs'])==16
cost=read('resource_costs_v36.json');supervisions=[]
for row in cost['runs']:
 folder=Path(row['directory']);p=folder/'supervision/summary.json'
 if not str(p) in raw:p=folder/'run_summary.json'
 s=json.loads(raw[str(p)]);samples=[json.loads(b) for b in raw[str(folder/'supervision/resources.jsonl')].splitlines()]
 assert len(samples)==s['samples']
 for v in samples:
  assert v['rss_bytes']==sum(m['rss_bytes'] for m in v['members']);assert v['swap_bytes']==sum(m['swap_bytes'] for m in v['members'])
 assert max(v['rss_bytes'] for v in samples)==s['sampled_process_tree_rss_peak_bytes']==row['sampled_tree_peak_bytes']
 assert max(v['swap_bytes'] for v in samples)==0 and s['descendants_cleared']
 assert s['elapsed_seconds']==row['supervisor_seconds'];supervisions.append(dict(stage=row['stage'],path=str(p),seconds=s['elapsed_seconds'],peak=s['sampled_process_tree_rss_peak_bytes'],samples=len(samples),status=s['classification']))
probes=[json.loads(p.read_text()) for p in (ROOT/'tmp/task042/v36').glob('probe_*.json')];sumruns=sum(s['seconds'] for s in supervisions);sumprobes=sum(p['elapsed_seconds'] for p in probes);total=sumruns+sumprobes+0.326941663
assert math.isclose(total,cost['charged_loaded_wall_seconds'],rel_tol=1e-14)
admissions=[]
for p in probes:
 d=json.loads(raw[p['receipt_path']]);fr={int(k):v for k,v in d['cpu_busy_fractions'].items()};reasons={}
 for key,b in d['cpu_ticks_before'].items():
  a=d['cpu_ticks_after'][key];assert abs(1-(a[3]-b[3]+a[4]-b[4])/max(sum(a)-sum(b),1)-fr[int(key)])<1e-15
 for tid,a in d['thread_ticks_after'].items():
  b=d['thread_ticks_before'].get(tid)
  if b and a[0]==b[0]:assert d['thread_delta_ticks'][tid]==a[1]-b[1]
 for cpu,v in fr.items():
  if v>.05:reasons.setdefault(cpu,[]).append('sample_busy_fraction_gt_0.05')
 for proc in d['neighbor_processes']:
  for t in proc['threads']:
   if len(t['affinity'])<=16:
    for cpu in t['affinity']:reasons.setdefault(cpu,[]).append('narrow_thread_affinity:'+str(t['tid']))
   elif d['thread_delta_ticks'].get(str(t['tid']),1)>0:reasons.setdefault(t['cpu'],[]).append('active_wide_thread:'+str(t['tid']))
 decisions=[dict(**t,eligible=not any(c in reasons for c in t['siblings']),excluded_siblings={str(c):reasons[c] for c in t['siblings'] if c in reasons}) for t in d['topology']]
 assert decisions==d['cpu_decisions'];assert [t['cpu'] for t in decisions if t['eligible']]==d['candidate_cpus'];assert d['selected_cpu'] in d['candidate_cpus'];admissions.append(dict(path=p['receipt_path'],cpu=d['selected_cpu']))
a=stages['COMPONENT'];assert a['status']=='PORT_COMPONENT_QUALIFIED_ON_MICRO';assert all(a[k]==0 for k in ('volume_actions','new_LU','new_QR','KSP','reference_read','seven_block_factors_read'))
for x in a['checks']:
 if 'numerator' in x:assert (x['numerator']==0 if x['denominator']==0 else x['numerator']/x['denominator']<=1e-10)
 if 'max_absolute' in x:assert x['max_absolute']<=1e-10
stats=a['provider_stats'];assert stats['loads']==440 and stats['evictions']==438 and stats['created_live_peak']==2 and stats['cache_peak_bytes']==82960
inv=stages['INVENTORY'];c=inv['capacity'];nx,ny,nz=c['axis_cells'];p=6;N=nx*ny*nz;E=nx*(ny+1)*(nz+1)+(nx+1)*ny*(nz+1)+(nx+1)*(ny+1)*nz;F=(nx+1)*ny*nz+nx*(ny+1)*nz+nx*ny*(nz+1);interior=3*p*(p-1)**2*N;trace=p*nx*ny*(3*nz+2)+2*p*(p-1)*nx*ny*(3*nz+1);full=p*E+2*p*(p-1)*F+interior
assert [N,trace,interior,full]==[530856,105298704,238885200,345771066];assert inv['inventory']['mode_count']==32060
modefile=Path(inv['ordered_modes']['path']);assert sha(modefile.read_bytes())==inv['ordered_modes']['sha256'];modes=json.loads(modefile.read_text());assert len(modes)==32060 and len({(m['side'],m['m'],m['n'],m['polarization']) for m in modes})==32060
assert c['arrays']['one_dense_Hhat_or_port_matrix']['bytes']==16*32060**2
# Classifier scope and memory discrepancy are evaluated without allocating FE objects.
support_bound=48*nx*ny*882+8
x=dict(reviewed_head=HEAD,previous_review=BASE,scope='stdlib metadata/hash/resource/source audit only; no new FE/matrix/factor/vector numerical experiment',raw_archives_verified=239,final_originals_matching_archive=final_original_checks,protected_files=len(protected),history_files=history,compiled=compiled,source_hashes=verified,supervisions=supervisions,CPU_admissions=admissions,costs=dict(supervised=sumruns,probes=sumprobes,bootstrap=.326941663,total=total),inventory_counts=dict(cells=N,trace=trace,interior=interior,storage=full,ports=32060),target_boundary_support=dict(ideal_topological_pair_bytes=c['arrays']['one_boundary_functional_pair']['bytes'],conservative_full_boundary_cell_support_pair_bytes=support_bound,provider_cache_cap=64*2**20,kind='source-derived candidate bound, not measured actual target support'),component_gates=a['checks'],provider_stats=stats,repository_index_sha256=sha((O/'repository_index.json').read_bytes()),dot_head='077ec9c8386c976da232093779279fb9d1a93033',no_source_edits=True)
(O/'independent_checks.json').write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in x.items() if k in ['raw_archives_verified','final_originals_matching_archive','protected_files','compiled','costs','target_boundary_support']},indent=2))
