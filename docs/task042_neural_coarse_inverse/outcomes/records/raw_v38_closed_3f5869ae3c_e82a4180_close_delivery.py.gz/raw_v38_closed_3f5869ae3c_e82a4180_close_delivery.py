"""Close after all supervised stages settle; final scalar metadata only."""
import gzip,hashlib,json,subprocess,time
from datetime import datetime,timezone
from pathlib import Path

ROOT=Path('/home/fenics/Projects/NN-Lab');T=ROOT/'tmp/task042/v38';R=ROOT/'docs/task042_neural_coarse_inverse/outcomes/records'
began=time.monotonic()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):
    p=Path(p);temp=p.with_suffix(p.suffix+'.closing.partial');temp.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n');temp.replace(p)
book=json.loads((T/'ledger.json').read_text())
if book['active'] is not None or book['closed'] or not all(r['descendants_cleared'] for r in book['runs']):raise RuntimeError('uncleared or already closed scope')
rows=[]
for r in book['runs']:
    d=Path(r['folder']);summary=d/('summary.json' if d.name.startswith('aux_') else 'run_summary.json')
    rows.append({**{k:r[k] for k in ('role','source_sha','elapsed_seconds','classification','exit_code','peak_bytes','swap_bytes','descendants_cleared')},'directory':str(d),'cpu':json.loads((d/'resource_baseline.json').read_text())['cpu'],'summary':{'path':str(summary),'sha256':sha(summary)}})
supervised=sum(r['elapsed_seconds'] for r in rows)
probes=sum(json.loads(p.read_text())['elapsed_seconds'] for p in T.glob('probe_*.json'))
charge=supervised+probes+3
component=sum(r['elapsed_seconds'] for r in rows if r['role'] in ('BRIDGE','LAYOUT','COMPONENT','ORACLE'))
slow_upper=sum(r['elapsed_seconds'] for r in rows if r['role'] in ('BRIDGE','ORACLE'))
if charge+5>7200-180 or component>5400 or slow_upper>1200 or probes>60:raise RuntimeError('final immutable budget failure')
from src.solvers.boundary_structure_scope import window
clock=window.snapshot()
if clock['heavy_remaining_seconds']<=0:raise RuntimeError('real deadline failure')
idx=json.loads((R/'run_index_v38.json').read_text());idx['runs']=rows;idx['current_pack_pending_settlement']=None;idx['all_stages_settled']=True;idx['before_commit_clock']=clock;dump(R/'run_index_v38.json',idx)
res=json.loads((R/'resource_costs_v38.json').read_text());res.update(runs=rows,supervised_wall_seconds=supervised,probes_seconds=probes,charged_seconds=charge,component_seconds=component,
    slow_oracle_conservative_charge_seconds=slow_upper,current_pack_pending_settlement=None,all_stages_settled=True,window=clock,
    known_measured_history_lower_after_v38_seconds=77821.58134307021+supervised+probes,
    bootstrap_not_added_to_measured_history_lower=True,
    successful_component_wall_seconds=next(r['elapsed_seconds'] for r in rows if r['role']=='COMPONENT' and r['classification']=='COMPLETED'),
    final_metadata_control_scope='unmonitored scalar close and git/network/queue metadata; duration recorded separately, not a FE cost; 5s conservative close allowance reserved',
    total_conservative_charge_plus_close_allowance_seconds=charge+5)
# Actual generated payload, independent of allocated filesystem blocks.
def payload(paths):
    seen=set();size=0
    for p in paths:
        candidates=[p] if p.is_file() else p.rglob('*')
        for f in candidates:
            if f.is_file() and not f.is_symlink():
                s=f.stat();key=(s.st_dev,s.st_ino)
                if key not in seen:seen.add(key);size+=s.st_size
    return size
own=[T,ROOT/'benchmarks/artifacts/task042/v38']+list((ROOT/'results/task042').glob('task042_v38_*'))
new_storage=payload(own)
tracked_new=0
for f in R.glob('*v38*'):
    if f.is_file():tracked_new+=f.stat().st_size
for f in (ROOT/'docs/task042_neural_coarse_inverse/response_v38.md',ROOT/'docs/task042_neural_coarse_inverse/outcomes/directional_boundary_structure_v38.md'):tracked_new+=f.stat().st_size
import shutil
res.update(storage={'new_run_cache_artifact_bytes':new_storage,'new_compact_delivery_bytes':tracked_new,'total_new_known_bytes':new_storage+tracked_new,
  'counting_scope':'all V38 tmp/artifact/results plus new compact delivery; navigation/source small incremental bytes covered by 1MiB reserve',
  'conservative_new_bytes_plus1MiB':new_storage+tracked_new+2**20,'cap_bytes':512*2**20,'all_task_artifact_bytes':payload([ROOT/'benchmarks/artifacts/task042']),
  'free_bytes':shutil.disk_usage(ROOT).free})
if res['storage']['conservative_new_bytes_plus1MiB']>512*2**20:raise RuntimeError('actual complete storage scope failure')
dump(R/'resource_costs_v38.json',res)
line=(f"最终已结算监督 {supervised:.9f}s＋probe {probes:.9f}s＋bootstrap3s＝预算收费 {charge:.9f}s；"
      f"另保守预留5s标量close费用。组件 {component:.9f}s／5400s，慢oracle含失败BRIDGE保守收费 {slow_upper:.9f}s／1200s。"
      f"已知新库存含compact交付 {new_storage+tracked_new}B，另1MiB源码／导航余量后仍低于512MiB；"
      f"历史实测下界续记 {77821.58134307021+supervised+probes:.9f}s，完整历史和未监督实现／一般读写仍UNKNOWN。"
      f"日历截至费用收口 {clock['elapsed_seconds']:.3f}s，自首次接手计算，窗口未刷新。\n\n")
for p in [ROOT/'docs/task042_neural_coarse_inverse/response_v38.md',ROOT/'docs/task042_neural_coarse_inverse/outcomes/directional_boundary_structure_v38.md']:
    text=p.read_text();p.write_text(text.replace('唯一下一建议：',line+'唯一下一建议：',1))
book['closed']=True;book['closed_utc']=datetime.now(timezone.utc).isoformat();book['reason']='ALL_AUTHORIZED_BOUNDARY_QUEUE_COMPLETE; NO_VOLUME_SOLVE_AUTHORIZED';book['final_close_allowance_seconds']=5;dump(T/'ledger.json',book)
with (T/'progress_journal.jsonl').open('a') as stream:stream.write(json.dumps({'event':'scope_closed','UTC':book['closed_utc'],'charged_seconds':charge,'descendants_cleared':True,'status':'TARGET_BOUNDARY_ACTION_QUALIFIED_AT_FROZEN_Q','NN20':'NOT_DEMONSTRATED'})+'\n')
raw=json.loads((R/'raw_evidence_index_v38.json').read_text());seen={(v['original_path'],v['sha256']) for v in raw['files']}
paths=[T/'ledger.json',T/'progress_journal.jsonl',T/'close_delivery.py']
paths.extend(p for p in (T/'aux_final_01').rglob('*') if p.is_file() and p.suffix in ('.json','.jsonl','.log'))
for p in paths:
    h=sha(p)
    if (str(p),h) in seen:continue
    data=p.read_bytes();out=R/('raw_v38_closed_'+hashlib.sha256(str(p).encode()).hexdigest()[:10]+'_'+h[:8]+'_'+p.name+'.gz')
    out.write_bytes(gzip.compress(data,compresslevel=1,mtime=0))
    if gzip.decompress(out.read_bytes())!=data:raise ValueError('closing archive mismatch')
    raw['files'].append({'original_path':str(p),'gzip':str(out.relative_to(ROOT)),'bytes':len(data),'sha256':h,'gzip_sha256':sha(out)})
raw['final_ledger_closed']=True;raw['final_ledger_ref']={'path':str(T/'ledger.json'),'sha256':sha(T/'ledger.json')};dump(R/'raw_evidence_index_v38.json',raw)
close_seconds=time.monotonic()-began
if close_seconds>5:raise RuntimeError('close metadata exceeds declared conservative allowance')
res=json.loads((R/'resource_costs_v38.json').read_text());res['scalar_close_elapsed_seconds_measured']=close_seconds;res['closed']=True;dump(R/'resource_costs_v38.json',res)
minimum=json.loads((R/'minimum_result_cost_v38.json').read_text());minimum.update(pending_final_metadata_settlement=False,closed=True,charged_seconds=charge,close_metadata_seconds=close_seconds,clock=clock);dump(R/'minimum_result_cost_v38.json',minimum)
dump(R/'cleanup_v38.json',{'closed':True,'final_ledger':{'path':str(T/'ledger.json'),'sha256':sha(T/'ledger.json')},'all_supervised_descendants_cleared':True,'actor_inventory_host_read_before_close':[],
    'source_before_docs_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'before_commit_clock':clock,'scalar_close_seconds':close_seconds,'queue_review_thread':'01a0fcea-d3a8-7b23-a266-eec22adf39fa','handoff_marker':'execution-review-handoff-20261004-v38'})
print(json.dumps({'closed':True,'charged_seconds':charge,'supervised_seconds':supervised,'probes_seconds':probes,'peak_bytes':res['sampled_tree_peak_bytes'],'new_bytes_with_compact':new_storage+tracked_new,'actual_close_metadata_seconds':close_seconds}),flush=True)
