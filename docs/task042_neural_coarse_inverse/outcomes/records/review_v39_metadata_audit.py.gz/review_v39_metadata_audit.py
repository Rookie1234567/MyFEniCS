import ast,gzip,hashlib,json,math,struct,subprocess,zipfile,xml.etree.ElementTree as ET
from pathlib import Path
ROOT=Path.cwd();D=ROOT/'docs/task042_neural_coarse_inverse';R=D/'outcomes/records';O=ROOT/'tmp/task042/review_v39';HEAD='545eee991318664770dec4edafe1ace5f00d02f3';BASE='718c42ef2be1ce375f940a5092ad503ab3729d5a'
def git(*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a])
def sha(b):return hashlib.sha256(b).hexdigest()
def read(n):return json.loads((R/n).read_text())
def key(p):return str((ROOT/p).resolve())
assert git('rev-parse','HEAD').decode().strip()==HEAD
raw={};versions={};rawidx=read('raw_evidence_index_v41.json')
for x in rawidx['files']:
 b=(ROOT/x['archive']).read_bytes();assert sha(b)==x['archive_sha256'];v=gzip.decompress(b);assert sha(v)==x['sha256'] and len(v)==x['bytes'];p=key(x['original']);raw[p]=v;versions.setdefault(p,[]).append(v)
originals=0;changed=[]
for p,vs in versions.items():
 if Path(p).exists():
  if Path(p).read_bytes() in vs:originals+=1
  else:changed.append(p)
protected=[];history=[];append={'README.md','outcomes/summary.md','outcomes/test_summary.md','outcomes/changed_files.md'}
for p in git('ls-tree','-r','--name-only',BASE,str(D.relative_to(ROOT))).decode().splitlines():
 old=git('show',BASE+':'+p);now=(ROOT/p).read_bytes();rel=str(Path(p).relative_to(D.relative_to(ROOT)))
 if rel in append:assert now.endswith(old),p
 else:assert now==old,p;protected.append(p)
 if Path(p).name.startswith(('review_report_v','response_v')):history.append(p)
compiled=[]
for p in git('diff','--name-only',BASE,HEAD).decode().splitlines():
 if p.endswith('.py'):compile((ROOT/p).read_text(),p,'exec');compiled.append(p)
run=read('run_index_v41.json');cost=read('resource_costs_v41.json');supervisions=[];formal_sources=[];stages=[]
for row in cost['runs']:
 folder=ROOT/row['folder'];manifest=json.loads(raw[key(folder/'run_manifest.json')]);role=manifest['stage'].removeprefix('V41-')
 if role in ('ENVELOPE','BRIDGE1','BRIDGE2','BRIDGE4','TOPOLOGY','ORIENTATION','ROUTING','CHECK','DEPLOY','CAPACITY'):
  for fp,h in manifest['implementation_hashes'].items():assert sha(git('show',manifest['source_sha']+':'+fp))==h,(role,fp)
  formal_sources.append(dict(role=role,source_sha=manifest['source_sha'],hashes=len(manifest['implementation_hashes']),manifest=str(folder/'run_manifest.json')))
 p=folder/'supervision/summary.json';s=json.loads(raw[key(p)]);samples=[json.loads(b) for b in raw[key(folder/'supervision/resources.jsonl')].splitlines()]
 assert len(samples)==s['samples']
 for v in samples:
  assert v['rss_bytes']==sum(m['rss_bytes'] for m in v['members']);assert v['swap_bytes']==sum(m['swap_bytes'] for m in v['members'])
 assert max(v['rss_bytes'] for v in samples)==s['sampled_process_tree_rss_peak_bytes']
 assert max(v['swap_bytes'] for v in samples)==0 and s['descendants_cleared'];assert s['elapsed_seconds']==row['seconds']
 supervisions.append(dict(role=row['role'],path=str(p),seconds=s['elapsed_seconds'],peak=s['sampled_process_tree_rss_peak_bytes'],samples=len(samples),status=s['classification']))
for row in run['runs']:
 for field in ('manifest','summary','result'):
  x=row.get(field)
  if x:
   b=(ROOT/x['path']).read_bytes();assert sha(b)==x['sha256'];assert len(b)==x['bytes']
   if field=='result':stages.append(json.loads(b))
probes=[json.loads(p.read_text()) for p in (ROOT/'tmp/task042/v41').glob('probe_*.json')];sumruns=sum(s['seconds'] for s in supervisions);sumprobes=sum(p['elapsed_seconds'] for p in probes);total=sumruns+sumprobes+3+5
assert math.isclose(sumruns,cost['supervised_seconds'],rel_tol=1e-14);assert math.isclose(sumprobes,cost['paid_probe_seconds'],rel_tol=1e-14);assert math.isclose(total,cost['charged_total_so_far_seconds'],rel_tol=1e-14)
peak=max(s['peak'] for s in supervisions)
book=json.loads((ROOT/'tmp/task042/v41/ledger.json').read_text());assert book['closed'] and book['active'] is None and len(book['runs'])==len(supervisions)
admissions=[]
for p in probes:
 d=json.loads(raw[key(p['receipt_path'])]);fr={int(k):v for k,v in d['cpu_busy_fractions'].items()};reasons={}
 for name,b in d['cpu_ticks_before'].items():
  a=d['cpu_ticks_after'][name];assert abs(1-(a[3]-b[3]+a[4]-b[4])/max(sum(a)-sum(b),1)-fr[int(name)])<1e-15
 for tid,a in d['thread_ticks_after'].items():
  b=d['thread_ticks_before'].get(tid)
  if b and a[0]==b[0]:assert d['thread_delta_ticks'][tid]==a[1]-b[1]
 for cpu,v in fr.items():
  if v>.05:reasons.setdefault(cpu,[]).append('sample_busy_fraction_gt_0.05')
 for proc in d['neighbor_processes']:
  for t in proc['threads']:
   if len(t['affinity'])<=16:
    for cpu in t['affinity']:reasons.setdefault(cpu,[]).append('narrow_thread_affinity:'+str(t['tid']))
   elif d['thread_delta_ticks'].get(str(t['tid']),1)>0:reasons.setdefault(t['cpu'],[]).append('active_wide_thread:'+str(t['tid']))
 decisions=[dict(**t,eligible=not any(c in reasons for c in t['siblings']),excluded_siblings={str(c):reasons[c] for c in t['siblings'] if c in reasons}) for t in d['topology']]
 assert decisions==d['cpu_decisions'];assert [t['cpu'] for t in decisions if t['eligible']]==d['candidate_cpus'];assert d['selected_cpu'] in d['candidate_cpus'];admissions.append(dict(path=p['receipt_path'],cpu=d['selected_cpu']))
# Only frozen array byte/hash/header inspection, no FE or NumPy/BLAS execution.
receipts={}
def walk(v):
 if isinstance(v,dict):
  if all(k in v for k in ('path','sha256','members')) and str(v['path']).endswith('.npz'):receipts[v['path']]=v
  for w in v.values():walk(w)
 elif isinstance(v,list):
  for w in v:walk(w)
walk(read('array_inventory_v41.json'));array_checks=[]
for path,receipt in receipts.items():
 p=Path(path);assert sha(p.read_bytes())==receipt['sha256'];aliases=receipt.get('aliases',{})
 with zipfile.ZipFile(p) as z:
  assert set(z.namelist())=={k+'.npy' for k in receipt['members'] if k not in aliases}
  for name,m in receipt['members'].items():
   actual=aliases.get(name,name);assert actual not in aliases;b=z.read(actual+'.npy');assert b[:6]==b'\x93NUMPY';length=2 if b[6]==1 else 4;off=8+length;size=int.from_bytes(b[8:off],'little');meta=ast.literal_eval(b[off:off+size].decode().strip());assert list(meta['shape'])==m['shape'] and meta['descr']==m['dtype'];payload=b[off+size:]
   if meta['fortran_order']:
    assert len(meta['shape'])==2,(path,name,meta)
    nr,nc=meta['shape'];width=int(meta['descr'][2:]);view=memoryview(payload)
    payload=b''.join(view[(j*nr+i)*width:(j*nr+i+1)*width] for i in range(nr) for j in range(nc))
   assert sha(payload)==m['sha256'],(path,name)
 array_checks.append(dict(path=path,members=len(receipt['members']),stored_members=len(receipt['members'])-len(aliases),bytes=p.stat().st_size))
scalars=[]
def ratios(v):
 if isinstance(v,dict):
  if {'numerator','denominator','passed'} <= set(v):
   num,den=v['numerator'],v['denominator'];passed=num<=v['absolute_rule'] if 'absolute_rule' in v else num==0 if den==0 else num/den<=1e-10
   assert v['passed']==passed,v
   if den and v.get('relative') is not None:assert math.isclose(v['relative'],num/den,rel_tol=1e-13)
   scalars.append(v)
  for val in v.values():ratios(val)
 elif isinstance(v,list):
  for val in v:ratios(val)
ratios(read('component_checker_v41.json'))
xml=[]
for p,b in raw.items():
 if p.endswith('pytest.xml'):
  t=ET.fromstring(b);suite=list(t)[0] if t.tag=='testsuites' else t;xml.append(dict(path=p,tests=int(suite.get('tests')),failures=int(suite.get('failures')),errors=int(suite.get('errors'))))
# Final implementation snapshot separated from formal run source.
tests=read('tests_v41.json');source=tests['implementation_hashes']
for p,h in source.items():assert sha((ROOT/p).read_bytes())==h,p

# Independently derive all raw/oriented class keys from owned cells, saved geometry
# and actual cell permutation integers. No FE calls/matrix operations.
from collections import Counter
from statistics import median

def npy(z,n):
 b=z.read(n+'.npy');width=2 if b[6]==1 else 4;off=8+width;l=int.from_bytes(b[8:off],'little');meta=ast.literal_eval(b[off:off+l].decode().strip());assert not meta['fortran_order'];return meta,memoryview(b)[off+l:]
def vals(z,n):
 m,b=npy(z,n);f={'<i4':'i','<i8':'q','<u4':'I','<f8':'d'}[m['descr']];return m, memoryview(b).cast(f)
def rkey(v):return (v['tag'],*v['width_hex'])
def okey(v):return (*rkey(v),v['permutation'],tuple(v['native_reference_vertex_order']))
topo=read('actual_topology_inventory_v41.json');rc=Counter();oc=Counter();rank_counts=[];tags=Counter();orders=set();codes=set()
for packet in topo['packets']:
 meta=packet['metadata'];n=meta['entity_sizes']['3']['owned'];rr=Counter();oo=Counter()
 with zipfile.ZipFile(packet['numeric']['path']) as z:
  _,cv=vals(z,'cell_vertices');_,xyz=vals(z,'coordinates');_,cp=vals(z,'cell_permutations');_,ct=vals(z,'cell_tags')
  for c in range(n):
   vertices=[tuple(xyz[3*v:3*v+3]) for v in cv[8*c:8*c+8]]
   low=[min(p[a] for p in vertices) for a in range(3)];hi=[max(p[a] for p in vertices) for a in range(3)]
   center=[(a+b)/2 for a,b in zip(low,hi)];tag=3 if 16.5<=center[0]<=33.5 and 0<=center[1]<=25 and 0<=center[2]<=120 else 2 if center[2]<0 else 1
   assert tag==ct[c]
   class_key=(tag,*[(b-a).hex() for a,b in zip(low,hi)]);order=tuple(sum((1<<a) for a in range(3) if v[a]==hi[a]) for v in vertices);k=(*class_key,cp[c],order)
   rr[class_key]+=1;oo[k]+=1;tags[tag]+=1;orders.add(order);codes.add(cp[c])
 assert rr==Counter({rkey(v):v['count'] for v in meta['raw_classes']})
 assert oo==Counter({okey(v):v['count'] for v in meta['oriented_classes']})
 rc.update(rr);oc.update(oo);rank_counts.append(dict(rank=meta['rank'],raw=len(rr),oriented=len(oo),cells=n))
assert rc==Counter({rkey(v):v['count'] for v in topo['raw_classes']})
assert oc==Counter({okey(v):v['count'] for v in topo['oriented_classes']})
assert len(rc)==270 and len(oc)==858 and sum(rc.values())==530856
# All explicit ratios with their saved numerator/denominator were independently
# checked above; no claim of rerunning arithmetic of saved matrix/vector outputs.
sampling=[]
for row in cost['runs']:
 v=[json.loads(b) for b in raw[key(ROOT/row['folder']/'supervision/resources.jsonl')].splitlines()]
 delta=[b['elapsed_seconds']-a['elapsed_seconds'] for a,b in zip(v,v[1:])]
 sampling.append(dict(folder=row['folder'],sample_count=len(v),actual_interval_median=median(delta) if delta else None,actual_interval_max=max(delta,default=None)))
checks=read('component_checker_v41.json');required={'BRIDGE1','BRIDGE2','BRIDGE4','TOPOLOGY','ORIENTATION','ROUTING','ACTIONS'};assert required==set(checks['checks'])
for name in ('BRIDGE1','BRIDGE2','BRIDGE4'):
 assert checks['checks'][name]['fixtures']
env=read('stage_dependencies_v41.json');b=Path(env['envelope_path']).read_bytes();assert sha(b)==env['envelope_sha256'];e=json.loads(b)
for parent in e['parents']:assert sha(Path(parent['path']).read_bytes())==parent['sha256']
for binding in e['class_bindings']:
 system=json.loads(Path(binding['system_path']).read_text());assert system['metadata']['classes']==binding['classes']
 for cl in binding['classes']:assert sha((Path(binding['system_path']).parent/(cl['name']+'.json')).read_bytes())==cl['sha256']
x=dict(reviewed_head=HEAD,previous_review=BASE,scope='stdlib read-only frozen byte/source/metadata/topology audit; no new FE/matrix action/factor/solve',raw_archives_verified=len(rawidx['files']),current_originals_matching_archived_version=originals,unmatched_current_originals=changed,protected_files=len(protected),history_files=history,compiled=compiled,formal_source_checks=formal_sources,final_source_hashes=source,supervisions=supervisions,CPU_admissions=admissions,costs=dict(supervised=sumruns,probes=sumprobes,bootstrap=3,close_upper=5,total_upper=total,peak_sampled_tree_bytes=peak,ownswap=0,cumulative_supervised_lower=cost['cumulative_supervised_lower_seconds']),array_byte_verification=array_checks,array_totals=dict(files=len(array_checks),logical=sum(v['members'] for v in array_checks),actual=sum(v['stored_members'] for v in array_checks)),scalar_ratio_checks=len(scalars),pytest_snapshots=xml,topology_independent=dict(raw=len(rc),oriented=len(oc),rank_counts=rank_counts,cells=sum(rc.values()),tags=tags,reference_orders=list(orders),native_direction_codes=sorted(codes)),present_required_checker_stages=sorted(required),sampling=sampling,repository_index_sha256=sha((O/'repository_index.json').read_bytes()),dot_head='077ec9c8386c976da232093779279fb9d1a93033',source_changes=False,qualification='DISTRIBUTED_NATIVE_ENTITY_BRIDGE_ON_FIXTURE_AND_TARGET_TOPOLOGY_OWNER_COMPONENT_ONLY',limitations=['not whole-repository line-by-line semantic audit','no target p6 FunctionSpace/complete dofmap/vector/operator/solve','saved ratio checks do not rerun matrix/vector arithmetic','fail-open missing stage aggregation and self-expected consumption identity require next-round repair','no distributed nonzero-RHS volume consumer','review ordinary IO/human costs not supervised'])
(O/'independent_checks.json').write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(raw=len(rawidx['files']),originals=originals,changed=changed,protected=len(protected),history=len(history),compiled=len(compiled),formal_sources=len(formal_sources),costs=x['costs'],arrays=x['array_totals'],ratios=len(scalars),topology=x['topology_independent'],xml=xml),indent=2))
