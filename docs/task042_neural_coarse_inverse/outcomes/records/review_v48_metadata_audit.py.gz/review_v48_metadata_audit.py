import ast,hashlib,json,math,subprocess,zipfile
from pathlib import Path
import numpy as np
root=Path.cwd();r=root/'docs/task042_neural_coarse_inverse/outcomes/records';art=root/'benchmarks/artifacts/task042/v49'
HEAD='d9121ce635c4d4c3a7dc3933ca8a60d71eab6f32';base='0b0e6b236aa1a7205f453841a0a41e209656ed98'
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def hashfile(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for chunk in iter(lambda:f.read(2**20),b''):h.update(chunk)
 return h.hexdigest()
def git(*args):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*args])
assert git('rev-parse','HEAD').decode().strip()==HEAD
assert not git('status','--porcelain')
delivery=read(r/'delivery_index_v49.json')
for item in delivery['compact_records']:
 p=r/item['path'];assert p.stat().st_size==item['bytes'] and hashfile(p)==item['sha256'],p
for item in delivery['final_tested_markdown_hashes']:assert hashfile(root/item['path'])==item['sha256']
rows=[]
for name in ('raw_archive_index_v49.json','post_settlement_archive_v49.json'):
 x=read(r/name)
 for item in x['files']:
  p=root/item['archived'];assert p.stat().st_size==item['bytes'] and hashfile(p)==item['sha256'],p
  rows.append(item)
versions={}
for item in rows:versions.setdefault(item['path'],set()).add(item['sha256'])
unmatched=[];missing=[]
for p,hs in versions.items():
 if not (root/p).exists():missing.append(p)
 elif hashfile(root/p) not in hs:unmatched.append(p)
assert not missing and set(unmatched)=={'docs/task042_neural_coarse_inverse/outcomes/records/delivery_index_v49.json','docs/task042_neural_coarse_inverse/outcomes/records/post_settlement_archive_v49.json'},(missing,unmatched)
# These two evolving index files contain their own prior snapshots. Their
# final bytes are Git-bound; the final settlement index is also delivery-bound.
index_final_versions=[{'path':p,'current_sha256':hashfile(root/p),'archived_prior_hashes':sorted(versions[p]),'scope':'self-referential final index; final HEAD and delivery bindings, not a scientific array mismatch'} for p in unmatched]
sources=read(r/'source_bindings_v49.json')['rows']
output=git('cat-file','--batch') if not sources else subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','cat-file','--batch'],input=''.join(x['source_sha']+':'+x['path']+'\n' for x in sources).encode(),capture_output=True,check=True).stdout
offset=0
for item in sources:
 end=output.index(b'\n',offset);h=output[offset:end].decode().split();offset=end+1
 assert h[1]=='blob' and h[0]==item['git_blob'];n=int(h[2]);data=output[offset:offset+n];offset+=n+1
 assert n==item['bytes'] and sha(data)==item['sha256'] and hashfile(root/item['archived'])==item['sha256']
assert offset==len(output)
parents={}
for stage,item in delivery['scientific_stage_pointers'].items():
 assert hashfile(item['path'])==item['sha256'];parents[stage]=read(item['path'])
receipts={}
def scan(x):
 if isinstance(x,dict):
  if isinstance(x.get('path'),str) and x['path'].endswith('.npz') and 'members' in x:receipts[x['path']]=x
  for y in x.values():scan(y)
 elif isinstance(x,list):
  for y in x:scan(y)
for x in parents.values():scan(x)
inventory=read(r/'array_inventory_v49.json')['files'];member_count=0;array_bytes=0;arrays_verified=[]
for item in inventory:
 p=root/item['path'];assert p.stat().st_size==item['bytes'] and hashfile(p)==item['sha256'];meta=receipts.get(str(p));names=[]
 with np.load(p,allow_pickle=False) as z:
  if meta:assert set(z.files)==set(meta['members']) and meta['sha256']==item['sha256']
  for k in z.files:
   a=z[k];assert not a.dtype.hasobject;array_bytes+=a.nbytes;member_count+=1;names.append(k)
   if meta:
    m=meta['members'][k];assert list(a.shape)==m['shape'] and str(a.dtype)==m['dtype']
    assert sha(a.dtype.str.encode()+str(a.shape).encode()+np.ascontiguousarray(a).tobytes())==m['sha256']
 arrays_verified.append({'path':item['path'],'members':names,'member_receipt':meta is not None})
def ratio(a,b):
 a=np.asarray(a);b=np.asarray(b);scale=max(float(np.max(np.abs(a),initial=0)),float(np.max(np.abs(b),initial=0)),1e-30)
 return float(np.linalg.norm(a/scale)/max(np.linalg.norm(b/scale),1e-30/scale))
def almost(a,b):assert math.isclose(a,b,rel_tol=2e-12,abs_tol=1e-28),(a,b)
numeric=[]
for name in ('REFERENCE_REGULAR','REFERENCE_NOTCH','ENGINE_REGULAR','ENGINE_NOTCH','REFERENCE_NOTCH_P5'):
 parent=parents[name]
 with np.load(parent['arrays']['path'],allow_pickle=False) as z:
  rhs=z['rhs'];u=z['u_storage'];slaves=z['slaves'];assert np.all(u[slaves]==0)
  geom={k:z[k].copy() for k in ('cell_centers','cell_tags','regular_tags')}
  if name.startswith('REFERENCE'):v={k:z[k] for k in ('residual','volume_action','coupling_action','augmented_residual','port_residual','projected','H')}
  else:
   with np.load(parent['audit_arrays']['path'],allow_pickle=False) as az:v={k:az[k] for k in az.files}
  nr=ratio(v['residual'],rhs);ar=ratio(v['augmented_residual'],rhs);pr=ratio(v['port_residual'],v['projected'])
  almost(nr,parent['original_audit']['true']);almost(ar,parent['original_audit']['augmented']);almost(pr,parent['original_audit']['port'])
  assert nr<=1e-10 and ar<=1e-10 and pr<=1e-10
  assert ratio(v['augmented_residual']-(rhs-v['volume_action']-v['coupling_action']),rhs)<1e-13
 power=read(Path(parent['output']['fields']['path']).with_name('port_power.json'));assert len(power['orders'])==532
 pm=parent['output']['port_metrics'];vm=parent['output']['volume_metrics']
 almost(pm['A_balance'],1-pm['R_total']-pm['T_total'])
 assert abs(vm['energy_closure_error_port_volume']-(vm['A_volume_total']-pm['A_balance']))<=4*np.finfo(float).eps
 numeric.append({'stage':name,'saved_original_true':nr,'saved_augmented':ar,'saved_port':pr,'all_modes':len(power['orders']),'energy_error':vm['energy_closure_error_port_volume'],'changed_cells':np.flatnonzero(geom['cell_tags']!=geom['regular_tags']).tolist()})
for case in ('REGULAR','NOTCH'):
 pair=next(x for x in parents['VERIFY_P4']['pairs'] if x['case']==case)
 assert set(pair['fields'])=={'E_total','E_scattered','H_total','H_scattered','scaled_curl_total','scaled_curl_scattered'}
 for v in pair['fields'].values():almost(v['mixed_relative'],v['difference_L2']/max(v['reference_L2'],1e-12));assert v['mixed_relative']<1e-4
 for side in ('reference','candidate'):
  audit=pair[side+'_audit'];recovery=pair[side+'_recovery']
  assert max(audit[k] for k in ('true','native','augmented','port'))<(1e-10 if side=='reference' else 1e-6)
  assert audit['identity']<1e-10 and audit['slave_zero']
  assert max(recovery[k] for k in ('operation_scaled_interior','max_cell_operation_scaled','master_storage_max_abs'))<1e-10 and recovery['slave_storage_zero']
 ref=parents['REFERENCE_'+case];cand=parents['ENGINE_'+case]
 with np.load(ref['output']['fields']['path']) as rf,np.load(cand['output']['fields']['path']) as cf:
  for k in pair['selected']:almost(np.linalg.norm(cf[k]-rf[k])/max(np.linalg.norm(rf[k]),1e-12),pair['selected'][k])
 rp=read(Path(ref['output']['fields']['path']).with_name('port_power.json'))['orders'];cp=read(Path(cand['output']['fields']['path']).with_name('port_power.json'))['orders']
 for key in ('auxiliary_amplitude_total_projection','outgoing_amplitude','outgoing_amplitude_at_boundary'):
  a=np.array([complex(*x[key]) for x in rp]);b=np.array([complex(*x[key]) for x in cp]);almost(ratio(b-a,a),pair['all_modes'][key+'_relative'])
 assert max(pair['power_differences'].values())<1e-5 and pair['all_modes']['mode_power_max_absolute']<1e-6
pinc=read(r/'p_increment_v49.json')['result']
for v in pinc['fields'].values():almost(v['mixed_relative'],v['difference_L2']/max(v['reference_L2'],1e-12))
run_records=read(r/'resource_costs_final_v49.json');count=0;peak=0;gap=0;swap=0
for item in run_records['runs']:
 samples=[json.loads(x) for x in (Path(item['folder'])/'supervision/resources.jsonl').read_text().splitlines()]
 assert len(samples)==item['sample_count'];count+=len(samples)
 peak=max(peak,max((s['rss_bytes'] for s in samples),default=0));swap=max(swap,max((s['swap_bytes'] for s in samples),default=0))
 localgap=max((b['elapsed_seconds']-a['elapsed_seconds'] for a,b in zip(samples,samples[1:])),default=0)
 almost(localgap,item['actual_max_gap_seconds']);gap=max(gap,localgap)
 assert item['descendants_cleared']
assert count==run_records['sample_count'] and peak==run_records['sampled_process_tree_peak_bytes'] and swap==0
almost(gap,run_records['actual_max_sample_gap_seconds'])
known=run_records['paid_supervised_probe_launcher_lower_seconds']+run_records['persisted_manual_development_tool_wall_lower_seconds']+run_records['post_settlement_measured_receipt']['seconds_lower_so_far']
almost(known,run_records['new_known_loaded_lower_seconds']);almost(known+run_records['known_prior_loaded_lower_seconds'],run_records['historical_plus_new_known_lower_seconds'])
costs=[]
for route in read(r/'cold_n1_costs_v49.json')['routes']:
 p=Path(route['parent_result_path']).parent;events=[json.loads(x) for x in (p/'events.jsonl').read_text().splitlines()]
 stack=[];exclusive={};roots=0.
 for ev in events:
  name=ev['event'];t=ev['elapsed_s']
  if name.endswith('_begin'):stack.append([name[:-6],t,0.])
  elif name.endswith('_end'):
   role=name[:-4];assert stack[-1][0]==role;_,begin,children=stack.pop();elapsed=t-begin
   assert elapsed>=children-1e-7;exclusive[role]=exclusive.get(role,0.)+max(elapsed-children,0.)
   if stack:stack[-1][2]+=elapsed
   else:roots+=elapsed
 assert not stack and exclusive==route['exclusive_seconds'];almost(roots,route['root_measured_seconds'])
 summary=read(root/'results/task042'/p.name/'run_summary.json');almost(summary['launch_wall_seconds'],route['cold_N1_measured_dat_launch_lower_bound_seconds'])
 costs.append({'stage':route['stage'],'cold_N1_lower':summary['launch_wall_seconds'],'exclusive_seconds':exclusive,'factor_inventory':route['actual_factor_inventory']})
for o in read(r/'opportunity_decision_v49.json')['opportunities']:
 c=next(x for x in costs if x['stage']==o['selected_non_neural_baseline']);ex=c['exclusive_seconds'];tail=ex['global_finite_factor_setup']+ex['solve_and_minimal_internal_recovery'];v=tail+ex['condensation_local_factors'];t=c['cold_N1_lower']
 almost(tail/t,o['factor_and_tail_complete_removal_optimistic_fraction']);almost(v-.2*t,o['maximum_cold_data_teacher_training_inference_extra_check_seconds_optimistic'])
protected=0
prefixes={'docs/task042_neural_coarse_inverse/README.md','docs/task042_neural_coarse_inverse/outcomes/summary.md','docs/development_progress.md','docs/development_model_registry.md'}
for p in git('ls-tree','-r','--name-only',base,'docs/task042_neural_coarse_inverse').decode().splitlines():
 old=git('show',base+':'+p);now=(root/p).read_bytes()
 if p in prefixes:assert now.endswith(old)
 else:assert now==old,p
 protected+=1
out={'schema':'task042.review48.independent.v1','reviewed_HEAD':HEAD,'review47_commit':base,'delivery_records':len(delivery['compact_records']),
 'archive_versions_by_index':[len(read(r/n)['files']) for n in ('raw_archive_index_v49.json','post_settlement_archive_v49.json')],'current_raw_paths':len(versions),'missing':missing,'self_referential_index_versions':index_final_versions,'unexplained_unmatched':[],
 'source_bindings_verified':len(sources),'NPZ_files':len(inventory),'NPZ_members':member_count,'NPZ_payload_bytes':array_bytes,'NPZ_records':arrays_verified,'member_receipts_found':len(receipts),
 'saved_array_norms_recomputed':numeric,'p_increment_fields':pinc['fields'],'cold_costs_recomputed':costs,'resource_samples':count,'peak_bytes':peak,'own_swap':swap,'max_sample_gap':gap,'new_known_lower':known,'history_plus_new_lower':known+run_records['known_prior_loaded_lower_seconds'],
 'protected_old_task_files':protected,'old_prefix_history_unchanged':True,'final_tested_doc_hashes_match':True,
 'scope':'hash/header/complete saved array norms and scalar recomputation only; no FE actions, assembly, solve, training, neural inference, JIT or MPI; review manual/IO costs unsupervised unknown'}
Path('/tmp/task042_review48_audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ('NPZ_records','cold_costs_recomputed','p_increment_fields')},ensure_ascii=False,indent=2))
