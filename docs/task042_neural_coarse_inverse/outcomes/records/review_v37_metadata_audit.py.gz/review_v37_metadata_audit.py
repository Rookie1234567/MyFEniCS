import ast,gzip,hashlib,json,math,struct,subprocess,zipfile,xml.etree.ElementTree as ET
from pathlib import Path
ROOT=Path.cwd();D=ROOT/'docs/task042_neural_coarse_inverse';R=D/'outcomes/records';O=ROOT/'tmp/task042/review_v37';HEAD='6f7a5576c7f87dcb014d6ea993fc792b1ff884c9';BASE='9430495d8a2cc6870ea1b79cfe4c60889ef5e3db'
def git(*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a])
def sha(b):return hashlib.sha256(b).hexdigest()
def read(n):return json.loads((R/n).read_text())
def key(p):return str((ROOT/p).resolve())
assert git('rev-parse','HEAD').decode().strip()==HEAD
raw={};versions={};rawidx=read('raw_evidence_index_v39.json')
for x in rawidx['files']:
 b=(ROOT/x['archive']).read_bytes();assert sha(b)==x['archive_sha256'];v=gzip.decompress(b);assert sha(v)==x['sha256'] and len(v)==x['bytes'];p=key(x['original']);raw[p]=v;versions.setdefault(p,[]).append(v)
originals=0;changed=[]
for p,vs in versions.items():
 if Path(p).exists():
  if Path(p).read_bytes() in vs:originals+=1
  else:changed.append(p)
protected=[];history=[];append={'README.md','outcomes/summary.md','outcomes/test_summary.md','outcomes/changed_files.md'}
for p in git('ls-tree','-r','--name-only',BASE,str(D.relative_to(ROOT))).decode().splitlines():
 old=git('show',BASE+':'+p);now=(ROOT/p).read_bytes();rel=str(Path(p).relative_to(D.relative_to(ROOT)))
 if rel in append:assert now.endswith(old),p
 else:assert now==old,p;protected.append(p)
 if Path(p).name.startswith(('review_report_v','response_v')):history.append(p)
compiled=[]
for p in git('diff','--name-only',BASE,HEAD).decode().splitlines():
 if p.endswith('.py'):compile((ROOT/p).read_text(),p,'exec');compiled.append(p)
run=read('run_index_v39.json');cost=read('resource_costs_v39.json');supervisions=[];formal_sources=[];stages=[]
for row in cost['runs']:
 folder=ROOT/row['folder'];manifest=json.loads(raw[key(folder/'run_manifest.json')]);role=manifest['stage'].removeprefix('V39-')
 if role in ('EVIDENCE','ADAPTER','COUPLED','CHECK','DEPLOY'):
  for fp,h in manifest['implementation_hashes'].items():assert sha(git('show',manifest['source_sha']+':'+fp))==h,(role,fp)
  formal_sources.append(dict(role=role,source_sha=manifest['source_sha'],hashes=len(manifest['implementation_hashes']),manifest=str(folder/'run_manifest.json')))
 p=folder/'supervision/summary.json';s=json.loads(raw[key(p)]);samples=[json.loads(b) for b in raw[key(folder/'supervision/resources.jsonl')].splitlines()]
 assert len(samples)==s['samples']
 for v in samples:
  assert v['rss_bytes']==sum(m['rss_bytes'] for m in v['members']);assert v['swap_bytes']==sum(m['swap_bytes'] for m in v['members'])
 assert max(v['rss_bytes'] for v in samples)==s['sampled_process_tree_rss_peak_bytes']
 assert max(v['swap_bytes'] for v in samples)==0 and s['descendants_cleared'];assert s['elapsed_seconds']==row['seconds']
 supervisions.append(dict(role=row['role'],path=str(p),seconds=s['elapsed_seconds'],peak=s['sampled_process_tree_rss_peak_bytes'],samples=len(samples),status=s['classification']))
for row in run['runs']:
 for field in ('manifest','summary','result'):
  x=row.get(field)
  if x:
   b=(ROOT/x['path']).read_bytes();assert sha(b)==x['sha256'];assert len(b)==x['bytes']
   if field=='result':stages.append(json.loads(b))
probes=[json.loads(p.read_text()) for p in (ROOT/'tmp/task042/v39').glob('probe_*.json')];sumruns=sum(s['seconds'] for s in supervisions);sumprobes=sum(p['elapsed_seconds'] for p in probes);total=sumruns+sumprobes+3+5
assert math.isclose(sumruns,cost['supervised_seconds'],rel_tol=1e-14);assert math.isclose(sumprobes,cost['paid_probe_seconds'],rel_tol=1e-14);assert math.isclose(total,cost['charged_total_upper_seconds'],rel_tol=1e-14)
assert max(s['peak'] for s in supervisions)==cost['peak_bytes']
book=json.loads((ROOT/'tmp/task042/v39/ledger.json').read_text());assert book['closed'] and book['active'] is None and len(book['runs'])==len(supervisions)
admissions=[]
for p in probes:
 d=json.loads(raw[key(p['receipt_path'])]);fr={int(k):v for k,v in d['cpu_busy_fractions'].items()};reasons={}
 for name,b in d['cpu_ticks_before'].items():
  a=d['cpu_ticks_after'][name];assert abs(1-(a[3]-b[3]+a[4]-b[4])/max(sum(a)-sum(b),1)-fr[int(name)])<1e-15
 for tid,a in d['thread_ticks_after'].items():
  b=d['thread_ticks_before'].get(tid)
  if b and a[0]==b[0]:assert d['thread_delta_ticks'][tid]==a[1]-b[1]
 for cpu,v in fr.items():
  if v>.05:reasons.setdefault(cpu,[]).append('sample_busy_fraction_gt_0.05')
 for proc in d['neighbor_processes']:
  for t in proc['threads']:
   if len(t['affinity'])<=16:
    for cpu in t['affinity']:reasons.setdefault(cpu,[]).append('narrow_thread_affinity:'+str(t['tid']))
   elif d['thread_delta_ticks'].get(str(t['tid']),1)>0:reasons.setdefault(t['cpu'],[]).append('active_wide_thread:'+str(t['tid']))
 decisions=[dict(**t,eligible=not any(c in reasons for c in t['siblings']),excluded_siblings={str(c):reasons[c] for c in t['siblings'] if c in reasons}) for t in d['topology']]
 assert decisions==d['cpu_decisions'];assert [t['cpu'] for t in decisions if t['eligible']]==d['candidate_cpus'];assert d['selected_cpu'] in d['candidate_cpus'];admissions.append(dict(path=p['receipt_path'],cpu=d['selected_cpu']))
# Only frozen array byte/hash/header inspection, no FE or NumPy/BLAS execution.
receipts={}
def walk(v):
 if isinstance(v,dict):
  if all(k in v for k in ('path','sha256','members')) and str(v['path']).endswith('.npz'):receipts[v['path']]=v
  for w in v.values():walk(w)
 elif isinstance(v,list):
  for w in v:walk(w)
walk(read('array_inventory_v39.json'));array_checks=[]
for path,receipt in receipts.items():
 p=Path(path);assert sha(p.read_bytes())==receipt['sha256'];aliases=receipt.get('aliases',{})
 with zipfile.ZipFile(p) as z:
  assert set(z.namelist())=={k+'.npy' for k in receipt['members'] if k not in aliases}
  for name,m in receipt['members'].items():
   actual=aliases.get(name,name);assert actual not in aliases;b=z.read(actual+'.npy');assert b[:6]==b'\x93NUMPY';length=2 if b[6]==1 else 4;off=8+length;size=int.from_bytes(b[8:off],'little');meta=ast.literal_eval(b[off:off+size].decode().strip());assert not meta['fortran_order'];assert list(meta['shape'])==m['shape'] and meta['descr']==m['dtype'];assert sha(b[off+size:])==m['sha256'],(path,name)
 array_checks.append(dict(path=path,members=len(receipt['members']),stored_members=len(receipt['members'])-len(aliases),bytes=p.stat().st_size))
scalars=[]
def ratios(v):
 if isinstance(v,dict):
  if {'numerator','denominator','passed'} <= set(v):
   num,den=v['numerator'],v['denominator'];passed=num<=v['absolute_rule'] if 'absolute_rule' in v else num==0 if den==0 else num/den<=1e-10
   assert v['passed']==passed,v
   if den and v.get('relative') is not None:assert math.isclose(v['relative'],num/den,rel_tol=1e-13)
   scalars.append(v)
  for val in v.values():ratios(val)
 elif isinstance(v,list):
  for val in v:ratios(val)
ratios(read('component_checker_v39.json'))
xml=[]
for p,b in raw.items():
 if p.endswith('pytest.xml'):
  t=ET.fromstring(b);suite=list(t)[0] if t.tag=='testsuites' else t;xml.append(dict(path=p,tests=int(suite.get('tests')),failures=int(suite.get('failures')),errors=int(suite.get('errors'))))
# Final implementation snapshot separated from formal run source.
tests=read('tests_v39.json');source=tests['implementation_hashes']
for p,h in source.items():assert sha((ROOT/p).read_bytes())==h,p
old_docs=read('review_v36_documentation_checks.json');assert any('review_report_v35.md' in p for p in old_docs['files']) and not any('review_report_v36.md' in p for p in old_docs['files'])
gate=read('gate_decisions_v39.json')['replay_time_admission'];assert math.isclose(gate['native_limit_seconds']-gate['native_spent_seconds'],gate['remaining_seconds']);assert gate['local_setup_timestamp_span_seconds']>gate['remaining_seconds']
# Record, but do not turn file mtime span into a guaranteed runtime lower bound.
x=dict(reviewed_head=HEAD,previous_review=BASE,scope='stdlib read-only raw metadata/resources/hash/source audit; no new numerical/PDE/operator/factor/solve',raw_archives_verified=len(rawidx['files']),current_originals_matching_archived_version=originals,unmatched_current_originals=changed,protected_files=len(protected),history_files=history,compiled=compiled,formal_source_checks=formal_sources,final_source_hashes=source,supervisions=supervisions,CPU_admissions=admissions,costs=dict(supervised=sumruns,probes=sumprobes,bootstrap=3,close_upper=5,total_upper=total,native=sum(s['seconds'] for s in supervisions if s['role'] in ('ADAPTER','COUPLED','basis_audit'))),array_byte_verification=array_checks,scalar_ratio_checks=len(scalars),pytest_snapshots=xml,previous_document_checker_scope_gap=dict(record='review_v36_documentation_checks.json',actually_checked=list(old_docs['files']),review36_not_checked_by_that_record=True),replay_gate_record=gate,repository_index_sha256=sha((O/'repository_index.json').read_bytes()),dot_head='077ec9c8386c976da232093779279fb9d1a93033',source_changes=False,qualification='NATIVE_BOUNDARY_ADAPTER_QUALIFIED_ON_WITNESSES; COUPLED AND AFFINE RECOVERY NOT_QUALIFIED',limitations=['not a whole-repository line-by-line semantic audit','native MPI1 only','unknown missing failed tensor/q15-q17 metrics/cache payload preserved','file timestamps support conservative admission only, not a certified replay lower bound','reviewer ordinary IO/human cost not supervised'])
(O/'independent_checks.json').write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(raw=len(rawidx['files']),originals=originals,changed=changed,protected=len(protected),history=len(history),compiled=len(compiled),formal_sources=len(formal_sources),costs=x['costs'],arrays=len(array_checks),members=sum(v['members'] for v in array_checks),ratios=len(scalars),xml=xml),indent=2))
