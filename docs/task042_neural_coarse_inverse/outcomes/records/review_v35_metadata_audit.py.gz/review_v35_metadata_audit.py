# task042_review35_index.py
import json,hashlib,re,subprocess,gzip
from pathlib import Path
root=Path.cwd();out=root/'tmp/task042/review_v35';out.mkdir(parents=True,exist_ok=True)
items=[];total=0
for p in subprocess.check_output(['git','ls-files','-z']).decode().split('\0'):
 if not p:continue
 b=(root/p).read_bytes();row={'path':p,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
 try:
  s=b.decode();total+=len(b);row['lines']=len(s.splitlines());row['navigation']=[{'line':i,'text':v[:240]} for i,v in enumerate(s.splitlines(),1) if re.match(r'^(#{1,6} |(?:async )?def |class |    def )',v)]
 except UnicodeDecodeError:row['binary']=True
 items.append(row)
v=json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'files':items,'text_bytes':total},ensure_ascii=False).encode();(out/'repository_index.json').write_bytes(v)
print('index',len(items),total,hashlib.sha256(v).hexdigest())
d=root/'docs/task042_neural_coarse_inverse';print('authority',[(p.name,p.stat().st_size) for p in d.glob('*.md') if not p.name.startswith(('response_','review_'))]);print('history',len(list(d.glob('response_v*.md'))),len(list(d.glob('review_report_v*.md'))))
r=d/'outcomes/records'
for name in ['run_index_v37.json','raw_evidence_index_v37.json','jit_storage_gate_v37.json','tests_v37.json','boundary_metrics_v37.json','component_checker_v37.json']:
 x=json.loads((r/name).read_text());print(name,{k:(len(v) if isinstance(v,(list,dict)) else v) for k,v in x.items()})
print('raw example',json.loads((r/'raw_evidence_index_v37.json').read_text())['files'][0])


# task042_review35_audit.py
import ast,gzip,hashlib,json,math,struct,subprocess,zipfile,xml.etree.ElementTree as ET
from pathlib import Path
ROOT=Path.cwd();D=ROOT/'docs/task042_neural_coarse_inverse';R=D/'outcomes/records';O=ROOT/'tmp/task042/review_v35';HEAD='011718d84606cc052085c200d2ce767030f21e38';BASE='02fe5f860562f6a7ef689f9d53b061cfaf30a43b'
def git(*a):return subprocess.check_output(['git',*a])
def sha(b):return hashlib.sha256(b).hexdigest()
def read(n):return json.loads((R/n).read_text())
assert git('rev-parse','HEAD').decode().strip()==HEAD
raw={};versions={};rawidx=read('raw_evidence_index_v37.json')
for x in rawidx['files']:
 b=(ROOT/x['gzip']).read_bytes();assert sha(b)==x['gzip_sha256'];v=gzip.decompress(b);assert sha(v)==x['sha256'] and len(v)==x['bytes'];raw[x['original_path']]=v;versions.setdefault(x['original_path'],[]).append(v)
originals=0;changed=[]
for p,vs in versions.items():
 if Path(p).exists():
  if Path(p).read_bytes() in vs:originals+=1
  else:changed.append(p)
protected=[];history=[]
append={'README.md','outcomes/summary.md','outcomes/test_summary.md','outcomes/changed_files.md'}
for p in git('ls-tree','-r','--name-only',BASE,str(D.relative_to(ROOT))).decode().splitlines():
 old=git('show',BASE+':'+p);now=(ROOT/p).read_bytes();rel=str(Path(p).relative_to(D.relative_to(ROOT)))
 if rel in append:assert now.endswith(old),p
 else:assert now==old,p;protected.append(p)
 if Path(p).name.startswith(('review_report_v','response_v')):history.append(p)
compiled=[]
for p in git('diff','--name-only',BASE,HEAD).decode().splitlines():
 if p.endswith('.py'):compile((ROOT/p).read_text(),p,'exec');compiled.append(p)
source=read('deployment_package_v37.json')['implementation_hashes']
for p,h in source.items():assert sha((ROOT/p).read_bytes())==h
stages={}
for name,x in read('run_index_v37.json')['parents'].items():
 b=Path(x['path']).read_bytes();assert sha(b)==x['sha256'];stages[name]=json.loads(b)
cost=read('resource_costs_v37.json');supervisions=[]
for row in cost['rows']:
 folder=Path(row['directory']);p=folder/'supervision/summary.json';s=json.loads(raw[str(p)]);samples=[json.loads(b) for b in raw[str(folder/'supervision/resources.jsonl')].splitlines()]
 assert len(samples)==s['samples']
 for v in samples:
  assert v['rss_bytes']==sum(m['rss_bytes'] for m in v['members']);assert v['swap_bytes']==sum(m['swap_bytes'] for m in v['members'])
 assert max(v['rss_bytes'] for v in samples)==s['sampled_process_tree_rss_peak_bytes']==row['peak_bytes']
 assert max(v['swap_bytes'] for v in samples)==0 and s['descendants_cleared'];assert s['elapsed_seconds']==row['elapsed_seconds']
 supervisions.append(dict(role=row['role'],path=str(p),seconds=s['elapsed_seconds'],peak=s['sampled_process_tree_rss_peak_bytes'],samples=len(samples),status=s['classification']))
probes=[json.loads(p.read_text()) for p in (ROOT/'tmp/task042/v37').glob('probe_*.json')];sumruns=sum(s['seconds'] for s in supervisions);sumprobes=sum(p['elapsed_seconds'] for p in probes);total=sumruns+sumprobes+3
assert math.isclose(total,cost['charged_final'],rel_tol=1e-14)
book=json.loads((ROOT/'tmp/task042/v37/ledger.json').read_text());assert book['closed'] and book['active'] is None and len(book['runs'])==len(supervisions)
admissions=[]
for p in probes:
 d=json.loads(raw[p['receipt_path']]);fr={int(k):v for k,v in d['cpu_busy_fractions'].items()};reasons={}
 for key,b in d['cpu_ticks_before'].items():
  a=d['cpu_ticks_after'][key];assert abs(1-(a[3]-b[3]+a[4]-b[4])/max(sum(a)-sum(b),1)-fr[int(key)])<1e-15
 for tid,a in d['thread_ticks_after'].items():
  b=d['thread_ticks_before'].get(tid)
  if b and a[0]==b[0]:assert d['thread_delta_ticks'][tid]==a[1]-b[1]
 for cpu,v in fr.items():
  if v>.05:reasons.setdefault(cpu,[]).append('sample_busy_fraction_gt_0.05')
 for proc in d['neighbor_processes']:
  for t in proc['threads']:
   if len(t['affinity'])<=16:
    for cpu in t['affinity']:reasons.setdefault(cpu,[]).append('narrow_thread_affinity:'+str(t['tid']))
   elif d['thread_delta_ticks'].get(str(t['tid']),1)>0:reasons.setdefault(t['cpu'],[]).append('active_wide_thread:'+str(t['tid']))
 decisions=[dict(**t,eligible=not any(c in reasons for c in t['siblings']),excluded_siblings={str(c):reasons[c] for c in t['siblings'] if c in reasons}) for t in d['topology']]
 assert decisions==d['cpu_decisions'];assert [t['cpu'] for t in decisions if t['eligible']]==d['candidate_cpus'];assert d['selected_cpu'] in d['candidate_cpus'];admissions.append(dict(path=p['receipt_path'],cpu=d['selected_cpu']))
# Inspect file/member bytes only. No array numerical recomputation or FE import.
array_checks=[]
for key,receipt in rawidx['large_array_files'].items():
 p=Path(receipt['path']);assert sha(p.read_bytes())==receipt['sha256']
 with zipfile.ZipFile(p) as z:
  assert set(z.namelist())=={k+'.npy' for k in receipt['members']}
  for name,m in receipt['members'].items():
   b=z.read(name+'.npy');assert b[:6]==b'\x93NUMPY';length=2 if b[6]==1 else 4;off=8+length;size=int.from_bytes(b[8:off],'little');meta=ast.literal_eval(b[off:off+size].decode().strip());assert not meta['fortran_order'];assert list(meta['shape'])==m['shape'] and meta['descr']==m['dtype'];assert sha(b[off+size:])==m['sha256']
 array_checks.append(dict(name=key,path=str(p),members=len(receipt['members']),bytes=p.stat().st_size))
checks=read('component_checker_v37.json');scalars=[]
for section in ('independent_checks','independent_quadrature_checks'):
 for c in checks[section]:
  num=c['numerator'];den=c['denominator'];passed=num==0 if den==0 else num/den<=1e-10
  assert c['passed']==passed and (c['relative'] is None if den==0 else math.isclose(c['relative'],num/den,rel_tol=1e-14));scalars.append(c)
assert all(c['passed'] for c in checks['independent_checks']);assert all(c['passed'] for c in checks['independent_quadrature_checks'] if c['kind'].startswith('q30'))
metrics=read('boundary_metrics_v37.json');assert max(c['relative'] for c in checks['independent_quadrature_checks'] if c['kind'].startswith('q15'))==metrics['q15_q30_max']
xml=[]
for p,b in raw.items():
 if p.endswith('pytest.xml'):
  t=ET.fromstring(b);suite=list(t)[0] if t.tag=='testsuites' else t;xml.append(dict(path=p,tests=int(suite.get('tests')),failures=int(suite.get('failures')),errors=int(suite.get('errors'))))
J=read('jit_storage_gate_v37.json');print('JITarchive',J['archive_manifest']);print('storage_stop',J['external_stop'])
x=dict(reviewed_head=HEAD,previous_review=BASE,scope='stdlib read-only raw metadata/resources/hash/source audit; no new FE, matrix, factor or vector numerical experiment',raw_archives_verified=len(rawidx['files']),current_originals_matching_archived_version=originals,unmatched_current_originals=changed,protected_files=len(protected),history_files=history,compiled=compiled,source_hashes=source,supervisions=supervisions,CPU_admissions=admissions,costs=dict(supervised=sumruns,probes=sumprobes,bootstrap=3,total=total),array_byte_verification=array_checks,scalar_ratio_checks=len(scalars),pytest_snapshots=xml,repository_index_sha256=sha((O/'repository_index.json').read_bytes()),dot_head='077ec9c8386c976da232093779279fb9d1a93033',source_changes=False,qualification='P6_TILE_INTERFACE_QUALIFIED_ON_PARTIAL_WITNESS',source_derived_scaling=dict(face_count_per_side=73*36,modes=32060,two_pass_visits=2*32060*73*36,duplicated_plan_references=32060*73*36),limitations=['not a whole-repository line-by-line semantic audit','JIT large archive metadata audited; compressed payload audit follows separately','no new numerical checker run'])
(O/'independent_checks.json').write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in x.items() if k in ['raw_archives_verified','current_originals_matching_archived_version','unmatched_current_originals','protected_files','compiled','costs','array_byte_verification','pytest_snapshots']},indent=2))


# task042_review35_jit.py
import gzip,hashlib,json,time
from pathlib import Path
root=Path.cwd();r=root/'docs/task042_neural_coarse_inverse/outcomes/records';o=root/'tmp/task042/review_v35/independent_checks.json';x=json.loads(o.read_text());j=json.loads((r/'jit_storage_gate_v37.json').read_text());p=Path(j['archive_manifest']['path']);assert hashlib.sha256(p.read_bytes()).hexdigest()==j['archive_manifest']['sha256'];m=json.loads(p.read_text());records=[];start=time.monotonic()
for row in m['members']:
 h=hashlib.sha256();size=0;archive=Path(row['archive']);assert archive.stat().st_size==row['archive_bytes']
 with gzip.open(archive,'rb') as f:
  while b:=f.read(2**20):h.update(b);size+=len(b)
 assert h.hexdigest()==row['sha256'] and size==row['bytes'];records.append(dict(archive=row['archive'],raw_bytes=size,compressed_bytes=row['archive_bytes'],sha256=h.hexdigest()))
assert len(records)==34 and sum(v['raw_bytes'] for v in records)==1559383311
x['jit_archives']={'members':records,'total_raw_bytes':sum(v['raw_bytes'] for v in records),'total_compressed_bytes':sum(v['compressed_bytes'] for v in records),'verification_seconds':time.monotonic()-start};x['limitations']=[s for s in x['limitations'] if not s.startswith('JIT large')];o.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');print({k:v for k,v in x['jit_archives'].items() if k!='members'})
