"""Final bounded metadata/hash collection; no FE or NumPy imports."""
import gzip
import hashlib
import json
import subprocess
from pathlib import Path

ROOT=Path('/home/fenics/Projects/NN-Lab');T=ROOT/'tmp/task042/v37';R=ROOT/'docs/task042_neural_coarse_inverse/outcomes/records'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(n,x):(R/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
raw=json.loads((R/'raw_evidence_index_v37.json').read_text());dedup={(v['original_path'],v['sha256']):v for v in raw['files']}
for v in raw['files']:
    p=ROOT/v['gzip'];data=gzip.decompress(p.read_bytes())
    if sha(p)!=v['gzip_sha256'] or len(data)!=v['bytes'] or hashlib.sha256(data).hexdigest()!=v['sha256']:raise ValueError('immutable raw mismatch '+str(p))
book=json.loads((T/'ledger.json').read_text())
rows=[]
for entry in book['runs']:
    d=Path(entry['folder']);summary=d/('summary.json' if d.name.startswith('aux_') else 'run_summary.json')
    rows.append({**{k:entry[k] for k in ['role','source_sha','elapsed_seconds','classification','exit_code','peak_bytes','swap_bytes','descendants_cleared']},'directory':str(d),'summary_sha256':sha(summary),'cpu':json.loads((d/'resource_baseline.json').read_text())['cpu']})
    for p in d.rglob('*'):
        if not p.is_file() or p.suffix not in ('.json','.jsonl','.log','.stdout','.stderr','.xml','.dat','.txt'):continue
        h=sha(p);key=(str(p),h)
        if key in dedup:continue
        data=p.read_bytes();out=R/('raw_v37_final_'+hashlib.sha256(str(p).encode()).hexdigest()[:8]+'_'+h[:8]+'_'+p.name+'.gz');out.write_bytes(gzip.compress(data,compresslevel=1,mtime=0))
        if gzip.decompress(out.read_bytes())!=data:raise ValueError('raw final readback')
        dedup[key]={'original_path':str(p),'gzip':str(out.relative_to(ROOT)),'bytes':len(data),'sha256':h,'gzip_sha256':sha(out)}
for p in [T/n for n in ['final_ruff.stdout','final_ruff.stderr','recover_archive.py','collect_final.py']]:
    data=p.read_bytes();h=sha(p);out=R/('raw_v37_final_'+h[:12]+'_'+p.name+'.gz');out.write_bytes(gzip.compress(data,compresslevel=1,mtime=0));dedup[(str(p),h)]={'original_path':str(p),'gzip':str(out.relative_to(ROOT)),'bytes':len(data),'sha256':h,'gzip_sha256':sha(out)}
raw['files']=list(dedup.values());dump('raw_evidence_index_v37.json',raw)
idx=json.loads((R/'run_index_v37.json').read_text());idx['runs']=rows;idx['pending_final_metadata_run']=book['active']['folder'];dump('run_index_v37.json',idx)
checked=json.loads((R/'component_checker_v37.json').read_text());wp=json.loads((R/'witness_inventory_v37.json').read_text())
worst=max([v for v in checked['independent_quadrature_checks'] if v['kind'].startswith('q15')],key=lambda v:v['relative'] or 0)
dump('gate_decisions_v37.json',{'q15':{'status':'NOT_QUALIFIED_ON_FINITE_WITNESS','limit':1e-10,'worst':worst,'mode':wp['selected_modes'][worst['index']]},'ordinary_tile':'P6_TILE_INTERFACE_QUALIFIED_ON_PARTIAL_WITNESS','native_q60':'NOT_RUN_STORAGE_GATE','max_ordinary':'NOT_RUN_STORAGE_GATE','periodic_seam_corner':'NOT_RUN_STORAGE_GATE','target_boundary':'NOT_QUALIFIED_INCOMPLETE_NATIVE_Q60_AND_PERIODIC_COVERAGE','legacy_v36_scope_annotation':'LEGACY_CLIPPED_SURFACE_EQUIVALENCE','target_solve':'TARGET_SOLVE_NOT_AUTHORIZED_OR_NOT_QUALIFIED','global_p4_factor':'ABSENT_IN_THIS_BATCH','new_volume_actions':0,'new_LU':0,'new_QR':0,'neural20':'NOT_DEMONSTRATED'})
arrays=raw['large_array_files']
for key,receipt in arrays.items():
    if sha(receipt['path'])!=receipt['sha256']:raise ValueError('final scientific file hash '+key)
dump('delivery_integrity_v37.json',{'raw_versions':len(dedup),'large_file_hashes_checked':list(arrays),'source_sha':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'new_scientific_evaluation':False,'archive_version_repair_verified':True,'all_fees_pending_current_supervisor_settlement':True})
print(json.dumps({'raw_versions':len(dedup),'large_hash_files':len(arrays),'worst_q15_original_index':wp['selected_modes'][worst['index']]['mode_index']}),flush=True)
