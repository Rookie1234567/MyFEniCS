import ast,gzip,hashlib,json,math,struct,subprocess,zipfile
from pathlib import Path
ROOT=Path.cwd();D=ROOT/'docs/task042_neural_coarse_inverse';R=D/'outcomes/records';HEAD='6c3dadb21aa0edfa7498e5865cf955766882f58a';BASE='e73baa45f59c0fcfc12ee1c00614c6933568f27e'
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a])
def read(n):return json.loads((R/(n+'.json')).read_text())
def near(a,b):return math.isclose(a,b,rel_tol=2e-12,abs_tol=1e-10)
assert git('rev-parse','HEAD').decode().strip()==HEAD
archive=read('raw_evidence_index_v48');versions={}
for row in archive['entries']:
 b=(ROOT/row['archive']).read_bytes();assert sha(b)==row['archive_sha256'] and len(b)==row['archive_bytes'];raw=gzip.decompress(b);assert sha(raw)==row['raw_sha256'] and len(raw)==row['raw_bytes'];versions.setdefault(str((ROOT/row['original_path']).resolve()),[]).append(raw)
unmatched=[];matched=0;missing=[]
for p,v in versions.items():
 f=Path(p)
 if not f.exists():missing.append(p)
 elif f.read_bytes() not in v:unmatched.append({'path':p,'sha256':sha(f.read_bytes()),'bytes':f.stat().st_size})
 else:matched+=1
files=read('delivery_index_v48');delivery=[]
for p,r in files['records'].items():
 b=(ROOT/p).read_bytes();assert sha(b)==r['sha256'] and len(b)==r['bytes'];delivery.append(p)
assert sha((D/'response_v48.md').read_bytes())==files['response_sha256']
assert sha((D/'outcomes/lossless_vector_storage_v48.md').read_bytes())==files['outcome_sha256']
append={'README.md','outcomes/summary.md'};protected=[]
for line in git('ls-tree','-r',BASE,str(D.relative_to(ROOT))).decode().splitlines():
 meta,p=line.split('\t');oid=meta.split()[2];body=(ROOT/p).read_bytes();rel=str(Path(p).relative_to(D.relative_to(ROOT)))
 if rel in append:assert body.endswith(git('show',BASE+':'+p)),p
 else:assert hashlib.sha1(b'blob '+str(len(body)).encode()+b'\0'+body).hexdigest()==oid,p;protected.append(p)
for p in ('docs/development_progress.md','docs/development_model_registry.md'):assert (ROOT/p).read_bytes().endswith(git('show',BASE+':'+p))
# Every scientific file in collector inventory; never unpickle transactions.
inv=read('array_and_bank_inventory_v48');count={};total=0;bank_headers={};npz_members=0;npz_member_bytes=0;package_member_meta={}
for row in inv['files']:
 p=ROOT/row['path'];b=p.read_bytes();assert sha(b)==row['sha256'] and len(b)==row['bytes'],p
 count[p.suffix]=count.get(p.suffix,0)+1;total+=len(b)
 if p.suffix=='.bank':
  assert b[:6]==b'WB48\x00\x01';n=struct.unpack_from('<I',b,6)[0];h=json.loads(b[10:10+n]);payload=b[10+n:]
  flat=sorted(v for block in h['blocks'] for rows in block['rows'] for v in rows);assert flat==list(range(h['ntrace']))
  for rows in h['index']:
   assert len(rows)==len(h['blocks'])
   for x in rows:
    chunk=payload[x['offset']:x['offset']+x['length']];assert len(chunk)==x['length'] and sha(chunk)==x['encoded_sha256']
  for w in h['weights']:
   chunk=payload[w['offset']:w['offset']+w['length']];assert len(chunk)==w['length'] and sha(chunk)==w['sha256']
  bank_headers[str(p)]={'method':h['method'],'vectors':h['vectors'],'trace':h['ntrace'],'bytes':len(b),'header':n,'model':sum(w['length'] for w in h['weights']),'blocks':len(h['blocks'])}
 elif p.suffix=='.npz':
  metas={}
  with zipfile.ZipFile(p) as z:
   assert len(z.namelist())==len(set(z.namelist()))
   for name in z.namelist():
    with z.open(name) as f:
     magic=f.read(8);assert magic[:6]==b'\x93NUMPY';k=2 if magic[6]==1 else 4;size=struct.unpack('<H' if k==2 else '<I',f.read(k))[0];hdr=ast.literal_eval(f.read(size).decode());assert not hdr['fortran_order']
     h=hashlib.sha256();n=0
     for chunk in iter(lambda:f.read(2**20),b''):h.update(chunk);n+=len(chunk)
     metas[name.removesuffix('.npy')]={'shape':list(hdr['shape']),'dtype':hdr['descr'],'sha256':h.hexdigest()};npz_members+=1;npz_member_bytes+=n
  package_member_meta[str(p)]=metas
# Bind scientific array member hashes wherever the published stage points to them.
idx=read('run_index_v48');stages={};receipts_verified=set()
def check_receipts(v):
 if isinstance(v,dict):
  if isinstance(v.get('path'),str) and 'sha256' in v and 'members' in v:
   p=str(Path(v['path']).resolve());assert sha(Path(p).read_bytes())==v['sha256'];metas=package_member_meta.get(p)
   if metas is not None:
    assert set(metas)==set(v['members']) and not v.get('aliases',{})
    for k,m in metas.items():assert all(v['members'][k][a]==m[a] for a in m),p
    receipts_verified.add(p)
  for a in v.values():check_receipts(a)
 elif isinstance(v,list):
  for a in v:check_receipts(a)
for name,receipt in idx['pointers'].items():
 p=Path(receipt['path']);b=p.read_bytes();assert sha(b)==receipt['sha256'];stages[name]=json.loads(b);check_receipts(stages[name])
partial_packages=[]
for p,meta in package_member_meta.items():
 if p not in receipts_verified:
  matches=[q for q in receipts_verified if package_member_meta[q]==meta]
  assert matches,p
  partial_packages.append({'path':p,'member_identity_matches':matches})
# All final supervised runs, not the pre-collector 34-run snapshot.
ledger=json.loads((ROOT/'tmp/task042/v48/ledger.json').read_text());assert ledger['closed'] and ledger['active'] is None
cost=read('resource_costs_final_v48');source_cache={};runs=[];probe_by={};probes=[]
for p in (ROOT/'tmp/task042/v48').glob('probe_*.json'):
 b=p.read_bytes();assert b in versions[str(p)];v=json.loads(b);probes.append(v);probe_by[str(Path(v['receipt_path']).parent)]=v['elapsed_seconds']
 a=json.loads(Path(v['receipt_path']).read_text());assert a['selected_cpu'] in a['candidate_cpus']
 for cpu,before in a['cpu_ticks_before'].items():
  after=a['cpu_ticks_after'][cpu];fraction=1-(after[3]-before[3]+after[4]-before[4])/max(sum(after)-sum(before),1);assert near(fraction,a['cpu_busy_fractions'][cpu])
for row in ledger['runs']:
 folder=Path(row['folder']);m=json.loads((folder/'run_manifest.json').read_text());s=json.loads((folder/'supervision/summary.json').read_text());samples=[json.loads(l) for l in (folder/'supervision/resources.jsonl').read_text().splitlines()]
 for v in samples:
  assert v['rss_bytes']==sum(x['rss_bytes'] for x in v['members']);assert v['swap_bytes']==sum(x['swap_bytes'] for x in v['members'])==0
 assert row['source_sha']==m['source_sha'] and row['elapsed_seconds']==s['elapsed_seconds'] and s['descendants_cleared']
 assert row['peak_bytes']==max(v['rss_bytes'] for v in samples) and s['samples']==len(samples)
 assert row['numerical_counts']['upper']=={'actions':0,'B_actions':0}
 for p,h in m['implementation_hashes'].items():
  key=(row['source_sha'],p)
  if key not in source_cache:source_cache[key]=sha(git('show',row['source_sha']+':'+p))
  assert source_cache[key]==h,(folder,p)
 gaps=[v['elapsed_seconds']-u['elapsed_seconds'] for u,v in zip(samples,samples[1:])]
 receipt=json.loads((folder/'summary.json').read_text())
 launch=receipt.get('launch_wall_seconds')
 runs.append({'role':row['role'],'folder':str(folder),'source_sha':row['source_sha'],'seconds':row['elapsed_seconds'],'samples':len(samples),'peak':row['peak_bytes'],'max_gap':max(gaps,default=0),'exit':row['exit_code'],'launch':launch,'receipt_keys':list(receipt)})
# Accounting values recomputed from settled summary fields, including metadata.
supervised=math.fsum(x['seconds'] for x in runs);probe=math.fsum(x['elapsed_seconds'] for x in probes)
assert near(supervised,cost['supervised_seconds']) and near(probe,cost['probe_seconds'])
launcher=math.fsum(max(0,r['launch']-r['seconds']-probe_by.get(r['folder'],0)) for r in runs);assert near(launcher,cost['non_nested_launcher_seconds'])
setup=json.loads((ROOT/'tmp/task042/v48/metadata_setup_receipt.json').read_text())['seconds'];fee=json.loads((ROOT/'tmp/task042/v48/post_settlement_fee.json').read_text())
known=supervised+probe+cost['non_nested_launcher_seconds']+setup+fee['measured_within_tail_seconds'];charged=supervised+probe+cost['non_nested_launcher_seconds']+setup+fee['seconds']
assert near(known,cost['known_new_loaded_lower_seconds']) and near(charged,cost['charged_new_loaded_seconds'])
assert near(cost['historical_known_lower_seconds']+known,cost['known_history_plus_new_lower_seconds'])
assert max(r['peak'] for r in runs)==cost['sampled_whole_tree_peak_bytes'] and near(max(r['max_gap'] for r in runs),cost['max_actual_sample_gap_seconds'])
# Recompute model choice and finite ratios; no new model evaluation.
models=[]
for kind in ('LIN','NN'):
 r=stages['TRAIN_'+kind];assert r['updates']==len(r['history'])==256 and [h['update'] for h in r['history']]==list(range(1,257))
 assert all(math.isfinite(h['loss']) for h in r['history']) and r['parameter_change_norm']>0
 for g in r['gradient_gate']['checks']:
  e=abs(g['central']-g['analytic'])/max(1,abs(g['analytic']));assert near(e,g['operational_error']) and e<=1e-6
 chosen=min(r['checkpoints'],key=lambda x:(x['validation_bank']['file_bytes'],x['update']));assert chosen==r['chosen'] and chosen['update']==0
 for c in r['checkpoints']:assert Path(c['validation_bank']['path']).stat().st_size==c['validation_bank']['file_bytes']
 models.append({'kind':kind,'updates':len(r['history']),'parameters':r['parameter_count'],'selected':chosen['update'],'validation_bytes':[c['validation_bank']['file_bytes'] for c in r['checkpoints']],'maximum_FD_error':max(x['operational_error'] for x in r['gradient_gate']['checks'])})
check=read('lossless_checker_v48');comp=read('candidate_comparison_v48');assert len(check['checks'])==len(comp['rows'])==20
comparisons=[]
for family in ('heldout','migration'):
 rr=[r for r in comp['rows'] if r['family']==family];assert len(rr)==10
 by={r['method']:r for r in rr};raw=by['RAW'];nn=by['NN'];best=min(rr,key=lambda x:x['objects']['complete_trace_bank_object_bytes']);filebest=min(rr,key=lambda x:x['file_bytes'])
 for row in rr:
  c=next(c for c in check['checks'] if c['family']==family and c['method']==row['method']);assert all(c[k] for k in ('trace_all_bits','full_canonical_all_bits','all_consumer_outputs_all_bits'))
  assert c['bank_sha256']==row['bank_sha256'] and c['consumer_arrays_sha256']==row['consumer_receipt']['sha256']
  v=row['objects'];assert v['resident_bank_bytes']+v['compulsory_workspace_bytes']==v['complete_trace_bank_object_bytes'];assert c['object_bytes']==v
 comparisons.append({'family':family,'best_online':best['method'],'best_file':filebest['method'],'NN_complete_ratio_to_RAW':nn['objects']['complete_trace_bank_object_bytes']/raw['objects']['complete_trace_bank_object_bytes'],'NN_resident_exceeds_RAW_80':nn['objects']['resident_bank_bytes']>.8*raw['objects']['complete_trace_bank_object_bytes'],'NN_file_ratio_to_best':nn['file_bytes']/filebest['file_bytes'],'rows':rr})
# First failure occurs after freeze; audit the saved timing/source trajectory.
freeze=stages['FREEZE'];initial_failed=next(r for r in ledger['runs'] if r['exit_code'])
assert freeze['frozen_utc'] < initial_failed['before_clock']['observed_utc']
metadata=read('tests_v48')['post_final_metadata_15_docs'];post_doc_versions=[]
for p,h in metadata['docs'].items():post_doc_versions.append({'path':p,'tested_sha256':h,'final_sha256':sha((ROOT/p).read_bytes()),'matches_final':h==sha((ROOT/p).read_bytes())})
out={'HEAD':HEAD,'review_base':BASE,'archive_entries':len(archive['entries']),'current_paths_matched':matched,'unmatched':unmatched,'missing':missing,'delivery_records':len(delivery),'protected_files':len(protected),'inventory_file_counts':count,'inventory_bytes':total,'npz_members_hashed':npz_members,'npz_member_bytes':npz_member_bytes,'NPZ_member_receipts_verified':len(receipts_verified),'failed_partial_package_equivalence':partial_packages,'bank_headers_verified':bank_headers,'source_snapshot_pairs':len(source_cache),'nonnested_launcher_recomputed':launcher,'runs':runs,'model_recomputation':models,'candidate_recomputation':comparisons,'supervised':supervised,'probe':probe,'metadata_setup':setup,'known':known,'charged':charged,'history_known_lower':cost['historical_known_lower_seconds']+known,'peak':cost['sampled_whole_tree_peak_bytes'],'max_gap':cost['max_actual_sample_gap_seconds'],'freeze_utc':freeze['frozen_utc'],'first_failed_heldout_after_freeze':True,'post_document_test_versions':post_doc_versions,'closed':True,'new_reviewer_FE_A_B_model_training_inference':0,'review_scope':'byte/header/hash and saved scalar checks; no scientific model/codec replay; tiny source lifetime witness separate','review_cost':'manual/hash/IO not supervised; no performance claim'}
Path('/tmp/task042_review46_audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k in ('archive_entries','current_paths_matched','unmatched','missing','protected_files','inventory_file_counts','inventory_bytes','npz_members_hashed','NPZ_member_receipts_verified','source_snapshot_pairs','known','charged','history_known_lower','post_document_test_versions')},ensure_ascii=False,indent=2))
