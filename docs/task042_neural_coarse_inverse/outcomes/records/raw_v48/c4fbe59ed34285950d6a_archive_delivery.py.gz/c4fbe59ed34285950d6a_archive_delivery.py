"""Explicit metadata/hash archiver snapshot; no scientific array decoding."""
import gzip
import hashlib
import json
import os
import time
from pathlib import Path

from src.runners.task042_shared import write_json
from src.solvers.bound_array_identity import file_hash
from src.solvers.vector_storage_scope import ARTIFACT, ROOT, guard_source, window

start=time.monotonic()
folder=Path(os.environ['TASK042_V36_AUX_DIRECTORY'])
window.guard_worker_parent()
launch=guard_source(folder)
record_root=ROOT/'docs/task042_neural_coarse_inverse/outcomes/records'
own_source={'category':'METADATA_ARCHIVER_WORKTREE_SNAPSHOT','launch_HEAD':launch['source_sha'],
            'script':str(Path(__file__).relative_to(ROOT)),'script_sha256':file_hash(__file__),
            'scientific_array_reads':0,'tracked_numeric_implementation_clean_at_start':True}
archives=record_root/'raw_v48';archives.mkdir(exist_ok=True)
rows=[]
for parent in (window.TMP,ARTIFACT):
    for path in sorted(parent.rglob('*')):
        if not path.is_file() or path.is_relative_to(folder) or path.suffix in ('.npz','.pt','.bank','.pyc','.gz') or 'pycache' in path.parts or 'ruff' in path.parts:
            continue
        raw=path.read_bytes();digest=hashlib.sha256(raw).hexdigest()
        destination=archives/(digest[:20]+'_'+path.name+'.gz')
        if not destination.exists():
            destination.write_bytes(gzip.compress(raw,compresslevel=6,mtime=0))
        if gzip.decompress(destination.read_bytes())!=raw:
            raise ValueError('raw archive byte equality')
        rows.append({'original_path':str(path.relative_to(ROOT)),'raw_bytes':len(raw),'raw_sha256':digest,
                     'archive':str(destination.relative_to(ROOT)),'archive_sha256':file_hash(destination),
                     'archive_bytes':destination.stat().st_size})
write_json(record_root/'raw_evidence_index_v48.json',{'status':'FROZEN_ARCHIVE_WITH_FINAL_METADATA_PENDING','entries':rows,
           'entries_count':len(rows),'active_archiver_folder_not_yet_settled':str(folder),
           'non_numeric_tool_identity':own_source,'large_arrays_banks_models':'ignored, file/member receipts not copied into Git'})
docs=window.TMP/'aux_metadata_docs_001/documentation_checks.json'
write_json(record_root/'documentation_checks_v48.json',json.loads(docs.read_text()))
tests=json.loads((record_root/'tests_v48.json').read_text())
tests.update(status='PASSED_LOCAL',final_document_check_pending=False,
             final_document_receipt={'path':str(docs),'sha256':file_hash(docs)},
             final_focused_receipt={'path':str(window.TMP/'aux_pre_005/tests.json'),'sha256':file_hash(window.TMP/'aux_pre_005/tests.json')},
             final_15_docs_and_10_codec_tests=True,final_compile_Ruff=True)
write_json(record_root/'tests_v48.json',tests)
write_json(folder/'metadata_archive_source.json',own_source)
print(json.dumps({'raw_versions':len(rows),'metadata_seconds_before_exit':time.monotonic()-start,'source_category':own_source['category']}),flush=True)
