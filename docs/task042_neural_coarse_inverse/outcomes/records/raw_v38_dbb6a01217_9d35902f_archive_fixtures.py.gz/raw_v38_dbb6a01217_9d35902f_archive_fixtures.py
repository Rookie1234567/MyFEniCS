import gzip,hashlib,json,os
from pathlib import Path
from src.runners.task042_shared import write_json
root=Path('/home/fenics/Projects/NN-Lab/tmp/task042/v38')
dest=root/'fixture_archives';dest.mkdir(exist_ok=True)
rows=[]
for p in sorted(root.glob('aux_pre_*/fixtures/**/*.npz')):
 if p.is_symlink() or not p.resolve().is_relative_to(root):raise ValueError('own synthetic fixture scope')
 h=hashlib.sha256();size=0;out=dest/(hashlib.sha256(str(p).encode()).hexdigest()[:16]+'_'+p.name+'.gz')
 temp=out.with_suffix('.partial')
 with p.open('rb') as src,gzip.open(temp,'wb',compresslevel=1) as dst:
  while b:=src.read(2**20):h.update(b);size+=len(b);dst.write(b)
 h2=hashlib.sha256();n=0
 with gzip.open(temp,'rb') as src:
  while b:=src.read(2**20):h2.update(b);n+=len(b)
 if n!=size or h.digest()!=h2.digest():raise ValueError('lossless fixture archive')
 os.replace(temp,out)
 rows.append(dict(original=str(p),archive=str(out),sha256=h.hexdigest(),bytes=size,archive_bytes=out.stat().st_size,readback=True))
 write_json(dest/'manifest.json',dict(members=rows))
 p.unlink()
print(json.dumps(dict(files=len(rows),raw_bytes=sum(r['bytes'] for r in rows),compressed_bytes=sum(r['archive_bytes'] for r in rows))))
