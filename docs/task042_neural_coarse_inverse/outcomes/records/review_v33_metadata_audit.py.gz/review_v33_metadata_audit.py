import json,gzip,hashlib,subprocess,math,tarfile,re
from pathlib import Path
from xml.etree import ElementTree as ET
ROOT=Path('/home/fenics/Projects/NN-Lab');D=ROOT/'docs/task042_neural_coarse_inverse';R=D/'outcomes/records';O=ROOT/'tmp/task042/review_v33'
HEAD='9a6cadff62771d63a4996a6dccc9424df431ee4c';BASE='e1926a9cb42329276da4a26f4304f71cbbf97198'
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT)
def sha(b):return hashlib.sha256(b).hexdigest()
def read(n):return json.loads((R/n).read_text())
assert git('rev-parse','HEAD').decode().strip()==HEAD
verified={};skipped=[];raws={};archived=[]
def verify(x):
 if isinstance(x,dict):
  if isinstance(x.get('path'),str) and isinstance(x.get('sha256'),str):
   p=Path(x['path']);p=p if p.is_absolute() else ROOT/p
   if p.suffix in ('.npz','.npy','.bin','.h5') or p.name.endswith('.tar.gz'):skipped.append(str(p));return
   b=p.read_bytes();assert sha(b)==x['sha256'],p
   if 'bytes' in x:assert len(b)==x['bytes'],p
   verified[str(p)]=dict(sha256=sha(b),bytes=len(b))
  for v in x.values():verify(v)
 elif isinstance(x,list):
  for v in x:verify(v)
for n in ('source_inventory_v35.json','run_index_v35.json','tests_v35.json','delivery_integrity_v35.json'):verify(read(n))
rawidx=read('raw_evidence_index_v35.json')
for x in rawidx['raw']:
 verify(x['stored']);b=gzip.decompress(Path(x['stored']['path']).read_bytes());assert sha(b)==x['original_sha256'] and len(b)==x['original_bytes']
 p=Path(x['original'])
 if p.exists():assert p.read_bytes()==b,p
 else:archived.append(str(p))
 raws[str(p)]=b
for x in rawidx.get('archived_actor_resources',[]):
 verify(x['stored']);b=gzip.decompress(Path(x['stored']['path']).read_bytes());p=ROOT/x['original'];raws[str(p)]=b
 if 'original_sha256' in x:assert sha(b)==x['original_sha256']
# All old task docs/records protected except append-only overview files.
oldpaths=git('ls-tree','-r','--name-only',BASE,str(D.relative_to(ROOT))).decode().splitlines();history=[];protected=[]
append={'README.md','outcomes/summary.md','outcomes/test_summary.md','outcomes/changed_files.md'}
for p in oldpaths:
 rel=str(Path(p).relative_to(D.relative_to(ROOT)));old=git('show',BASE+':'+p);now=(ROOT/p).read_bytes()
 if rel in append:assert now.endswith(old),p
 else:assert now==old,p;protected.append(p)
 if Path(p).name.startswith(('review_report_v','response_v')):history.append(p)
compiled=[]
for p in git('diff','--name-only',BASE,HEAD).decode().splitlines():
 if p.endswith('.py'):compile((ROOT/p).read_text(),p,'exec');compiled.append(p)
idx=read('run_index_v35.json');result=json.loads(Path(idx['result']['path']).read_text());book=json.loads((ROOT/'tmp/task042/v35/ledger.json').read_text());cost=read('resource_costs_v35.json')
assert book['closed'] and book['active'] is None and len(book['runs'])==1
expected=dict(actions=834,pc_apply=264,factor_readers=7,joint_lu_solve=526,outer_lu_solve=1584,explicit_triangular_pass=4220,port_factors=2,port_solves=822,port_rhs_columns=822,original_audits=1,arnoldi=256,cycles=1)
assert result['budget_counts']==idx['budget_counts']==book['charged']==expected
assert result['source_sha']==idx['source']=='af0d3d3e7d2b05ab915902bbb66b6ddbd7ed912e'
assert result['pc_apply_calls']-result['pc_zero_calls']==262
assert expected['joint_lu_solve']==2+2*262 and expected['outer_lu_solve']==12+6*262
assert expected['explicit_triangular_pass']==2*(526+1584)
assert sum(result['action_counts'][k] for k in ('S','SH'))+sum(result['fast_action_counts'][k] for k in ('S','SH'))==834
assert result['all_batch_equivalent_actions']==45
assert len(result['cycles'])==1 and result['cycles'][0]['inner']['inner_iterations']==256
A=result['cycles'][0]['audit'];assert A['schur_relative']>1e-2 and A['native_relative']>1e-6
assert result['status']=='ONLINE_BLOCK_PC_PROGRESS_INSUFFICIENT'
assert not any(result[k] for k in ('reference_arrays_read','hidden_training','warm_arrays_read','cached_direction_arrays_read','old5_7_LU_read','new_local_assemblies','new_local_factors'))
for row in result['old_new_S_SH_pairs']:
 assert row['full_b_relative']<=1e-11 and row['operation_relative']<=1e-10
for factor in result['factor_reloads']:
 assert not factor['refactored'] and factor['qualified']
 for w in factor['witnesses']:
  assert w['solve_relative']<=1e-8 and w['solve_operation_relative']<=1e-12
  assert w['original_principal_action']['operation_relative']<=1e-10 and w['original_adjoint_action']['operation_relative']<=1e-10
supers=[]
for x in cost['aux_runs']+[{'path':idx['run']['path']}]:
 p=Path(x['path']);s=json.loads(p.read_text());sp=p.parent/'supervision/resources.jsonl';samples=[json.loads(b) for b in raws[str(sp)].splitlines()]
 assert len(samples)==s['samples']
 for r in samples:
  assert r['rss_bytes']==sum(v['rss_bytes'] for v in r['members'])
  assert r['swap_bytes']==sum(v['swap_bytes'] for v in r['members'])
 assert max(v['rss_bytes'] for v in samples)==s['sampled_process_tree_rss_peak_bytes']
 assert max(v['swap_bytes'] for v in samples)==0 and s['descendants_cleared']
 supers.append(dict(path=str(p),seconds=s['elapsed_seconds'],peak=s['sampled_process_tree_rss_peak_bytes'],samples=len(samples),status=s['classification']))
aux=sum(x['seconds'] for x in supers[:-1]);actor=supers[-1]['seconds'];probe=sum(x['elapsed_seconds'] for x in cost['probes']);total=aux+actor+probe
assert math.isclose(total,cost['new_supervised_probe_seconds'],rel_tol=1e-14)
assert math.isclose(aux,cost['auxiliary_supervised_seconds'],rel_tol=1e-14)
tests=[]
for x in read('tests_v35.json')['raw_JUnit']:
 p=Path(x['path']);cases=ET.fromstring(p.read_bytes()).findall('.//testcase');fail=[c.attrib['name'] for c in cases if c.find('failure') is not None or c.find('error') is not None]
 assert len(cases)==x['cases'] and len(fail)==x['failed']
 tests.append(dict(path=str(p),total=len(cases),failed=fail))
admissions=[]
for x in cost['probes']:
 p=Path(x['receipt_path']);d=json.loads(raws.get(str(p),p.read_bytes() if p.exists() else b'{}'))
 fractions={int(k):v for k,v in d['cpu_busy_fractions'].items()};reasons={}
 for key,b in d['cpu_ticks_before'].items():
  a=d['cpu_ticks_after'][key];assert abs(1-(a[3]-b[3]+a[4]-b[4])/max(sum(a)-sum(b),1)-fractions[int(key)])<1e-15
 for tid,a in d['thread_ticks_after'].items():
  b=d['thread_ticks_before'].get(tid)
  if b and a[0]==b[0]:assert d['thread_delta_ticks'][tid]==a[1]-b[1]
 for cpu,v in fractions.items():
  if v>.05:reasons.setdefault(cpu,[]).append('sample_busy_fraction_gt_0.05')
 for proc in d['neighbor_processes']:
  for t in proc['threads']:
   if len(t['affinity'])<=16:
    for cpu in t['affinity']:reasons.setdefault(cpu,[]).append('narrow_thread_affinity:'+str(t['tid']))
   elif d['thread_delta_ticks'].get(str(t['tid']),1)>0:reasons.setdefault(t['cpu'],[]).append('active_wide_thread:'+str(t['tid']))
 decisions=[dict(**t,eligible=not any(c in reasons for c in t['siblings']),excluded_siblings={str(c):reasons[c] for c in t['siblings'] if c in reasons}) for t in d['topology']]
 assert decisions==d['cpu_decisions'];assert [t['cpu'] for t in decisions if t['eligible']]==d['candidate_cpus'];assert d['selected_cpu'] in d['candidate_cpus']
 admissions.append(dict(path=str(p),cpu=d['selected_cpu'],replayed=True))
output=dict(reviewed_head=HEAD,previous_review=BASE,scope='stdlib metadata/source/hash/history/resource audit; no new numerical actions, LU loads or PDE',verified_metadata=verified,raw_gzip_count=len(rawidx['raw']),archived_originals_checked_against_published_raw_hash=archived,protected_count=len(protected),history_count=len(history),history_files=history,compiled=compiled,charged=expected,audit=A,supervisions=supers,admissions=admissions,JUnit=tests,costs=dict(actor=actor,auxiliary=aux,probes=probe,total=total),full_repository_index=dict(path=str(O/'repository_index.json'),sha256=sha((O/'repository_index.json').read_bytes())),skipped_numeric_payloads=sorted(set(skipped)))
(O/'independent_checks.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in output.items() if k in ['scope','raw_gzip_count','protected_count','history_count','compiled','costs']},indent=2))
print('verified_metadata',len(verified),'supervisions',len(supers),'admissions',len(admissions),'JUnit',[(t['total'],len(t['failed'])) for t in tests])
