import ast,gzip,hashlib,json,math,struct,subprocess,zipfile,xml.etree.ElementTree as ET
from pathlib import Path
ROOT=Path.cwd();D=ROOT/'docs/task042_neural_coarse_inverse';R=D/'outcomes/records';O=ROOT/'tmp/task042/review_v43';HEAD='09a165a157cdb8291b290a43923c4429c5ca9ee0';BASE='2e5bfc593716d82ccbca4cc2061b50fe491186cd'
def git(*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a])
def sha(b):return hashlib.sha256(b).hexdigest()
def read(n):return json.loads((R/n).read_text())
def key(p):return str((ROOT/p).resolve())
assert git('rev-parse','HEAD').decode().strip()==HEAD
raw={};versions={};rawidx=read('raw_evidence_index_v45.json')
for x in rawidx['files']:
 b=(ROOT/x['archive']).read_bytes();assert sha(b)==x['archive_sha256'];v=gzip.decompress(b);assert sha(v)==x['sha256'] and len(v)==x['bytes'];p=key(x['original']);raw[p]=v;versions.setdefault(p,[]).append(v)
originals=0;changed=[]
for p,vs in versions.items():
 if Path(p).exists():
  if Path(p).read_bytes() in vs:originals+=1
  else:changed.append(p)
protected=[];history=[];append={'README.md','outcomes/summary.md','outcomes/test_summary.md','outcomes/changed_files.md'}
for item in git('ls-tree','-r',BASE,str(D.relative_to(ROOT))).decode().splitlines():
 meta,p=item.split('\t');oid=meta.split()[2];now=(ROOT/p).read_bytes();rel=str(Path(p).relative_to(D.relative_to(ROOT)))
 if rel in append:
  old=git('show',BASE+':'+p);assert now.endswith(old),p
 else:
  assert hashlib.sha1(b'blob '+str(len(now)).encode()+b'\0'+now).hexdigest()==oid,p;protected.append(p)
 if Path(p).name.startswith(('review_report_v','response_v')):history.append(p)
compiled=[]
for p in git('diff','--name-only',BASE,HEAD).decode().splitlines():
 if p.endswith('.py'):compile((ROOT/p).read_text(),p,'exec');compiled.append(p)
run=read('run_index_v45.json');cost=read('resource_costs_v45.json');supervisions=[];formal_sources=[];stages=[]
for row in cost['runs']:
 folder=ROOT/row['folder'];manifest=json.loads(raw[key(folder/'run_manifest.json')]);role=manifest['stage'].removeprefix('V45-')
 if role in ('SETUP','DATA','GRADIENT','CHECK','DIAGNOSTIC') or role.startswith(('TRAIN_','EVAL_')):
  for fp,h in manifest['implementation_hashes'].items():assert sha(git('show',manifest['source_sha']+':'+fp))==h,(role,fp)
  formal_sources.append(dict(role=role,source_sha=manifest['source_sha'],hashes=len(manifest['implementation_hashes']),manifest=str(folder/'run_manifest.json')))
 p=folder/'supervision/summary.json';s=json.loads(raw[key(p)]);samples=[json.loads(b) for b in raw[key(folder/'supervision/resources.jsonl')].splitlines()]
 assert s.get('samples') is None or len(samples)==s['samples']
 for v in samples:
  assert v['rss_bytes']==sum(m['rss_bytes'] for m in v['members']);assert v['swap_bytes']==sum(m['swap_bytes'] for m in v['members'])
 assert max(v['rss_bytes'] for v in samples)==s['sampled_process_tree_rss_peak_bytes']
 assert max(v['swap_bytes'] for v in samples)==0 and s['descendants_cleared'];assert s['elapsed_seconds']==row['seconds_budget_charge_upper'];assert s.get('elapsed_seconds_lower',s['elapsed_seconds'])==row['seconds_measured_lower']
 supervisions.append(dict(role=row['role'],path=str(p),seconds=s['elapsed_seconds'],lower=row['seconds_measured_lower'],exit=s.get('leader_exit_code',s.get('exit_code')),peak=s['sampled_process_tree_rss_peak_bytes'],samples=len(samples),status=s['classification']))
for row in run['runs']:
 for field in ('manifest','summary','result'):
  x=row.get(field)
  if x:
   b=(ROOT/x['path']).read_bytes();assert sha(b)==x['sha256'];assert len(b)==x['bytes']
   if field=='result':stages.append(json.loads(b))
probes=[json.loads(p.read_text()) for p in (ROOT/'tmp/task042/v45').glob('probe_*.json')];sumruns=sum(s['seconds'] for s in supervisions);lower=sum(s['lower'] for s in supervisions);sumprobes=sum(p['elapsed_seconds'] for p in probes)
settlement=cost['final_low_load_settlement_measured_seconds_lower']+cost['final_archive_housekeeping_measured_seconds_lower']+cost['post_close_metadata_refinement_measured_seconds_lower'];total=lower+sumprobes+settlement;upper=sumruns+sumprobes+settlement
assert math.isclose(sumruns,cost['actual_batch_supervised_budget_charge_upper_seconds'],rel_tol=1e-14);assert math.isclose(lower,cost['actual_batch_supervised_seconds_lower'],rel_tol=1e-14);assert math.isclose(sumprobes,cost['probe_seconds'],rel_tol=1e-14);assert math.isclose(total,cost['loaded_measured_lower_seconds'],rel_tol=1e-14);assert math.isclose(upper,cost['loaded_budget_charge_upper_seconds'],rel_tol=1e-14)
peak=max(s['peak'] for s in supervisions)
book=json.loads((ROOT/'tmp/task042/v45/ledger.json').read_text());assert book['closed'] and book['active'] is None and len(book['runs'])==len(supervisions)
admissions=[]
for p in probes:
 d=json.loads(raw[key(p['receipt_path'])]);fr={int(k):v for k,v in d['cpu_busy_fractions'].items()};reasons={}
 for name,b in d['cpu_ticks_before'].items():
  a=d['cpu_ticks_after'][name];assert abs(1-(a[3]-b[3]+a[4]-b[4])/max(sum(a)-sum(b),1)-fr[int(name)])<1e-15
 for tid,a in d['thread_ticks_after'].items():
  b=d['thread_ticks_before'].get(tid)
  if b and a[0]==b[0]:assert d['thread_delta_ticks'][tid]==a[1]-b[1]
 for cpu,v in fr.items():
  if v>.05:reasons.setdefault(cpu,[]).append('sample_busy_fraction_gt_0.05')
 for proc in d['neighbor_processes']:
  for t in proc['threads']:
   if len(t['affinity'])<=16:
    for cpu in t['affinity']:reasons.setdefault(cpu,[]).append('narrow_thread_affinity:'+str(t['tid']))
   elif d['thread_delta_ticks'].get(str(t['tid']),1)>0:reasons.setdefault(t['cpu'],[]).append('active_wide_thread:'+str(t['tid']))
 decisions=[dict(**t,eligible=not any(c in reasons for c in t['siblings']),excluded_siblings={str(c):reasons[c] for c in t['siblings'] if c in reasons}) for t in d['topology']]
 assert decisions==d['cpu_decisions'];assert [t['cpu'] for t in decisions if t['eligible']]==d['candidate_cpus'];assert d['selected_cpu'] in d['candidate_cpus'];admissions.append(dict(path=p['receipt_path'],cpu=d['selected_cpu']))
# Only frozen array byte/hash/header inspection, no FE or NumPy/BLAS execution.
receipts={}
def walk(v):
 if isinstance(v,dict):
  if all(k in v for k in ('path','sha256','members')) and str(v['path']).endswith('.npz'):receipts[v['path']]=v
  for w in v.values():walk(w)
 elif isinstance(v,list):
  for w in v:walk(w)
walk(read('array_inventory_v45.json'));array_checks=[]
for path,receipt in receipts.items():
 p=Path(path);assert sha(p.read_bytes())==receipt['sha256'];aliases=receipt.get('aliases',{})
 with zipfile.ZipFile(p) as z:
  assert set(z.namelist())=={k+'.npy' for k in receipt['members'] if k not in aliases}
  for name,m in receipt['members'].items():
   actual=aliases.get(name,name);assert actual not in aliases;b=z.read(actual+'.npy');assert b[:6]==b'\x93NUMPY';length=2 if b[6]==1 else 4;off=8+length;size=int.from_bytes(b[8:off],'little');meta=ast.literal_eval(b[off:off+size].decode().strip());assert list(meta['shape'])==m['shape'] and meta['descr']==m['dtype'];payload=b[off+size:]
   if meta['fortran_order']:
    assert len(meta['shape'])==2,(path,name,meta)
    nr,nc=meta['shape'];width=int(meta['descr'][2:]);view=memoryview(payload)
    payload=b''.join(view[(j*nr+i)*width:(j*nr+i+1)*width] for i in range(nr) for j in range(nc))
   assert sha(payload)==m['sha256'],(path,name)
 array_checks.append(dict(path=path,members=len(receipt['members']),stored_members=len(receipt['members'])-len(aliases),bytes=p.stat().st_size))
from statistics import median
import itertools
# No numerical solver/library imports. Norms below are saved-vector reductions.
def npy(path,name):
 with zipfile.ZipFile(path) as z:b=z.read(name+'.npy')
 k=2 if b[6]==1 else 4;off=8+k;ln=int.from_bytes(b[8:off],'little');h=ast.literal_eval(b[off:off+ln].decode());data=b[off+ln:]
 if h['fortran_order']:
  assert len(h['shape'])==2
  nr,nc=h['shape'];width=int(h['descr'][2:]);v=memoryview(data);data=b''.join(v[(j*nr+i)*width:(j*nr+i+1)*width] for i in range(nr) for j in range(nc))
 typ=h['descr'];fmt={'<c16':'<dd','<f8':'<d','<i8':'<q','<i4':'<i'}[typ]
 return h,[complex(*v) if typ=='<c16' else v[0] for v in struct.iter_unpack(fmt,data)]
def norm(v):return math.sqrt(math.fsum(abs(a)**2 for a in v))
def near(a,b):return math.isclose(a,b,rel_tol=5e-12,abs_tol=1e-27)
weights=[]
for item in read('array_inventory_v45.json')['model_files']:
 r=item['receipt'];assert sha(Path(r['path']).read_bytes())==r['sha256'];weights.append(r)
training=[]
for name in ('linear_hierarchy','neural_local','neural_hierarchy'):
 t=read('neural_training_'+name+'_v45.json');b=Path(t['history_path']).read_bytes();assert sha(b)==t['history_sha256'];h=[json.loads(v) for v in b.splitlines()];prior=[]
 if t.get('prior_complete_updates',0):
  resume=json.loads((ROOT/'tmp/task042/v45/train_NE_resume.json').read_text());r=resume['prior_history'];assert sha(Path(r['path']).read_bytes())==r['sha256'];prior=[json.loads(v) for v in Path(r['path']).read_bytes().splitlines()];assert len(prior)==7 and h[0]['parameter_before_hash']==resume['last_parameter_hash']==prior[-1]['parameter_after_hash'];assert sha(Path(resume['checkpoint']['path']).read_bytes())==resume['checkpoint']['sha256']
 h=prior+h;assert len(h)==128 and [v['update'] for v in h]==list(range(1,129));assert t.get('prior_complete_updates',0)+t.get('new_complete_updates',128)==128
 for i,v in enumerate(h):
  assert v['parameter_before_hash']!=v['parameter_after_hash']
  if i:assert v['parameter_before_hash']==h[i-1]['parameter_after_hash']
  assert v['batch_samples']==[(2*i)%16,(2*i+1)%16]
  assert math.isfinite(v['loss_before_update']) and math.isfinite(v['gradient_norm'])
 for c in t['all_checkpoints']:
  assert near(median(c['qr']),c['median_qr']) and near(median(c['qe']),c['median_qe']) and near(max(c['qe']),c['max_qe']);assert sha(Path(c['receipt']['path']).read_bytes())==c['receipt']['sha256']
 order=(lambda c:(c['median_qr'],c['update'])) if t['route']=='NN-R' else (lambda c:(c['median_qe'],c['max_qe'],c['median_qr'],c['update']))
 assert t['selected']==min(t['all_checkpoints'],key=order)
 assert all(v>0 for v in t['parameter_group_changes_last'].values()) and t['heldout_reads']==0
 training.append(dict(route=t['route'],updates=len(h),prior=len(prior),new=t.get('new_complete_updates',128),selected=t['selected'],changes=t['parameter_group_changes_last'],source=t['source_sha'],initial_parameter_hash=t['initial_parameter_hash']))
assert training[0]['initial_parameter_hash']==training[1]['initial_parameter_hash']==training[2]['initial_parameter_hash']
# Recompute full eta/rho from immutable saved vectors, without replaying any A/AH.
ptr=json.loads((ROOT/'benchmarks/artifacts/task042/v45/DATA.json').read_text());ds=json.loads(Path(ptr['path']).read_text())
gp=json.loads((ROOT/'benchmarks/artifacts/task042/v43/SETUP.json').read_text());setup=json.loads(Path(gp['path']).read_text())
_,ind=npy(setup['graph']['path'],'independent');_,slaves=npy(setup['graph']['path'],'slaves')
assert sorted(ind+slaves)==list(range(45000))
he,errors=npy(ds['sealed']['heldout']['path'],'error');hr,rhss=npy(ds['prefix']['heldout']['path'],'rhs')
assert he['shape']==hr['shape']==(8,45000)
checker=read('neural_heldout_checker_v45.json');comp=read('neural_candidate_comparison_v45.json');saved_checks=[];routes={}
for row in comp['rows']:
 sample,route=row['sample'],row['route'];path=row['state']['path'];a={n:npy(path,n)[1] for n in ('z','rhs','residual','initial','prefix','delta','prefix_residual','initial_residual')}
 e=errors[sample*45000:(sample+1)*45000];r=rhss[sample*45000:(sample+1)*45000];assert a['rhs']==r
 rho=norm(a['residual'])/norm(r);eta=norm(a['z'][i]-e[i] for i in ind)/norm(e[i] for i in ind);slave=norm(a['z'][i] for i in slaves)
 c=next(c for c in checker['rows'] if c['sample']==sample and c['route']==route)
 assert near(c['rho'],rho) and near(c['eta'],eta) and slave==0 and c['passed']==(rho<=1e-6 and eta<=1e-4 and slave==0)
 assert a['initial']==[x+y for x,y in zip(a['prefix'],a['delta'],strict=True)]
 for stage,field in [('prefix','prefix'),('corrected','initial'),('final','z')]:assert near(c['stages'][stage]['eta'],norm(a[field][i]-e[i] for i in ind)/norm(e[i] for i in ind))
 qe=norm(a['initial'][i]-e[i] for i in ind)/norm(a['prefix'][i]-e[i] for i in ind)
 val=dict(sample=sample,route=route,rho=rho,eta=eta,correction_qe=qe,eta_over_rho=eta/rho,steps=row['total_Arnoldi'],whole_seconds=row['independent_online_seconds'],passed=c['passed'])
 assert row['total_Arnoldi']==128 and 0 <= row['independent_online_seconds']-row['actual_online_increment_seconds']-row['common_prefix_seconds'] < 1e-4
 saved_checks.append(val);routes.setdefault(route,[]).append(val)
for route,rows in routes.items():
 rc=cost['route_costs'][route];assert near(sum(v['whole_seconds'] for v in rows)/8,rc['per_rhs_observed_online_mean']);assert sum(v['passed'] for v in rows)==0
assert {(c['sample'],c['route']) for c in saved_checks}=={(i,r) for i in range(8) for r in ('R0','CL44','LIN-H','NN-L','NN-H')}
grad=read('neural_gradient_v45.json');fd=[]
for row in grad['FD']:
 _,a=npy(row['arrays']['path'],'finite_difference');_,b=npy(row['arrays']['path'],'jvp');num=norm(x-y for x,y in zip(a,b,strict=True));den=norm(b)
 assert near(row['numerator'],num) and near(row['denominator'],den) and row['passed']==(num<=1e-5*den)
 fd.append(dict(direction=row['direction'],step=row['step'],relative=num/den,passed=row['passed']))
xml=[]
for p,b in raw.items():
 if p.endswith('pytest.xml'):
  t=ET.fromstring(b);suite=list(t)[0] if t.tag=='testsuites' else t;xml.append(dict(path=p,tests=int(suite.get('tests')),failures=int(suite.get('failures')),errors=int(suite.get('errors'))))
source=read('tests_v45.json')['implementation_hashes']
for p,h in source.items():assert sha((ROOT/p).read_bytes())==h,p
counts={k:sum(row['numerical_counts']['upper'][k] for row in cost['runs']) for k in ('actions','B_actions')};assert counts=={'actions':6519,'B_actions':0}
callrows=[]
for row in cost['runs']:
 p=key(ROOT/row['folder']/'action_calls.jsonl')
 if p in raw:
  lines=[json.loads(l) for l in raw[p].splitlines()];by={}
  for v in lines:by[v['kind']]=by.get(v['kind'],0)+v['RHS']
  assert sum(by.values())==sum(row['numerical_counts']['completed'].values());callrows.append(dict(role=row['role'],breakdown=by))
sampling=[]
for row in cost['runs']:
 v=[json.loads(b) for b in raw[key(ROOT/row['folder']/'supervision/resources.jsonl')].splitlines()];delta=[b['elapsed_seconds']-a['elapsed_seconds'] for a,b in zip(v,v[1:])];sampling.append(dict(folder=row['folder'],median=median(delta) if delta else None,max=max(delta,default=None)))
zero_controls=[]
for route in ('NN-L','NN-H'):
 for sample in range(8):
  rr=next(r for r in comp['rows'] if r['sample']==sample and r['route']==route);r0=next(r for r in comp['rows'] if r['sample']==sample and r['route']=='R0')
  for field in ('z','residual','initial','initial_residual','delta'):
   assert npy(rr['state']['path'],field)[1]==npy(r0['state']['path'],field)[1],(route,sample,field)
  assert norm(npy(rr['state']['path'],'delta')[1])==0
  zero_controls.append(dict(route=route,sample=sample,all_saved_outputs_equal_R0=True))
setup45=read('neural_bridge_v45.json');layout=setup45['bucket_inventory']['path'];hk,flat=npy(layout,'keys');keys=[flat[i:i+5] for i in range(0,len(flat),5)];group=[6 if k[0]==3 else (k[0]-1)*3+k[1] for k in keys]
_,storedgroups=npy(layout,'entity_group');assert group==storedgroups
bucketchecks=[]
for level in range(len(setup45['levels'])):
 hk,kflat=npy(layout,f'level{level}_keys');bk=[tuple(kflat[i:i+3]) for i in range(0,len(kflat),3)];hi,ids=npy(layout,f'level{level}_ids');hc,bucket_counts_flat=npy(layout,f'level{level}_counts');bucket_counts=[[0]*7 for k in bk]
 for node,k in enumerate(keys):assert tuple(c//(2**(level+1)) for c in k[2:])==bk[ids[node]];bucket_counts[ids[node]][group[node]]+=1
 assert [v for row in bucket_counts for v in row]==bucket_counts_flat
 bucketchecks.append(dict(level=level,buckets=len(bk),entities=sum(bucket_counts_flat),real_moments=sum(bucket_counts[i][g]*2*(6 if g<3 else 60 if g<6 else 450) for i in range(len(bucket_counts)) for g in range(7))))
mechanisms=[]
for r in setup45['checks']:
 if r['kind'] in ('mean','broadcast'):
  passed=abs(r['left']-r['right'])<=1e-10*r['operation_denominator'];assert r['passed']==passed and passed;mechanisms.append(r)
 elif r['kind']=='fixed_gamma_distant_content':assert r['passed'] and ((r['response_norm']==0) if r['code']=='NL' else r['response_norm']>1e-12)
diag=[]
x=dict(reviewed_head=HEAD,previous_review=BASE,scope='stdlib immutable bytes/source/resource audit plus saved-vector norm/FD recomputation; no A/AH, FE, recovery, solve, factor, training, SVD replay or Torch deserialization',raw_archives_verified=len(rawidx['files']),current_originals_matching_archived_version=originals,unmatched_current_originals=changed,unmatched_original_snapshots=[dict(path=p,bytes=len(Path(p).read_bytes()),sha256=sha(Path(p).read_bytes()),text=Path(p).read_text() if Path(p).stat().st_size<4096 else None) for p in changed],protected_files=len(protected),history_files=history,compiled=compiled,formal_source_checks=formal_sources,final_source_hashes=source,supervisions=supervisions,CPU_admissions=admissions,costs=dict(supervised_lower=lower,supervised_upper=sumruns,probes=sumprobes,settlement=settlement,total_lower=total,total_upper=upper,peak_sampled_tree_bytes=peak,ownswap=0,historical_plus_current_lower=cost['historical_plus_current_lower_seconds'],unmonitored='unknown'),array_byte_verification=array_checks,array_totals=dict(files=len(array_checks),logical=sum(v['members'] for v in array_checks),actual=sum(v['stored_members'] for v in array_checks)),model_files_verified=len(weights),training_records=training,heldout_saved_vector_checks=saved_checks,gradient_saved_vector_checks=fd,decoder_saved_scalar_checks=diag,zero_selected_head_checks=zero_controls,bucket_inventory_checks=bucketchecks,mechanism_scalar_checks=mechanisms,action_counts_upper=counts,action_journals=callrows,pytest_snapshots=xml,sampling=sampling,repository_index_sha256=sha((O/'repository_index.json').read_bytes()),dot_head='7f03a48d2962dd3ea967a07368b36acb4aae7f57',source_changes=False,limitations=['not whole-repository line-by-line semantic audit','rho recomputation uses saved residual; no independent matrix action replay in review','training e-read absence is source/record contract, not an OS file-access sandbox proof','Adam step/state content checked by producer restore and saved tests; reviewer did not deserialize checkpoint','V45 full correctness 0/8 all routes; original-size and NN20 not qualified','dot read-only published document, not independently requalified raw evidence','ordinary review IO/human cost unmonitored'])
(O/'independent_checks.json').write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(raw=len(rawidx['files']),originals=originals,changed=changed,protected=len(protected),history=len(history),compiled=len(compiled),formal_sources=len(formal_sources),costs=x['costs'],arrays=x['array_totals'],weights=len(weights),vector_checks=len(saved_checks),FD=len(fd),counts=counts,tests=xml),indent=2))
