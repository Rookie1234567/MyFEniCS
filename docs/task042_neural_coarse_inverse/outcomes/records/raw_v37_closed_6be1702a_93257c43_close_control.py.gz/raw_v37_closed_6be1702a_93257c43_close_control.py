"""Low-load final control: verify no owned actor, close the unchanged window."""
import gzip
import hashlib
import json
import os
import subprocess
import time
from pathlib import Path

from src.runners.task042_shared import write_json
from src.runners.port_preparation import storage
from src.solvers.boundary_witness_scope import ROOT,window

R=ROOT/'docs/task042_neural_coarse_inverse/outcomes/records';T=window.TMP
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

book=window.ledger()
if book['active'] is not None or book['closed']:raise ValueError('closing needs settled open V37')
owned=[];neighbors=[]
for d in Path('/proc').iterdir():
    if not d.name.isdigit() or int(d.name)==os.getpid():continue
    try:
        cwd=(d/'cwd').resolve();args=(d/'cmdline').read_bytes().decode(errors='replace').split('\0');name=Path(args[0]).name
        actor=bool(args) and (name.startswith(('python','mpiexec','mpirun')) and any(v=='scripts/run_case.py' or v.startswith(('src.runners.','benchmarks.subreaper_watchdog')) for v in args))
        compiler=name in ('gcc','g++','cc1','cc1plus','collect2','ld')
        if cwd.is_relative_to(ROOT) and (actor or compiler):owned.append({'pid':int(d.name),'cwd':str(cwd),'executable':name,'stage_args':[v for v in args if v.endswith(('.dat','.py')) or v.startswith('src.runners.')]})
        elif str(cwd)=='/home/fenics/Projects/NN-Lab-V2' and actor:neighbors.append({'pid':int(d.name),'cwd':str(cwd),'readonly':True})
    except (OSError,ValueError,IndexError):pass
if owned:raise ValueError('own actor still active '+repr(owned))
if not all(v['descendants_cleared'] and v['swap_bytes']==0 for v in book['runs']):raise ValueError('unsettled descendants/swap evidence')
clock=window.snapshot();inventory=storage(namespace='v37');paid=window.charged_wall()
if paid>3600-120 or window.probe_wall()>60:raise ValueError('V37 total/probe quota')
component=sum(v['elapsed_seconds'] for v in book['runs'] if v['role'] in ('PATCH','CAPACITY'))
if component>2400:raise ValueError('component cap')
book['closed']=True;book['closure']={'clock':clock,'reason':'completed independent partial component and 5.4 analysis after genuine native q60 new-storage stop; no affected enlargement restart','charged_wall_seconds':paid,'actor_wall_field_semantics':'generic actor_wall_seconds unused; authoritative charges are runs elapsed + probes + bootstrap','no_owned_actors':True}
write_json(window.LEDGER_PATH,book);window.journal('scope_closed',charged_seconds=paid,own_actors=owned,storage=inventory)
state={'source_before_documentation':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'clock':clock,'closed':True,'active':None,'own_actors':owned,'neighbors_readonly':neighbors,'charged_wall_seconds':paid,'component_wall_seconds':component,'own_swap_peak_bytes':0,'no_global_p4_factor':True,'new_volume_solve':False,'merge':False,'closed_old_ledgers_reopened':False,'stopped_q60_enlargement_restarted':False,'final_git_head':'reported after exact branch commit/push; documentation HEAD never used as run source'}
write_json(R/'final_state_v37.json',state)
c=json.loads((R/'resource_costs_v37.json').read_text());c.update({'supervised_wall_seconds_final':sum(v['elapsed_seconds'] for v in book['runs']),'probe_seconds_final':window.probe_wall(),'charged_final':paid,'storage_final':inventory,'window_final':clock,'ledger_closed':True,'generic_actor_wall_seconds_0_is_not_free':True,'non_supervised_authoring_and_final_metadata_control':'UNKNOWN, included in total calendar; not claimed as complete N1 expense','historical_known_lower_plus_new_supervised_probes':77349.71922726494+sum(v['elapsed_seconds'] for v in book['runs'])+window.probe_wall()})
rows=[]
for v in book['runs']:
    d=Path(v['folder']);summary=d/('summary.json' if d.name.startswith('aux_') else 'run_summary.json');base=json.loads((d/'resource_baseline.json').read_text())
    rows.append({**{k:v[k] for k in ['role','source_sha','elapsed_seconds','classification','exit_code','peak_bytes','swap_bytes','descendants_cleared']},'directory':str(d),'summary_sha256':sha(summary),'cpu':base['cpu']})
c['rows']=rows;write_json(R/'resource_costs_v37.json',c)
idx=json.loads((R/'run_index_v37.json').read_text());idx['runs']=rows;idx.pop('pending_final_metadata_run',None);idx['closed_state']='docs/task042_neural_coarse_inverse/outcomes/records/final_state_v37.json';write_json(R/'run_index_v37.json',idx)
raw=json.loads((R/'raw_evidence_index_v37.json').read_text());keys={(v['original_path'],v['sha256']) for v in raw['files']}
extra=[T/'window.json',T/'start_identity.json',T/'ledger.json',T/'progress_journal.jsonl',T/'close_control.py']
extra.extend(T.glob('probe_*.json'))
extra.extend(p for p in (T/'aux_final_01').rglob('*') if p.is_file() and p.suffix in ('.json','.jsonl','.log','.stdout','.stderr','.txt'))
for p in extra:
    h=sha(p)
    if (str(p),h) in keys:continue
    data=p.read_bytes();out=R/('raw_v37_closed_'+hashlib.sha256(str(p).encode()).hexdigest()[:8]+'_'+h[:8]+'_'+p.name+'.gz');out.write_bytes(gzip.compress(data,compresslevel=1,mtime=0))
    if gzip.decompress(out.read_bytes())!=data:raise ValueError('closed metadata readback')
    raw['files'].append({'original_path':str(p),'gzip':str(out.relative_to(ROOT)),'bytes':len(data),'sha256':h,'gzip_sha256':sha(out)})
write_json(R/'raw_evidence_index_v37.json',raw)
write_json(R/'storage_v37.json',{'final':inventory,'limit_new_bytes':512*2**20,'task_artifact_limit_bytes':20*2**30,'minimum_free_bytes':50*2**30,'status':'FINAL_WITHIN_LIMIT_PRIOR_BREACH_RETAINED','prior_breach_evidence':'jit_storage_gate_v37.json','old_arrays_and_results_deleted':False})
print(json.dumps({'closed':True,'clock_utc':clock['observed_utc'],'paid_seconds':paid,'supervised_wall':c['supervised_wall_seconds_final'],'probe_seconds':c['probe_seconds_final'],'component_seconds':component,'peak_bytes':c['sampled_tree_peak_bytes'],'storage':inventory,'own_actors':owned,'raw_versions':len(raw['files'])}),flush=True)
