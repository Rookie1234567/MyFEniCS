"""Keep both metadata-check source versions; validate the original hash."""
import gzip
import hashlib
import json
from pathlib import Path

ROOT=Path('/home/fenics/Projects/NN-Lab');T=ROOT/'tmp/task042/v37';R=ROOT/'docs/task042_neural_coarse_inverse/outcomes/records'
raw=json.loads((R/'raw_evidence_index_v37.json').read_text());path=T/'post_check.py';text=path.read_text()
old=text.replace('    # The long historical dispatcher already has style findings. Check all\n    # new/revised modules and independently compare its exact baseline spans,\n    # rather than silently cleaning unrelated historical orchestration.\n    py=[p for p in final_tests[\'implementation_hashes\'] if p.endswith(\'.py\') and p!=\'scripts/run_case.py\']\n',"    py=[p for p in final_tests['implementation_hashes'] if p.endswith('.py')]\n")
a=old.index("    dispatch='scripts/run_case.py'\n");b=old.index("    dump('tests_v37.json'",a);old=old[:a]+old[b:]
old=old.replace(",\'historical_dispatcher_findings_unchanged\':len(old_sig)",'')
versions={hashlib.sha256(text.encode()).hexdigest():text.encode(),hashlib.sha256(old.encode()).hexdigest():old.encode()}
events=[];dedup={}
for row in raw['files']:
    file=ROOT/row['gzip']
    data=gzip.decompress(file.read_bytes())
    if hashlib.sha256(data).hexdigest()!=row['sha256']:
        if row['original_path']!=str(path) or row['sha256'] not in versions:raise ValueError('unexpected metadata archival conflict '+str(file))
        data=versions[row['sha256']]
        if len(data)!=row['bytes']:raise ValueError('original authored source length')
        events.append({'old_gzip':row['gzip'],'sha256':row['sha256'],'reason':'exact initial authored metadata checker reconstructed and verified against existing original hash/length; no scientific source changed'})
    if row['original_path']==str(path):
        file=R/('raw_v37_post_check_'+row['sha256'][:12]+'.py.gz');file.write_bytes(gzip.compress(data,compresslevel=1,mtime=0));row['gzip']=str(file.relative_to(ROOT));row['gzip_sha256']=hashlib.sha256(file.read_bytes()).hexdigest()
    if len(data)!=row['bytes'] or hashlib.sha256(data).hexdigest()!=row['sha256']:raise ValueError('raw inventory check')
    dedup[(row['original_path'],row['sha256'])]=row
raw['files']=list(dedup.values());raw['metadata_archive_version_repair']=events
(R/'raw_evidence_index_v37.json').write_text(json.dumps(raw,ensure_ascii=False,indent=2)+'\n')
print('verified archives',len(raw['files']),'metadata versions retained',len(versions),'repaired',len(events),flush=True)
