import ast,gzip,hashlib,json,math,struct,subprocess,zipfile,xml.etree.ElementTree as ET
from pathlib import Path
ROOT=Path.cwd();D=ROOT/'docs/task042_neural_coarse_inverse';R=D/'outcomes/records';O=ROOT/'tmp/task042/review_v40';HEAD='d8a464f1f05e15739448bb70ac452e81ee292dad';BASE='31774b6282f61280fe33c162f9f48bf4ea526ce6'
def git(*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a])
def sha(b):return hashlib.sha256(b).hexdigest()
def read(n):return json.loads((R/n).read_text())
def key(p):return str((ROOT/p).resolve())
assert git('rev-parse','HEAD').decode().strip()==HEAD
raw={};versions={};rawidx=read('raw_evidence_index_v42.json')
for x in rawidx['files']:
 b=(ROOT/x['archive']).read_bytes();assert sha(b)==x['archive_sha256'];v=gzip.decompress(b);assert sha(v)==x['sha256'] and len(v)==x['bytes'];p=key(x['original']);raw[p]=v;versions.setdefault(p,[]).append(v)
originals=0;changed=[]
for p,vs in versions.items():
 if Path(p).exists():
  if Path(p).read_bytes() in vs:originals+=1
  else:changed.append(p)
protected=[];history=[];append={'README.md','outcomes/summary.md','outcomes/test_summary.md','outcomes/changed_files.md'}
for p in git('ls-tree','-r','--name-only',BASE,str(D.relative_to(ROOT))).decode().splitlines():
 old=git('show',BASE+':'+p);now=(ROOT/p).read_bytes();rel=str(Path(p).relative_to(D.relative_to(ROOT)))
 if rel in append:assert now.endswith(old),p
 else:assert now==old,p;protected.append(p)
 if Path(p).name.startswith(('review_report_v','response_v')):history.append(p)
compiled=[]
for p in git('diff','--name-only',BASE,HEAD).decode().splitlines():
 if p.endswith('.py'):compile((ROOT/p).read_text(),p,'exec');compiled.append(p)
run=read('run_index_v42.json');cost=read('resource_costs_v42.json');supervisions=[];formal_sources=[];stages=[]
for row in cost['runs']:
 folder=ROOT/row['folder'];manifest=json.loads(raw[key(folder/'run_manifest.json')]);role=manifest['stage'].removeprefix('V42-')
 if role in ('ENVELOPE','CLASSES','ORACLE','VOLUME1','VOLUME2','VOLUME4','RECOVERY2','RECOVERY4','CHECK','TARGET_GATE','DEPLOY','CAPACITY'):
  for fp,h in manifest['implementation_hashes'].items():assert sha(git('show',manifest['source_sha']+':'+fp))==h,(role,fp)
  formal_sources.append(dict(role=role,source_sha=manifest['source_sha'],hashes=len(manifest['implementation_hashes']),manifest=str(folder/'run_manifest.json')))
 p=folder/'supervision/summary.json';s=json.loads(raw[key(p)]);samples=[json.loads(b) for b in raw[key(folder/'supervision/resources.jsonl')].splitlines()]
 assert len(samples)==s['samples']
 for v in samples:
  assert v['rss_bytes']==sum(m['rss_bytes'] for m in v['members']);assert v['swap_bytes']==sum(m['swap_bytes'] for m in v['members'])
 assert max(v['rss_bytes'] for v in samples)==s['sampled_process_tree_rss_peak_bytes']
 assert max(v['swap_bytes'] for v in samples)==0 and s['descendants_cleared'];assert s['elapsed_seconds']==row['seconds']
 supervisions.append(dict(role=row['role'],path=str(p),seconds=s['elapsed_seconds'],peak=s['sampled_process_tree_rss_peak_bytes'],samples=len(samples),status=s['classification']))
for row in run['runs']:
 for field in ('manifest','summary','result'):
  x=row.get(field)
  if x:
   b=(ROOT/x['path']).read_bytes();assert sha(b)==x['sha256'];assert len(b)==x['bytes']
   if field=='result':stages.append(json.loads(b))
probes=[json.loads(p.read_text()) for p in (ROOT/'tmp/task042/v42').glob('probe_*.json')];sumruns=sum(s['seconds'] for s in supervisions);sumprobes=sum(p['elapsed_seconds'] for p in probes);total=sumruns+sumprobes+cost['metadata_close_measured_seconds']
assert math.isclose(sumruns,cost['supervised_seconds'],rel_tol=1e-14);assert math.isclose(sumprobes,cost['paid_probe_seconds'],rel_tol=1e-14);assert math.isclose(total,cost['charged_total_so_far_seconds'],rel_tol=1e-14)
peak=max(s['peak'] for s in supervisions)
book=json.loads((ROOT/'tmp/task042/v42/ledger.json').read_text());assert book['closed'] and book['active'] is None and len(book['runs'])==len(supervisions)
admissions=[]
for p in probes:
 d=json.loads(raw[key(p['receipt_path'])]);fr={int(k):v for k,v in d['cpu_busy_fractions'].items()};reasons={}
 for name,b in d['cpu_ticks_before'].items():
  a=d['cpu_ticks_after'][name];assert abs(1-(a[3]-b[3]+a[4]-b[4])/max(sum(a)-sum(b),1)-fr[int(name)])<1e-15
 for tid,a in d['thread_ticks_after'].items():
  b=d['thread_ticks_before'].get(tid)
  if b and a[0]==b[0]:assert d['thread_delta_ticks'][tid]==a[1]-b[1]
 for cpu,v in fr.items():
  if v>.05:reasons.setdefault(cpu,[]).append('sample_busy_fraction_gt_0.05')
 for proc in d['neighbor_processes']:
  for t in proc['threads']:
   if len(t['affinity'])<=16:
    for cpu in t['affinity']:reasons.setdefault(cpu,[]).append('narrow_thread_affinity:'+str(t['tid']))
   elif d['thread_delta_ticks'].get(str(t['tid']),1)>0:reasons.setdefault(t['cpu'],[]).append('active_wide_thread:'+str(t['tid']))
 decisions=[dict(**t,eligible=not any(c in reasons for c in t['siblings']),excluded_siblings={str(c):reasons[c] for c in t['siblings'] if c in reasons}) for t in d['topology']]
 assert decisions==d['cpu_decisions'];assert [t['cpu'] for t in decisions if t['eligible']]==d['candidate_cpus'];assert d['selected_cpu'] in d['candidate_cpus'];admissions.append(dict(path=p['receipt_path'],cpu=d['selected_cpu']))
# Only frozen array byte/hash/header inspection, no FE or NumPy/BLAS execution.
receipts={}
def walk(v):
 if isinstance(v,dict):
  if all(k in v for k in ('path','sha256','members')) and str(v['path']).endswith('.npz'):receipts[v['path']]=v
  for w in v.values():walk(w)
 elif isinstance(v,list):
  for w in v:walk(w)
walk(read('array_inventory_v42.json'));array_checks=[]
for path,receipt in receipts.items():
 p=Path(path);assert sha(p.read_bytes())==receipt['sha256'];aliases=receipt.get('aliases',{})
 with zipfile.ZipFile(p) as z:
  assert set(z.namelist())=={k+'.npy' for k in receipt['members'] if k not in aliases}
  for name,m in receipt['members'].items():
   actual=aliases.get(name,name);assert actual not in aliases;b=z.read(actual+'.npy');assert b[:6]==b'\x93NUMPY';length=2 if b[6]==1 else 4;off=8+length;size=int.from_bytes(b[8:off],'little');meta=ast.literal_eval(b[off:off+size].decode().strip());assert list(meta['shape'])==m['shape'] and meta['descr']==m['dtype'];payload=b[off+size:]
   if meta['fortran_order']:
    assert len(meta['shape'])==2,(path,name,meta)
    nr,nc=meta['shape'];width=int(meta['descr'][2:]);view=memoryview(payload)
    payload=b''.join(view[(j*nr+i)*width:(j*nr+i+1)*width] for i in range(nr) for j in range(nc))
   assert sha(payload)==m['sha256'],(path,name)
 array_checks.append(dict(path=path,members=len(receipt['members']),stored_members=len(receipt['members'])-len(aliases),bytes=p.stat().st_size))
scalars=[]
def ratios(v):
 if isinstance(v,dict):
  if {'numerator','denominator','passed'} <= set(v):
   num,den=v['numerator'],v['denominator'];passed=num<=v['absolute_rule'] if 'absolute_rule' in v else num==0 if den==0 else num/den<=1e-10
   assert v['passed']==passed,v
   if den and v.get('relative') is not None:assert math.isclose(v['relative'],num/den,rel_tol=1e-13)
   scalars.append(v)
  for val in v.values():ratios(val)
 elif isinstance(v,list):
  for val in v:ratios(val)
ratios(read('component_checker_v42.json'))
xml=[]
for p,b in raw.items():
 if p.endswith('pytest.xml'):
  t=ET.fromstring(b);suite=list(t)[0] if t.tag=='testsuites' else t;xml.append(dict(path=p,tests=int(suite.get('tests')),failures=int(suite.get('failures')),errors=int(suite.get('errors'))))
# Final implementation snapshot separated from formal run source.
tests=read('source_inventory_v42.json');source=tests['implementation_hashes']
for p,h in source.items():assert sha((ROOT/p).read_bytes())==h,p


from statistics import median
sampling=[]
for row in cost['runs']:
 v=[json.loads(b) for b in raw[key(ROOT/row['folder']/'supervision/resources.jsonl')].splitlines()];delta=[b['elapsed_seconds']-a['elapsed_seconds'] for a,b in zip(v,v[1:])]
 sampling.append(dict(folder=row['folder'],sample_count=len(v),actual_interval_median=median(delta) if delta else None,actual_interval_max=max(delta,default=None)))
check=read('component_checker_v42.json');A=check['independent_internal_audit'];B=check['recovery'];ar=[c for c in A['checks'] if '_native_internal_cell' in c['kind']];br=[c for c in B['checks'] if 'CSR_internal_balance' in c['kind']]
assert len(ar)==192 and sum(not c['passed'] for c in ar)==99 and len(br)==2 and all(not c['passed'] for c in br)
assert check['volume_action_passed'] is True and check['passed'] is False
old=read('review_v39_independent_checks.json');assert old['topology_independent']['raw']==270
x=dict(reviewed_head=HEAD,previous_review=BASE,scope='stdlib read-only bytes/source/resources/metadata audit; no FE, matrix action, recovery, factorization or training',raw_archives_verified=len(rawidx['files']),current_originals_matching_archived_version=originals,unmatched_current_originals=changed,protected_files=len(protected),history_files=history,compiled=compiled,formal_source_checks=formal_sources,final_source_hashes=source,supervisions=supervisions,CPU_admissions=admissions,costs=dict(supervised=sumruns,probes=sumprobes,metadata_close=cost['metadata_close_measured_seconds'],total=total,peak_sampled_tree_bytes=peak,ownswap=0,cumulative_supervised_lower=cost['cumulative_supervised_lower_seconds'],unmonitored='unknown'),array_byte_verification=array_checks,array_totals=dict(files=len(array_checks),logical=sum(v['members'] for v in array_checks),actual=sum(v['stored_members'] for v in array_checks)),scalar_ratio_checks=len(scalars),pytest_snapshots=xml,sampling=sampling,finite_recovery=dict(A_states=len(ar),A_failures=99,A_max=max(c['relative'] for c in ar),B_checks=br,threshold=1e-10,full_recovery_qualified=False),volume_action_metadata_pass=True,target_action_not_run=True,unchanged_V41_topology_prior_independent_record=old['topology_independent'],repository_index_sha256=sha((O/'repository_index.json').read_bytes()),dot_head='077ec9c8386c976da232093779279fb9d1a93033',source_changes=False,limitations=['not whole-repository line-by-line semantic audit','saved ratio checks are not vector/matrix numerical replay','V42 recovery and target solve unqualified','no neural training/inference or NN20 gain','review ordinary IO/human cost unmonitored'])
(O/'independent_checks.json').write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(raw=len(rawidx['files']),originals=originals,changed=changed,protected=len(protected),history=len(history),compiled=len(compiled),formal_sources=len(formal_sources),costs=x['costs'],arrays=x['array_totals'],ratios=len(scalars),recovery=x['finite_recovery'],tests=xml),indent=2))
