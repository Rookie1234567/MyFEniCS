"""Append exact raw versions and immutable source identities after doc checks."""
import gzip,hashlib,json,subprocess,time
from pathlib import Path
from src.runners.task042_shared import write_json
from src.solvers.boundary_structure_scope import ROOT,window,ARTIFACT

R=ROOT/'docs/task042_neural_coarse_inverse/outcomes/records';T=window.TMP
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
raw=json.loads((R/'raw_evidence_index_v38.json').read_text());seen={(r['original_path'],r['sha256']):r for r in raw['files']}
book=window.ledger();paths=set()
for entry in book['runs']:
    d=Path(entry['folder'])
    paths.update(p for p in d.rglob('*') if p.is_file() and p.suffix in ('.json','.jsonl','.log','.stdout','.stderr','.xml','.dat','.txt'))
paths.update(p for p in T.iterdir() if p.is_file() and p.suffix in ('.json','.jsonl','.log','.stdout','.stderr','.txt','.py'))
for p in sorted(paths):
    h=sha(p);key=(str(p),h)
    if key in seen:continue
    data=p.read_bytes();out=R/('raw_v38_final_'+hashlib.sha256(str(p).encode()).hexdigest()[:10]+'_'+h[:8]+'_'+p.name+'.gz')
    out.write_bytes(gzip.compress(data,compresslevel=1,mtime=0))
    if gzip.decompress(out.read_bytes())!=data:raise ValueError('final raw archive mismatch')
    seen[key]={'original_path':str(p),'gzip':str(out.relative_to(ROOT)),'bytes':len(data),'sha256':h,'gzip_sha256':sha(out)}
raw['files']=list(seen.values());write_json(R/'raw_evidence_index_v38.json',raw)
current=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
changed=subprocess.check_output(['git','diff','--name-only','cf0896e57f9f16970e5af6b55ad14920ab4c7815','HEAD'],text=True).splitlines()
write_json(R/'changed_files_v38.json',{'implementation':changed,'navigation_updated_preserving_history':['README','outcomes/summary','test_summary','changed_files','development_progress','development_model_registry'],'new_delivery':['response_v38.md','outcomes/directional_boundary_structure_v38.md','outcomes/records/*v38*'],'old_authorities_modified':False,'ordinary_defaults_changed':False,'actual_source_before_docs':current})
write_json(R/'minimum_result_cost_v38.json',{'status':'TARGET_BOUNDARY_ACTION_QUALIFIED_AT_FROZEN_Q','q':30,'real_MPI':1,'modes':32060,'boundary_rows':378432,'full_solver':'NOT_RUN_NOT_QUALIFIED','NN20':'NOT_DEMONSTRATED','native_bridge':'QUALIFIED','pending_final_metadata_settlement':True,'clock':window.snapshot(),'charged_seconds_before_final':window.charged_wall(),'source':current})
print(json.dumps({'raw_versions':len(seen),'final_numeric_source_unchanged':current,'pending_metadata_only':book['active']}),flush=True)
