"""Delivery checks on metadata/archives only. No FE runtime or new solve."""
import gzip
import hashlib
import json
import re
import subprocess
import time
from pathlib import Path

ROOT=Path('/home/fenics/Projects/NN-Lab')
R=ROOT/'docs/task042_neural_coarse_inverse/outcomes/records'
T=ROOT/'tmp/task042/v37'
REVIEW='02fe5f860562f6a7ef689f9d53b061cfaf30a43b'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(n,x):(R/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')

def main():
    began=time.monotonic();source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
    final_tests=json.loads((T/'aux_pre_06/tests.json').read_text())
    for p,h in final_tests['implementation_hashes'].items():
        if sha(ROOT/p)!=h:raise ValueError('final tested source hash changed '+p)
    raw=json.loads((R/'raw_evidence_index_v37.json').read_text());checked=[]
    for row in raw['files']:
        p=ROOT/row['gzip'];data=gzip.decompress(p.read_bytes())
        if sha(p)!=row['gzip_sha256'] or len(data)!=row['bytes'] or hashlib.sha256(data).hexdigest()!=row['sha256']:
            raise ValueError('raw archival content '+str(p))
        checked.append(row['gzip'])
    extra=[T/n for n in ['start_identity.json','window.json','qualification.json','fix_02.json','fix_03.json','storage_stop.json','ack_receipt.txt','package.py','post_check.py','write_delivery.py','dot_source_0.txt','dot_source_1.txt','dot_source_2.txt','dot_published_input.dat','authoring_ruff.stdout','authoring_ruff.stderr']]
    extra.extend(T.glob('probe_*.json'))
    idx=json.loads((R/'run_index_v37.json').read_text())
    extra.extend(Path(row['path']) for row in idx['parents'].values())
    cap=json.loads(Path(idx['parents']['capacity']['path']).read_text())
    for row in cap['native_files'].values():extra.append(Path(row['path']).with_suffix('.json'))
    for row in cap['manual_files'].values():extra.append(Path(row['path']).with_suffix('.json'))
    extra.append(Path(json.loads((R/'witness_inventory_v37.json').read_text())['witness_plan']['path']))
    for p in extra:
        if not p.exists():continue
        out=R/('raw_v37_extra_'+hashlib.sha256(str(p).encode()).hexdigest()[:8]+'_'+p.name+'.gz')
        data=p.read_bytes();out.write_bytes(gzip.compress(data,compresslevel=1,mtime=0))
        if gzip.decompress(out.read_bytes())!=data:raise ValueError('extra archive readback')
        raw['files'].append({'original_path':str(p),'gzip':str(out.relative_to(ROOT)),'bytes':len(data),'sha256':sha(p),'gzip_sha256':sha(out)})
    dump('raw_evidence_index_v37.json',raw)
    py=[p for p in final_tests['implementation_hashes'] if p.endswith('.py')]
    lint=subprocess.run(['/home/fenics/Projects/Metrology/.venv/bin/ruff','check',*py],cwd=ROOT,capture_output=True,text=True)
    (T/'final_ruff.stdout').write_text(lint.stdout);(T/'final_ruff.stderr').write_text(lint.stderr)
    dump('tests_v37.json',{'source_metadata_checker':source,'final_focused':final_tests,'counts':{'serial_passed':31,'serial_failed':0,'synthetic_MPI_sizes':[2,4]},'prior_failure':'aux_pre_01: 27 passed / 1 failed; clean child fixture repair; original preserved',
                         'ruff':{'returncode':lint.returncode,'stdout':str(T/'final_ruff.stdout'),'sha256':sha(T/'final_ruff.stdout')},'CI':'NOT_CLAIMED'})
    allow={'docs/task042_neural_coarse_inverse/README.md','docs/task042_neural_coarse_inverse/outcomes/summary.md','docs/task042_neural_coarse_inverse/outcomes/test_summary.md','docs/task042_neural_coarse_inverse/outcomes/changed_files.md','docs/development_progress.md','docs/development_model_registry.md'}
    historical=[]
    for p in sorted(allow):
        old=subprocess.check_output(['git','show',REVIEW+':'+p],cwd=ROOT)
        new=(ROOT/p).read_bytes()
        if not new.endswith(old):raise ValueError('historical suffix changed '+p)
        historical.append({'path':p,'prior_sha256':hashlib.sha256(old).hexdigest(),'bytes':len(old),'suffix_exact':True})
    changed=subprocess.check_output(['git','diff','--name-only',REVIEW],cwd=ROOT,text=True).splitlines()
    bad=[p for p in changed if ('/review_report_' in p or '/response_' in p or p.endswith('/task.md') or p.endswith('AGENTS.md'))]
    if bad:raise ValueError('protected authority changed '+str(bad))
    docs=[ROOT/'docs/task042_neural_coarse_inverse/response_v37.md',ROOT/'docs/task042_neural_coarse_inverse/outcomes/target_p6_boundary_tiles_v37.md',ROOT/'docs/task042_neural_coarse_inverse/review_report_v34.md']+[ROOT/p for p in allow]
    markdown=[]
    for p in docs:
        text=p.read_text().split('<!-- V37-LATEST-END -->',1)[0]
        fence=False;last=None;tables=0;links=0
        for line in text.splitlines():
            if line.startswith('```'):fence=not fence;last=None;continue
            if fence:continue
            if '$$' in line or '\\[' in line:raise ValueError('unsupported new math delimiter '+str(p))
            if line.strip().startswith('|'):
                cols=len(re.split(r'(?<!\\)\|',line))-2
                if last is not None and cols!=last:raise ValueError('table columns '+str(p))
                if last is None:tables+=1
                last=cols
            else:last=None
        if fence:raise ValueError('unclosed fence '+str(p))
        for target in re.findall(r'\]\(([^)]+)\)',text):
            if target.startswith(('https://','http://','#')):continue
            q=target.split('#',1)[0]
            if q and not (p.parent/q).exists():raise ValueError('local link missing '+str(p)+' '+target)
            links+=1
        markdown.append({'path':str(p.relative_to(ROOT)),'tables':tables,'local_links_checked':links,'passed':True})
    dump('documentation_checks_v37.json',{'github_visual':'NOT_VERIFIED','exact_review_url':'https://github.com/Rookie1234567/MyFEniCS/blob/'+REVIEW+'/docs/task042_neural_coarse_inverse/review_report_v34.md','web_attempt':'Failed to fetch: Cache miss; no visual rendering received','local_markdown':markdown,'historical_suffix':historical,'old_authority_paths_modified':bad,'CI':'NOT_CLAIMED'})
    dump('evidence_checks_v37.json',{'source_sha':source,'archives_checked':len(checked),'extra_archives_added':len(raw['files'])-len(checked),'tested_implementation_hashes_equal':True,'legacy_suffix_unchanged':True,'old_authorities_modified':False,'metadata_wall_seconds':time.monotonic()-began,'ruff_exit':lint.returncode,'volume_actions':0,'LU':0,'QR':0,'training':0})
    print(json.dumps({'archives_checked':len(checked),'ruff_exit':lint.returncode,'local_markdown':'PASSED','history':'UNCHANGED'}),flush=True)
    if lint.returncode:raise ValueError('targeted Ruff failed; exact output saved')

if __name__=='__main__':main()
