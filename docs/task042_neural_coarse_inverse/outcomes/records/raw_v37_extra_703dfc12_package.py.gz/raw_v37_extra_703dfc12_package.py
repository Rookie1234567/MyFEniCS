"""V37 evidence packaging: raw metadata/hashes only, no FE imports or solves."""
import gzip
import hashlib
import json
import shutil
import subprocess
import time
from pathlib import Path

from src.runners.task042_shared import write_json
from src.runners.port_preparation import storage
from src.solvers.boundary_witness_scope import ARTIFACT,ROOT,read_stage,window

OUT=ROOT/'docs/task042_neural_coarse_inverse/outcomes/records'
OUT.mkdir(parents=True,exist_ok=True)

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def dump(name,v):write_json(OUT/name,v)


def main():
    began=time.monotonic();book=window.ledger();rows=[];raw=[]
    for number,entry in enumerate(book['runs']):
        directory=Path(entry['folder']);summary=directory/('summary.json' if directory.name.startswith('aux_') else 'run_summary.json')
        info=json.loads(summary.read_text());rows.append({'role':entry['role'],'source_sha':entry['source_sha'],'directory':str(directory),
            'summary_sha256':sha(summary),'elapsed_seconds':entry['elapsed_seconds'],'classification':entry['classification'],
            'exit_code':entry['exit_code'],'peak_bytes':entry['peak_bytes'],'swap_bytes':entry['swap_bytes'],'descendants_cleared':entry['descendants_cleared'],
            'cpu':json.loads((directory/'resource_baseline.json').read_text())['cpu']})
        files=[p for p in directory.rglob('*') if p.is_file() and (p.suffix in ('.json','.jsonl','.log','.stdout','.stderr','.xml','.dat','.txt'))]
        for p in files:
            output=OUT/f'raw_v37_{number:02d}_{hashlib.sha256(str(p).encode()).hexdigest()[:8]}_{p.name}.gz'
            data=p.read_bytes();encoded=gzip.compress(data,compresslevel=1,mtime=0)
            output.write_bytes(encoded)
            if gzip.decompress(encoded)!=data:raise ValueError('raw readback')
            raw.append({'original_path':str(p),'gzip':str(output.relative_to(ROOT)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'gzip_sha256':sha(output)})
    identity,identity_path=read_stage('IDENTITY');cap,cap_path=read_stage('CAPACITY');checked,check_path=read_stage('CHECK');deploy,deploy_path=read_stage('DEPLOY')
    dump('consumer_v37.json',{'consumer':identity['consumer'],'dot_readonly':identity['dot_readonly'],
         'identity_parent':{'path':str(identity_path),'sha256':sha(identity_path)},'default':deploy['status']})
    dump('component_checker_v37.json',checked)
    dump('run_index_v37.json',{'schema':'task042.v37.run-index.v1','base':'ccd357885f7f9be84efe3be07868cc94f13d93fc',
         'review':'02fe5f860562f6a7ef689f9d53b061cfaf30a43b','source_before_documentation':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
         'runs':rows,'partial_native_source':'ce18a6056731780d1feb4f47c96dfcc4f52aa6d1','capacity_source':cap['source_sha'],'checker_source':checked['source_sha'],
         'parents':{label:{'path':str(path),'sha256':sha(path)} for label,path in [('identity',identity_path),('capacity',cap_path),('checker',check_path),('deploy',deploy_path)]}})
    files=cap['native_files'];original30=json.loads((Path(files['30']['path']).with_suffix('.json')).read_text())
    clipping=[]
    for r in original30:
        c=r['clipping'];clipping.append({'original_index':r['original_index'],'mode':r['mode'],'first_deleted_counts':[v['count'] for v in c['first']],
            'second_deleted_counts':[v['count'] for v in c['second']], 'first_deleted_norms':[v['norm'] for v in c['first']],
            'second_deleted_norms':[v['norm'] for v in c['second']], 'C_relative':c['C_difference']['relative'],'D_relative':c['D_difference']['relative'],
            'empty_C':c['deleted_empty_C'],'empty_D':c['deleted_empty_D']})
    metrics={'status':cap['status'],'strict_target_witness':cap['target_p6_boundary_witness'],'selected_modes':cap['selected_mode_count'],
        'native_hex_count':cap['native_hex_count'],'description':cap['description'],
        'q15_q30_max':max(v['relative'] or 0 for v in checked['independent_quadrature_checks'] if v['kind'].startswith('q15')),
        'q30_native_q60_Basix_max':max(v['relative'] or 0 for v in checked['independent_quadrature_checks'] if v['kind'].startswith('q30')),
        'q30_same_max':max(v['relative'] or 0 for v in cap['same_q_checks']),
        'action_checks':cap['component']['checks'],'action_stats':cap['component']['action_stats'],
        'action_wall_seconds':cap['component']['action_wall_seconds'],'creator_costs':cap['creator_costs'],
        'legacy_clipping_q30':clipping,'old_V36_scope':'LEGACY_CLIPPED_SURFACE_EQUIVALENCE',
        'complete_native_q60':'NOT_RUN_STORAGE_GATE','periodic_mpc_patch_coverage':'NOT_RUN_STORAGE_GATE',
        'native_reference_files':files,'manual_files':cap['manual_files'],'action_witness':cap['component']['witness'],
        'source':cap['source_sha'],'checker_source':checked['source_sha']}
    dump('boundary_metrics_v37.json',metrics)
    archive=window.TMP/'jit_archive/manifest.json';arch=json.loads(archive.read_text())
    dump('jit_storage_gate_v37.json',{'external_stop':json.loads((window.TMP/'storage_stop.json').read_text()),
        'archive_manifest':{'path':str(archive),'sha256':sha(archive)},'archived_generated_raw_bytes':sum(v['bytes'] for v in arch['members']),
        'compressed_bytes':sum(v['archive_bytes'] for v in arch['members']),'members':arch['members'],
        'breach_not_erased':True,'live_new_storage_guard_added':True,'native_q60_jit_single_form_transient_example_bytes':sum(v['bytes'] for v in arch['members'] if '7880f9a1b9ba89723c66f2667514e62195223b35' in v['original'])})
    wp=identity['witness_plan'];plan=json.loads(Path(wp['path']).read_text())
    dump('witness_inventory_v37.json',{'witness_plan':wp,'selected_modes':plan['selected_modes'],'patches':plan['patches'],'planned_native_hex':plan['native_hex_count'],
                                     'measured_native_hex':cap['native_hex_count'],'global_period_nm':plan['global_period_nm'],'full_mode_count':32060})
    snapshot=storage(namespace='v37')
    resources={'rows':rows,'supervised_wall_seconds_before_pack':sum(v['elapsed_seconds'] for v in rows),
        'probes':window.probe_wall(),'conservative_bootstrap_charge':window.bootstrap,'charged_before_pack':window.charged_wall(),
        'sampled_tree_peak_bytes':max(v['peak_bytes'] for v in rows),'peak_scope':'0.5s simultaneous dedicated supervisor plus all descendants; not continuous cgroup peak',
        'own_swap_peak_bytes':max(v['swap_bytes'] for v in rows),'component_wall_seconds':sum(v['elapsed_seconds'] for v in rows if v['role'] in ('PATCH','CAPACITY')),
        'window':window.snapshot(),'storage':snapshot,'stage_nested_costs':cap['creator_costs'],'action_inclusive_seconds':cap['component']['action_wall_seconds'],
        'raw_archival_inclusive_seconds':next(v['elapsed_seconds'] for v in rows if v['role']=='archive'),
        'full_history':'prior lower bounds preserved; non-supervised implementation/metadata and complete upstream N1 remain UNKNOWN',
        'historical_formal_lower_seconds_before_v37':77349.71922726494,'GPU_used':False,'math_threads':1,'MPI_real_FE':1,'MPI_synthetic':[2,4],
        'new_volume_actions':0,'new_LU':0,'new_QR':0,'training':0,'physical_solve':False,'costs_identity':'shared-workstation; no uncontended speedup',
        'hardware_cgroup_limit_created':False,'scope_resource_stops':1,'repeat_CPU_rejection':0}
    dump('resource_costs_v37.json',resources)
    capacity={'ideal_single_mode_pair_payload_bytes':9082376,'legacy_conservative_pair_upper_bytes':111259016,'mode_cache_cap_bytes':67108864,
        'tile_cap_bytes':131072,'ordinary_measured_tile_payload_bytes':42336,'target_surface_faces_per_port':2628,'full_mode_count':32060,
        'two_pass_tile_visits_per_full_apply':2*32060*2628,'projection_reduction':'one scalar per mode; all owners including empty ranks; batch<=64',
        'creator_workspace_measured_example':cap['creator_costs'],'actual_target_single_mode_support':'UNKNOWN',
        'target_periodic_expansion_bound':'UNKNOWN; byte precheck rejects before allocation; finite ordinary witness does not prove all target maps',
        'target_full_storage_vector_payload_bytes':5532337056,'two_full_input_output_payload_lower_bytes':2*5532337056,
        'conditional_GMRES256_vector_group_payload_bytes':434673050112,'metadata':'O(Nport) separate from numeric cache; full Python overhead UNKNOWN',
        'global_solver_interiors_factors_MPI_IO_peak':'UNKNOWN, not additive pseudo-peak',
        'time_formula':'sum over 32060 modes and 2628 faces of projection-create plus traction-replay, plus MPI reduction/scatter and full vector IO; cache reuse, communication, iterations unknown',
        'measured_tile_creator_unit_seconds':cap['component']['action_stats']['creator_seconds']/cap['component']['action_stats']['tile_loads'],
        'unit_cost_transfer_to_target':'UNQUALIFIED; finite ordinary witness, cold JIT/geometry reuse and target row reader not measured',
        'target_N1_2TB_48h':'NOT_QUALIFIED','neural20':'NOT_DEMONSTRATED; no new NN or comparable full correct baseline'}
    dump('capacity_lifecycle_v37.json',capacity)
    dump('raw_evidence_index_v37.json',{'files':raw,'large_array_files':{**cap['native_files'],**{f'manual{q}':v for q,v in cap['manual_files'].items()},'actions':cap['component']['witness']},
        'large_JIT_archive':str(archive),'source_script_sha256':sha(__file__),'metadata_pack_wall_seconds':time.monotonic()-began})
    # Preserve every pre-review authority. Only the allowed current navigation
    # files may receive a prepended V37 block; no historical suffix replacement.
    changed=subprocess.check_output(['git','diff','--name-only','02fe5f860562f6a7ef689f9d53b061cfaf30a43b','HEAD'],text=True).splitlines()
    dump('changed_files_v37.json',{'implementation':changed,'review_history_files_modified':[p for p in changed if '/review_report_' in p or '/response_' in p],'ordinary_oracle_modified':False})
    dump('documentation_checks_v37.json',{'github_visual':'NOT_VERIFIED','exact_review_url':'https://github.com/Rookie1234567/MyFEniCS/blob/02fe5f860562f6a7ef689f9d53b061cfaf30a43b/docs/task042_neural_coarse_inverse/review_report_v34.md',
        'web_attempt':'Failed to fetch: Cache miss; no visual rendering received','local_markdown':'pending final self-check','CI':'NOT_CLAIMED'})
    print(json.dumps({'max_q15_q30':metrics['q15_q30_max'],'max_native30_Basix60':metrics['q30_native_q60_Basix_max'],
                      'max_same_q':metrics['q30_same_max'],'charged_before_pack':resources['charged_before_pack'],'peak':resources['sampled_tree_peak_bytes'],
                      'new_bytes':snapshot['new_bytes'],'native_seconds':resources['component_wall_seconds']}),flush=True)

if __name__=='__main__':main()
