import gzip, hashlib, json, math, statistics, subprocess
from pathlib import Path

ROOT=Path.cwd(); D=ROOT/'docs/task042_neural_coarse_inverse'; R=D/'outcomes/records'
O=ROOT/'tmp/task042/review_v44'; O.mkdir(parents=True,exist_ok=True)
HEAD='9a5434f23b78b16b7f8d7d56872eaec770204540'; BASE='0217f004a38f109a6253923f83a9a24b19d85362'
def sha(b): return hashlib.sha256(b).hexdigest()
def git(*args): return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*args])
def read(name): return json.loads((R/name).read_text())
def near(a,b): return math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-10)
assert git('rev-parse','HEAD').decode().strip()==HEAD
delivery=read('delivery_index_v46.json'); costs=read('resource_costs_v46.json')
raw={}; versions={}; archives=[]
for row in read('raw_evidence_index_v46.json')['files']:
 b=(ROOT/row['archive_path']).read_bytes(); assert sha(b)==row['archive_sha256'] and len(b)==row['archive_bytes']
 v=gzip.decompress(b); assert sha(v)==row['sha256'] and len(v)==row['bytes']
 k=str((ROOT/row['path']).resolve());raw[k]=v; versions.setdefault(k,[]).append(v);archives.append(row)
matched=[];unmatched=[];missing=[]
for k,vs in versions.items():
 if not Path(k).exists():missing.append(k)
 elif Path(k).read_bytes() in vs:matched.append(k)
 else:unmatched.append(dict(path=k,bytes=Path(k).stat().st_size,sha256=sha(Path(k).read_bytes())))
records=[]
for name,row in delivery['records'].items():
 b=(R/name).read_bytes();assert sha(b)==row['sha256'] and len(b)==row['bytes'],name;records.append(name)
compiled=[]
for p,h in delivery['implementation_hashes'].items():
 b=(ROOT/p).read_bytes();assert sha(b)==h and sha(git('show',delivery['source_sha']+':'+p))==h,p
 if p.endswith('.py'):compile(b,p,'exec');compiled.append(p)
protected=[];history=[]
append={'README.md','outcomes/summary.md','outcomes/test_summary.md','outcomes/changed_files.md'}
for line in git('ls-tree','-r',BASE,str(D.relative_to(ROOT))).decode().splitlines():
 meta,p=line.split('\t');oid=meta.split()[2];b=(ROOT/p).read_bytes();rel=str(Path(p).relative_to(D.relative_to(ROOT)))
 if rel in append:assert b.endswith(git('show',BASE+':'+p)),p
 else:assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid,p;protected.append(p)
 if Path(p).name.startswith(('review_report_v','response_v')):history.append(p)
for p in ('docs/development_progress.md','docs/development_model_registry.md'):
 assert (ROOT/p).read_bytes().endswith(git('show',BASE+':'+p))
plan=json.loads((ROOT/'input/task042_neural_coarse_inverse/neural_deployment_v46.json').read_text()); parents={}
for name,receipt in plan['parents'].items():
 b=(ROOT/receipt['path']).read_bytes();assert sha(b)==receipt['sha256'] and len(b)==receipt['bytes'];parents[name]=json.loads(b)
formal=json.loads(raw[str((ROOT/'tmp/task042/v46/aux_DECISION_001/run_manifest.json').resolve())])
assert formal['source_sha']==delivery['actual_decision_source_sha']
for p,h in formal['implementation_hashes'].items():assert sha(git('show',formal['source_sha']+':'+p))==h,p
probe=[];probe_by_folder={};admissions=[]
for p in (ROOT/'tmp/task042/v46').glob('probe_*.json'):
 v=json.loads(p.read_text());assert p.read_bytes() in versions[str(p.resolve())];probe.append(v)
 folder=str(Path(v['receipt_path']).parent.resolve());probe_by_folder[folder]=probe_by_folder.get(folder,0)+v['elapsed_seconds']
 a=json.loads(raw[str(Path(v['receipt_path']).resolve())]);fr={int(k):x for k,x in a['cpu_busy_fractions'].items()};reasons={}
 for name,b in a['cpu_ticks_before'].items():
  after=a['cpu_ticks_after'][name];assert abs(1-(after[3]-b[3]+after[4]-b[4])/max(sum(after)-sum(b),1)-fr[int(name)])<1e-15
 for cpu,val in fr.items():
  if val>.05:reasons.setdefault(cpu,[]).append('sample_busy_fraction_gt_0.05')
 for proc in a['neighbor_processes']:
  for t in proc['threads']:
   if len(t['affinity'])<=16:
    for cpu in t['affinity']:reasons.setdefault(cpu,[]).append('narrow_thread_affinity:'+str(t['tid']))
   elif a['thread_delta_ticks'].get(str(t['tid']),1)>0:reasons.setdefault(t['cpu'],[]).append('active_wide_thread:'+str(t['tid']))
 decisions=[dict(**t,eligible=not any(c in reasons for c in t['siblings']),excluded_siblings={str(c):reasons[c] for c in t['siblings'] if c in reasons}) for t in a['topology']]
 assert decisions==a['cpu_decisions'];assert a['selected_cpu'] in a['candidate_cpus'];admissions.append(dict(receipt=v['receipt_path'],selected_cpu=a['selected_cpu']))
runs=[];overhead=0.0
for row in delivery['runs']:
 folder=(ROOT/row['folder']).resolve()
 manifest=raw[str(folder/'run_manifest.json')];summary=raw[str(folder/'summary.json')]
 assert sha(manifest)==row['manifest_sha256'] and sha(summary)==row['summary_sha256'];s=json.loads(summary)
 samples=[json.loads(v) for v in raw[str(folder/'supervision/resources.jsonl')].splitlines()]
 for v in samples:
  assert v['rss_bytes']==sum(m['rss_bytes'] for m in v['members']);assert v['swap_bytes']==sum(m['swap_bytes'] for m in v['members'])==0
 assert len(samples)==s['samples'];peak=max(v['rss_bytes'] for v in samples);assert peak==s['sampled_process_tree_rss_peak_bytes']
 assert s['descendants_cleared'] and s['elapsed_seconds']==row['elapsed_seconds'] and s['leader_exit_code']==row['exit_code']
 intervals=[b['elapsed_seconds']-a['elapsed_seconds'] for a,b in zip(samples,samples[1:])]
 extra=max(0.,row['launch_wall_seconds']-row['elapsed_seconds']-probe_by_folder.get(str(folder),0));overhead+=extra
 runs.append(dict(role=row['role'],source=row['source_sha'],elapsed=s['elapsed_seconds'],exit_code=s['leader_exit_code'],peak=peak,samples=len(samples),max_interval=max(intervals,default=0),launcher_non_nested=extra))
supervised=math.fsum(v['elapsed'] for v in runs);probes=math.fsum(v['elapsed_seconds'] for v in probe)
assert near(supervised,costs['supervised_seconds']) and near(probes,costs['probe_seconds']) and near(overhead,costs['launcher_non_nested_seconds'])
lower=supervised+probes+overhead+costs['scalar_setup_seconds']+costs['post_settlement_measured_lower_seconds'];upper=lower+costs['post_settlement_final_tail_upper_seconds']
assert near(lower,costs['new_measured_lower_seconds']) and near(upper,costs['new_known_charged_seconds'])
assert near(costs['historical_lower_before_seconds']+lower,costs['historical_lower_with_current_seconds'])
assert max(v['peak'] for v in runs)==costs['sampled_process_tree_rss_peak_bytes'];assert near(max(v['max_interval'] for v in runs),costs['maximum_sample_interval_seconds'])
assert not any(costs['new_numeric_counts'].values())
bookbytes=(ROOT/'tmp/task042/v46/ledger.json').read_bytes();book=json.loads(bookbytes);assert book['closed'] and book['active'] is None
assert sha(bookbytes)==read('closed_window_v46.json')['ledger']['sha256']
feefile=ROOT/'tmp/task042/v46/post_settlement_fee.json';fee=json.loads(feefile.read_text())
assert near(fee['measured_lower_seconds'],costs['post_settlement_measured_lower_seconds'])
assert fee['final_tail_reserved_upper_seconds']==costs['post_settlement_final_tail_upper_seconds']
assert near(fee['seconds'],fee['measured_lower_seconds']+fee['final_tail_reserved_upper_seconds'])
oldfees=[json.loads(v) for v in versions[str(feefile.resolve())]]
fee_snapshot=dict(path=str(feefile.relative_to(ROOT)),sha256=sha(feefile.read_bytes()),bytes=feefile.stat().st_size,final=fee,archived_versions=oldfees,delta_from_last_archive=fee['seconds']-oldfees[-1]['seconds'],classification='final current metadata captured by independent review; latest fee receipt and tracked totals agree; archival gap is not a separately timed proof')
for row in read('closed_window_v46.json')['old_latest_ledgers']:
 p=ROOT/'tmp/task042'/row['namespace']/'ledger.json';b=p.read_bytes();assert sha(b)==row['sha256'];j=json.loads(b);assert j['closed'] and j['active'] is None
contract=read('cold_n1_cost_contract_v46.json');recomputed=[]
for route,r in parents['cost']['route_costs'].items():
 rows=[v for v in parents['comparison']['rows'] if v['route']==route];assert len(rows)==8
 prefix=statistics.mean(v['common_prefix_seconds'] for v in rows);infer=statistics.mean(v['inference_seconds'] for v in rows)
 phase={'data_teacher':r['prefix_train_validation_measured_seconds']+r['DATA_overhead_allocated_to_training_seconds'],'setup':r['one_time_SETUP_seconds']+r['one_time_gradient_qualification_seconds'],'training':r['selected_model_train_wall_measured_lower_seconds'],'loading':r['eval_load_start_IO_overhead_charged_once_seconds'],'common_prefix':prefix,'inference':infer,'post_cleanup':r['per_rhs_observed_online_mean']-prefix-infer,'audit_io':r['full_CHECK_group_allocation_charged_once_seconds'],'failures':0.}
 t=contract['routes'][route]['terms'];assert len({v['consumption_id'] for v in t})==len(t)
 for p,value in phase.items():assert near(next(v['value'] for v in t if v['consumption_id']==route+':current:'+p),value)
 inherited=0.
 if route=='CL44':
  old=parents['inherited_cost']['route_costs']['CL-E'];assert old==r['inherited_V44_CL44_preparation_training_cost']
  inherited=sum(old[p] for p in ('prefix_train_validation_measured_seconds','DATA_overhead_allocated_to_training_seconds','one_time_SETUP_seconds','one_time_gradient_qualification_seconds','selected_model_train_wall_measured_lower_seconds'))
  assert near(inherited,493.7489533459302)
 known=math.fsum(phase.values())+inherited;assert near(known,r['N1_known_lower_scenario_seconds'])
 assert near(known,contract['summaries'][route]['known_lower_seconds']) and contract['summaries'][route]['complete_seconds'] is None
 assert any(v['phase']=='failures' and v['value'] is None for v in t)
 assert parents['checker']['full_pass_by_route'][route]==parents['comparison']['qualification'][route]==0
 recomputed.append(dict(route=route,known_lower_seconds=known,complete_seconds=None,inherited_prepare_train=inherited,correct_count=0))
assert contract['selector']['status']=='NO_ALL_EIGHT_CORRECT_ROUTE' and contract['selector']['selected'] is None
def leaves(v,p=''):
 if isinstance(v,dict):
  for k,x in v.items():yield from leaves(x,p+'.'+k if p else k)
 else:yield p,v
engine=read('engine_matching_v46.json');checked_fields=[]
for layer in ('physics','discretization','problem','correctness','engineering','neural'):
 offered=dict(leaves(plan['dot_offered_contract'][layer]))
 for field,expected in leaves(plan['target_contract'][layer]):
  actual=offered.get(field);known=expected is not None and expected!='unknown';good=known and type(actual) is type(expected) and actual==expected
  recorded=next(v for v in engine['rows'] if v['layer']==layer and v['field']==field);assert recorded['passed']==good
  checked_fields.append(dict(layer=layer,field=field,passed=good))
assert engine['status']=='NO_MATCHED_QUALIFIED_ENGINE' and engine['accepted'] is False
correction=read('final_stdout_correction_v46.json');a=correction['new_final'];assert len(gzip.decompress((ROOT/a['archive_path']).read_bytes()))==355
old=correction['old_empty_archive'];assert sha((ROOT/old['path']).read_bytes())==old['sha256'] and gzip.decompress((ROOT/old['path']).read_bytes())==b''
tests=read('tests_v46.json');assert tests['pure_passed']==25 and tests['ML_fixture_skipped_in_pure']==1 and tests['ML_isolated_test_count']==1
for field in ('pure_stdout_archive_source','ML_stdout_archive_source'):
 log=raw[str((ROOT/tests[field]).resolve())].decode();assert 'OK' in log and 'FAILED' not in log
dotpath=Path('/tmp/task042_review44_dot.json')
dot=json.loads(dotpath.read_text()) if dotpath.exists() else read('review_v44_independent_checks.json')['dot_publication']
out=dict(reviewed_head=HEAD,previous_review=BASE,scope='stdlib raw/source/scalar/resource/history audit; no FE/ML action or numerical replay',raw_archives=len(archives),current_originals_matching_version=len(matched),unmatched=unmatched,missing=missing,delivery_record_hashes_checked=records,protected_files=len(protected),history_files=len(history),compiled_files=compiled,formal_source=formal['source_sha'],final_implementation_source=delivery['source_sha'],runs=runs,admissions=admissions,costs=dict(supervised=supervised,probes=probes,launcher_non_nested=overhead,known_lower=lower,charged_upper=upper,history_lower=costs['historical_lower_with_current_seconds']),cost_routes=recomputed,engine_fields=checked_fields,corrected_old_stdout_bytes=355,software_tests=tests,dot_publication=dot,findings=[dict(kind='incorrect_frozen_metadata',path='input/task042_neural_coarse_inverse/neural_deployment_v46.json',field='dot_offered_contract.discretization.degree',reported=6,actual_from_source=4,affects_overall_rejection=False),dict(kind='metadata_contract_scope',detail='matcher checks assertions; hashing a compact does not independently validate every asserted field, full physical qualification remains separate')],repository_index_sha256=sha((O/'repository_index.json').read_bytes()),new_numeric_actions=0,review_source_changes=False,limitations=['No repeated saved FE vectors, weights or old scientific payload audit; unchanged hashes preserve prior review scope','Dot publication and compact only, not independent raw numerical requalification','Formal metadata reject is supported; engine acceptance is not physical qualification','Review ordinary IO/human costs not monitored'])
out['final_fee_snapshot']=fee_snapshot
out['review_helper_repair']='corrected ledger namespace/path lookup and removed unsupported assumption that metadata-repair timer was the only post-archive settlement change; reran stdlib audit; no production change or actor'
(O/'independent_checks.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:out[k] for k in ('raw_archives','current_originals_matching_version','unmatched','missing','protected_files','history_files','costs','cost_routes','findings')},ensure_ascii=False,indent=2))
